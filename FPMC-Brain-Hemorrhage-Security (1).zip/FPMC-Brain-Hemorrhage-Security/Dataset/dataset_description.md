# Dataset description

Source: ROCOv2 MRI images with radiology captions, reorganised into class folders
(`control`, `epidural`, `intracerebral`, `intraventricular`, `subdural`; `unspecified` / `multiple` are ignored).

`balanced_526.csv` (written by the dataset verify/expand script) has one row per image:

| column | meaning |
|---|---|
| ID | image file id |
| Caption | clinical caption / note |
| split | train / val / test (`valid` is mapped to `val`) |
| class | one of the five classes |
| image_path | path to the image relative to `balanced_526/` |
| is_augmented | True for synthetic copies (TRAIN SPLIT ONLY, never used for testing) |
| source_id | ID of the real image an augmented copy was made from (groups are never split across train/test) |

Known data caveats to report in the paper
* control images must exist (the pipeline stops if a class has zero images);
* all epidural captions in the source describe spinal epidural hematomas; one IVH item is cardiac; some controls are non-brain;
* augmented copies inherit captions, so they are excluded from every test metric;
* with ~5-20 real test images per class, every interval is wide.

`sample_metadata.csv` shows the expected format (three illustrative rows).
