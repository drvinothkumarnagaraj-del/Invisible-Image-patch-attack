"""STEP 4 - adaptive image attacks against the TRAINED models: detection TPR/FPR, classifier accuracy and attack success rate
(ASR) per attack, plus a detector-aware black-box attack that queries the classifier and the patch detector."""
import joblib, numpy as np, pandas as pd, torch
from common import *
from Attacks.fiba_attack import fiba, psnr
from Attacks.patch_generation import load_triggers, sample_attack_params, apply_attack, ADAPTIVE_KINDS
from Attacks.adaptive_attacks import detector_aware_attack
from Federated_Learning.client_training import MultimodalNet, predict
from Detection.maxvit_detection import CamFeatureExtractor
from Defense.fpmc_defense import FPMCDefense
from Evaluation.attack_success_rate import conditional_asr
from Evaluation.confidence_intervals import fmt_rate

cfg = load_config(); set_seed(cfg["seed"]); dev = device(); D = load_cache(cfg); dt = cfg["detection"]
Xc, y, E, Ep, caps, pcaps, split, is_aug = D["Xc"], D["y"], D["E_orig"], D["E_pois"], D["caps"], list(D["poisoned_caps"]), D["split"], D["is_aug"]
EV = cfg["data"]["classes"].index(cfg["data"]["evade_class"]); NC = len(cfg["data"]["classes"]); S = cfg["data"]["img_size"]
trigs, _ = load_triggers(cfg["paths"]["patch_dir"], S, *D["clahe"].tolist(), n=cfg["attack"]["trigger_pool"])
te = np.where((split == "test") & ~is_aug)[0]; hem = te[y[te] != EV]; rs = np.random.RandomState(cfg["seed"] + 5)
pdet = joblib.load(cache_path(cfg, "patch_detector.joblib"))["detector"]
cx = CamFeatureExtractor(cfg["backbone"]["name"], tuple(cfg["backbone"]["gradcam_stages"]), dev, dt["cam_threshold"])
cx.window = getattr(pdet, "window", None)      # POA-selected attention window saved in step 2
defense = FPMCDefense(cx, pdet, dt["cam_threshold"], float(D["cos_tau"][0]))
def load(tag):
    m = MultimodalNet(cfg["backbone"]["name"], NC, text_dim=E.shape[1], pretrained=False); m.load_state_dict(torch.load(cache_path(cfg, tag))); return m.to(dev).eval()
M_plain, M_fpmc = load("model_fedavg_data_poison.pt"), load("model_fpmc_data_poison.pt")

clean_flag = pdet.flag(cx(Xc[te])); print(f"clean test images flagged by the patch detector: {fmt_rate(float(clean_flag.mean()), len(te))}")
_bp, _bf = predict(M_plain, Xc[hem], None, "image", dev), predict(M_fpmc, Xc[hem], None, "image", dev)
rows = []
def evaluate(name, Xatt, ps, reps=1):
    base_plain, base_fpmc, hem_ = np.tile(_bp, reps), np.tile(_bf, reps), np.tile(hem, reps)
    flag = pdet.flag(cx(Xatt)); p_plain = predict(M_plain, Xatt, None, "image", dev)
    Xd, fi = defense.sanitize_images(Xatt); p_def = predict(M_fpmc, Xd, None, "image", dev); p_fp_nodef = predict(M_fpmc, Xatt, None, "image", dev)
    a0, n0, _ = conditional_asr(base_plain, p_plain, EV); a1, n1, _ = conditional_asr(base_fpmc, p_fp_nodef, EV); a2, n2, _ = conditional_asr(base_fpmc, p_def, EV)
    rows.append({"attack": name, "mean PSNR dB": round(float(np.mean(ps)), 1), "detection TPR": fmt_rate(float(flag.mean()), len(flag)),
                 "detection FPR (clean)": fmt_rate(float(clean_flag.mean()), len(te)),
                 "ASR undefended FedAvg model": fmt_rate(a0, n0), "ASR FPMC-trained, no inference defence": fmt_rate(a1, n1), "ASR FPMC-trained + defence": fmt_rate(a2, n2),
                 "accuracy after defence (hemorrhage)": fmt_rate(float((p_def == y[hem_]).mean()), len(hem_))})
seen = [fiba(Xc[i], trigs[0], cfg["attack"]["fiba"]["alpha"], cfg["attack"]["fiba"]["beta"]) for i in hem]
evaluate("seen FIBA (alpha=0.3,beta=0.1)", np.stack(seen), [psnr(Xc[i], s) for i, s in zip(hem, seen)])
# attack-strength sweep: detection TPR/FPR and ASR (undefended / FPMC-trained / FPMC + defence) at every alpha
for a in cfg["attack"]["alphas"]:
    sw = [fiba(Xc[i], trigs[0], a, cfg["attack"]["fiba"]["beta"]) for i in hem]
    evaluate(f"FIBA strength sweep (alpha={a},beta={cfg['attack']['fiba']['beta']})", np.stack(sw), [psnr(Xc[i], s) for i, s in zip(hem, sw)])
for kind in ADAPTIVE_KINDS:
    imgs, ps = [], []
    for _ in range(dt["adaptive_per_kind"]):
        for i in hem:
            xa = apply_attack(Xc[i], trigs[rs.randint(len(trigs))], sample_attack_params(kind, rs), rs); imgs.append(xa); ps.append(psnr(Xc[i], xa))
    evaluate("adaptive: " + kind, np.stack(imgs), ps, dt["adaptive_per_kind"])
save_table(pd.DataFrame(rows), cfg, "step4a_adaptive_attacks")

# ---- detector-aware attack ----
cls_fn = lambda x: predict(M_fpmc, x[None], None, "image", dev)[0]
det_fn = lambda x: float(pdet.score(cx(x[None]))[0])
res = []
for i in hem[:dt["detector_aware_images"]]:
    if cls_fn(Xc[i]) == EV: continue
    r = detector_aware_attack(Xc[i], trigs, cls_fn, det_fn, EV, pdet.thr, dt["detector_aware_budget"], dt["psnr_min_adaptive_db"], rs)
    if r is None: continue
    Xd, _ = defense.sanitize_images(r["image"][None]); r["after_defence_target"] = bool(predict(M_fpmc, Xd, None, "image", dev)[0] == EV); res.append(r)
if res:
    n = len(res); k = lambda key: sum(bool(r[key]) for r in res)
    out = pd.DataFrame([{"images attacked": n, "mean PSNR dB": round(float(np.mean([r["psnr"] for r in res])), 1),
                         "misclassified as control": fmt_rate(k("success") / n, n), "evaded detector": fmt_rate(k("evaded") / n, n),
                         "both (successful + undetected)": fmt_rate(sum(r["success"] and r["evaded"] for r in res) / n, n),
                         "still target after sanitisation": fmt_rate(k("after_defence_target") / n, n), "query budget/image": dt["detector_aware_budget"]}])
    save_table(out, cfg, "step4b_detector_aware_attack")
else: print("detector-aware attack: no eligible images")
print("\nNote: random search is a WEAK detector-aware attacker. A white-box gradient attack would be stronger; state this as a limitation.")
