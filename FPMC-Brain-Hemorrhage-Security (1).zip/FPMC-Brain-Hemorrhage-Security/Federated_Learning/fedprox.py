"""FedProx: local objective  L(w) + (mu/2) * ||w - w_global||^2."""
import torch


def prox_term(model, global_params, mu):
    if mu <= 0: return 0.0
    s = 0.0
    for p, g in zip(model.parameters(), global_params):
        s = s + ((p - g) ** 2).sum()
    return 0.5 * mu * s
