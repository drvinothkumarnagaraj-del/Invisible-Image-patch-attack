"""Aggregation rules on flattened client UPDATE vectors (numpy, no torch needed) + communication-cost utilities.
U has shape (n_clients, d).  Baselines: FedAvg, Krum/Multi-Krum, coordinate-wise median, trimmed mean, RFA, FLTrust."""
import numpy as np


def fedavg(U, w=None):
    w = np.ones(len(U)) / len(U) if w is None else np.asarray(w, float) / np.sum(w)
    return (w[:, None] * U).sum(0)


def _pairwise_sq(U):
    g = U @ U.T; d = np.diag(g); return np.maximum(d[:, None] + d[None, :] - 2 * g, 0)


def krum(U, f=1, multi=1):
    """Blanchard et al. 2017. score_i = sum of squared distances to the n-f-2 nearest others; average the `multi` best."""
    n = len(U); k = max(1, n - f - 2); D = _pairwise_sq(U); np.fill_diagonal(D, np.inf)
    scores = np.sort(D, axis=1)[:, :k].sum(1); sel = np.argsort(scores)[:max(1, multi)]
    return U[sel].mean(0), sel


def coordinate_median(U): return np.median(U, axis=0)


def trimmed_mean(U, beta=0.2):
    n = len(U); k = min(int(beta * n), (n - 1) // 2); S = np.sort(U, axis=0)
    return S[k:n - k].mean(0)


def rfa(U, w=None, iters=20, eps=1e-6):
    """Geometric median by Weiszfeld iterations (Pillutla et al.)."""
    w = np.ones(len(U)) / len(U) if w is None else np.asarray(w, float) / np.sum(w); z = (w[:, None] * U).sum(0)
    for _ in range(iters):
        d = np.maximum(np.linalg.norm(U - z, axis=1), eps); a = w / d; zn = (a[:, None] * U).sum(0) / a.sum()
        if np.linalg.norm(zn - z) < 1e-8: z = zn; break
        z = zn
    return z


def fltrust(U, g0):
    """Cao et al. 2021: trust score = ReLU(cos(update, server root update)); updates are rescaled to |g0|."""
    n0 = np.linalg.norm(g0) + 1e-12; nu = np.linalg.norm(U, axis=1) + 1e-12
    ts = np.maximum(0.0, (U @ g0) / (nu * n0))
    if ts.sum() <= 0: return g0.copy()
    return ((ts / ts.sum())[:, None] * (U * (n0 / nu)[:, None])).sum(0)


def aggregate(method, U, w=None, f=1, beta=0.2, g0=None):
    if method in ("fedavg", "fedprox", "fpmc"): return fedavg(U, w)
    if method == "krum": return krum(U, f, 1)[0]
    if method == "multikrum": return krum(U, f, max(1, len(U) - f))[0]
    if method == "median": return coordinate_median(U)
    if method == "trimmed_mean": return trimmed_mean(U, beta)
    if method == "rfa": return rfa(U, w)
    if method == "fltrust":
        if g0 is None: raise ValueError("FLTrust needs the server's root update g0")
        return fltrust(U, g0)
    raise ValueError(method)


def dp_clip_noise(u, clip, sigma, rng):
    """Clip the update to L2 norm `clip` and add Gaussian noise sigma*clip. No (epsilon, delta) accounting is done here, so
    this must NOT be reported as a differential-privacy guarantee."""
    u = u * min(1.0, clip / (np.linalg.norm(u) + 1e-12)); return u + rng.normal(0, sigma * clip, u.shape)


def communication_cost(n_params, rounds, n_clients, bytes_per_param=4):
    """C_total = R * N * (B_download + B_upload); the image/caption checks add no payload."""
    b = n_params * bytes_per_param
    return dict(bytes_download_per_client=b, bytes_upload_per_client=b, per_round_MB=n_clients * 2 * b / 2 ** 20,
                total_MB=rounds * n_clients * 2 * b / 2 ** 20)


# ---- torch state <-> vector helpers (torch imported lazily) ----
def state_to_vec(sd):
    return np.concatenate([v.detach().cpu().numpy().ravel().astype(np.float32) for k, v in sorted(sd.items()) if v.is_floating_point()])


def vec_to_state(vec, template):
    import torch
    out, i = {}, 0
    for k, v in sorted(template.items()):
        if v.is_floating_point():
            n = v.numel(); out[k] = torch.from_numpy(vec[i:i + n].reshape(tuple(v.shape))).to(v.dtype); i += n
        else: out[k] = v.clone()
    return out
