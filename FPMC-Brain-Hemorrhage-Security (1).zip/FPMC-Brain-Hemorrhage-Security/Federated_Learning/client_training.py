"""Multimodal (image + clinical-text embedding) model and local client training."""
import copy
import numpy as np, torch, torch.nn as nn, torch.nn.functional as F, timm
from Preprocessing.image_preprocessing import to_tensor_input
from Federated_Learning.fedprox import prox_term


class MultimodalNet(nn.Module):
    """image backbone (MaxViT) + projected text embedding -> fused head; also an image-only head (for image-only ASR)."""
    def __init__(self, backbone, n_classes, text_dim=768, proj=128, pretrained=True):
        super().__init__()
        self.b = timm.create_model(backbone, pretrained=pretrained, num_classes=0)
        fd = self.b.num_features
        self.tp = nn.Sequential(nn.Linear(text_dim, proj), nn.ReLU())
        self.head = nn.Linear(fd + proj, n_classes); self.ihead = nn.Linear(fd, n_classes); self.proj = proj

    def forward(self, img, txt=None, mode="fused"):
        f = self.b(img)
        if mode == "image": return self.ihead(f)
        t = self.tp(txt) if txt is not None else torch.zeros(f.shape[0], self.proj, device=f.device)
        return self.head(torch.cat([f, t], 1))


def local_train(model, X, E, y, epochs, lr, wd, batch, device, mu=0.0, global_params=None, text_drop=0.3, seed=0):
    """X uint8 (N,H,W), E float (N,D), y int. Returns the trained model (in place)."""
    model.train().to(device); opt = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=wd)
    rs = np.random.RandomState(seed); gp = [g.detach().to(device) for g in global_params] if global_params is not None else None
    scaler = torch.amp.GradScaler("cuda", enabled=device == "cuda")
    for _ in range(epochs):
        perm = rs.permutation(len(X))
        for i in range(0, len(perm), batch):
            b = perm[i:i + batch]
            if len(b) < 2: continue
            xb = torch.from_numpy(to_tensor_input(X[b])).to(device); eb = torch.from_numpy(E[b]).float().to(device); yb = torch.from_numpy(y[b]).long().to(device)
            eb = eb * (torch.rand(len(b), 1, device=device) > text_drop).float()
            with torch.autocast(device_type="cuda", dtype=torch.float16, enabled=device == "cuda"):
                loss = F.cross_entropy(model(xb, eb), yb) + F.cross_entropy(model(xb, None, "image"), yb)
            if gp is not None: loss = loss + prox_term(model, gp, mu)
            opt.zero_grad(set_to_none=True); scaler.scale(loss).backward(); scaler.step(opt); scaler.update()
    return model


@torch.no_grad()
def predict(model, X, E, mode="fused", device="cuda", bs=64):
    model.eval().to(device); out = []
    for i in range(0, len(X), bs):
        xb = torch.from_numpy(to_tensor_input(X[i:i + bs])).to(device)
        eb = torch.from_numpy(E[i:i + bs]).float().to(device) if E is not None else None
        out.append(model(xb, eb, mode).argmax(1).cpu().numpy())
    return np.concatenate(out) if out else np.array([], int)


from Defense.fpmc_defense import sanitize_client  # noqa: E402  (kept here for backward compatibility)
