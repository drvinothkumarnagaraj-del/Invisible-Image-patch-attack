"""Group-aware, class-stratified client partition. Identical to the code inlined in run_step3 (same RandomState consumption order),
so step 8 trains on exactly the same client datasets as step 3 when called with a fresh RandomState(seed)."""
import numpy as np


def partition_clients(grp, y, tr, n_clients, n_classes, rs):
    """tr: indices of training samples. All samples of one patient/group go to the same client. Returns a list of index arrays."""
    client_idx = [[] for _ in range(n_clients)]
    for c in range(n_classes):
        gs = sorted(set(grp[tr][y[tr] == c])); rs.shuffle(gs)
        for j, g in enumerate(gs): client_idx[j % n_clients] += list(tr[(grp[tr] == g)])
    return [np.array(ci, dtype=int) for ci in client_idx]
