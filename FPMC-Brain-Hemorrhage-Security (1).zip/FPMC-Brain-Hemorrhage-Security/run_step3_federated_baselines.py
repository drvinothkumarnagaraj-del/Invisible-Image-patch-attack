"""STEP 3 - federated comparison: FedAvg, FedProx, Krum, Multi-Krum, Median, Trimmed-mean, RFA, FLTrust and FPMC under
three scenarios: clean, data_poison (malicious client: FIBA trigger + dirty label + poisoned note) and model_poison
(malicious client submits a scaled, sign-flipped update). Same partitions / settings everywhere."""
import copy, time, joblib
import numpy as np, pandas as pd, torch
from common import *
from Attacks.fiba_attack import fiba
from Attacks.patch_generation import load_triggers
from Federated_Learning.client_training import MultimodalNet, local_train, predict, sanitize_client
from Federated_Learning.global_aggregation import aggregate, state_to_vec, vec_to_state, communication_cost
from Detection.maxvit_detection import CamFeatureExtractor
from Defense.fpmc_defense import FPMCDefense
from Evaluation.classification_metrics import classification_report
from Evaluation.attack_success_rate import asr_row
from Evaluation.protocol import assert_no_group_overlap, assert_no_aug_outside_train

cfg = load_config(); set_seed(cfg["seed"]); dev = device(); D = load_cache(cfg); fl = cfg["federated"]; A = cfg["attack"]
ACTION = cfg.get("defense", {}).get("flag_action", "quarantine")      # "quarantine" (realistic) | "restore_reference" (ORACLE upper bound)
Xc, y, E, Ep, caps, pcaps, split, grp, is_aug = D["Xc"], D["y"], D["E_orig"], D["E_pois"], D["caps"], list(D["poisoned_caps"]), D["split"], D["grp"], D["is_aug"]
EV = cfg["data"]["classes"].index(cfg["data"]["evade_class"]); NC = len(cfg["data"]["classes"]); S = cfg["data"]["img_size"]
if cfg["quick"]: fl = {**fl, "rounds": 2, "methods": ["fedavg", "krum", "fpmc"], "scenarios": ["clean", "data_poison"]}
trigs, _ = load_triggers(cfg["paths"]["patch_dir"], S, *D["clahe"].tolist(), n=A["trigger_pool"]); trig = trigs[0]
assert_no_group_overlap(grp, split); assert_no_aug_outside_train(split, is_aug)
tr = np.where(split == "train")[0]; te = np.where((split == "test") & ~is_aug)[0]
rs = np.random.RandomState(cfg["seed"])

# ---- partition (group-aware, class-stratified) ----
client_idx = [[] for _ in range(fl["n_clients"])]
for c in range(NC):
    gs = sorted(set(grp[tr][y[tr] == c])); rs.shuffle(gs)
    for j, g in enumerate(gs): client_idx[j % fl["n_clients"]] += list(tr[(grp[tr] == g)])
client_idx = [np.array(ci) for ci in client_idx]; MAL = fl["malicious_client"]
cand = [i for i in client_idx[MAL] if y[i] != EV]; pz = rs.choice(cand, int(len(cand) * A["poison_fraction"]), replace=False) if cand else np.array([], int)
root_pool = np.concatenate([client_idx[c] for c in range(fl["n_clients"]) if c != MAL]); root_idx = rs.choice(root_pool, max(8, int(fl["root_fraction"] * len(root_pool))), replace=False)
print("client sizes:", [len(c) for c in client_idx], "| poisoned samples:", len(pz), "| FLTrust root:", len(root_idx))

# poisoned copies (only used in data_poison)
Xa, Ea, ya, ca = Xc.copy(), E.copy(), y.copy(), list(caps)
for i in pz: Xa[i] = fiba(Xc[i], trig, A["fiba"]["alpha"], A["fiba"]["beta"]); Ea[i] = Ep[i]; ya[i] = EV; ca[i] = pcaps[i]

# ---- FPMC defence (needs step 2) ----
need_def = "fpmc" in fl["methods"]
if need_def:
    pdet = joblib.load(cache_path(cfg, "patch_detector.joblib"))["detector"]
    cx = CamFeatureExtractor(cfg["backbone"]["name"], tuple(cfg["backbone"]["gradcam_stages"]), dev, cfg["detection"]["cam_threshold"])
    cx.window = getattr(pdet, "window", None)      # POA-selected attention window saved in step 2
    defense = FPMCDefense(cx, pdet, cfg["detection"]["cam_threshold"], float(D["cos_tau"][0]))
_san = {}
def sanitized(scn):
    if scn not in _san:
        src = (Xa, Ea, ya, ca) if scn == "data_poison" else (Xc, E, y, caps)
        Xs, Es, ys = src[0].copy(), src[1].copy(), src[2].copy()
        Xs[tr], Es[tr], ys[tr], f_i, f_t, kp = sanitize_client(defense, src[0][tr], [caps[i] for i in tr], [src[3][i] for i in tr], E[tr], src[1][tr], y[tr], src[2][tr], ACTION)
        keep = np.ones(len(Xs), bool); keep[tr] = kp
        _san[scn] = (Xs, Es, ys, keep, f_i, f_t)
        print(f"  [FPMC:{ACTION}] {scn}: kept {int(kp.sum())}/{len(kp)} training samples; image-flag rate {f_i.mean():.2f}, text-flag rate {f_t.mean():.2f}")
        if scn == "data_poison":
            m = np.isin(tr, pz); print(f"  [FPMC] poisoned samples: image flag {f_i[m].mean():.2f}, note flag {f_t[m].mean():.2f}, removed {1 - kp[m].mean():.2f}; clean samples image flag {f_i[~m].mean():.2f}, removed {1 - kp[~m].mean():.2f}")
    return _san[scn]

def run(method, scn):
    base = MultimodalNet(cfg["backbone"]["name"], NC, text_dim=E.shape[1], pretrained=cfg["backbone"]["pretrained"]).to(dev)
    gsd = {k: v.detach().cpu().clone() for k, v in base.state_dict().items()}; gvec = state_to_vec(gsd); n_par = len(gvec)
    mu = fl["fedprox_mu"] if method in ("fedprox", "fpmc") else 0.0
    if method == "fpmc": Xs, Es, ys, keep, *_ = sanitized(scn if scn != "model_poison" else "clean")
    agg_t = []
    for r in range(fl["rounds"]):
        U, sizes = [], []
        for c in range(fl["n_clients"]):
            idx = client_idx[c]
            if method == "fpmc": idx = idx[keep[idx]]; Xk, Ek, yk = Xs[idx], Es[idx], ys[idx]
            elif c == MAL and scn == "data_poison": Xk, Ek, yk = Xa[idx], Ea[idx], ya[idx]
            else: Xk, Ek, yk = Xc[idx], E[idx], y[idx]
            m = copy.deepcopy(base); m.load_state_dict(gsd)
            gp = [p.detach().clone() for p in m.parameters()]
            local_train(m, Xk, Ek, yk, fl["local_epochs"], fl["lr"], fl["weight_decay"], fl["batch_size"], dev, mu, gp if mu > 0 else None, fl["text_dropout"], cfg["seed"] + r * 100 + c)
            u = state_to_vec({k: v.cpu() for k, v in m.state_dict().items()}) - gvec
            if c == MAL and scn == "model_poison": u = -fl["model_poison_boost"] * u
            U.append(u); sizes.append(len(Xk))
        U = np.stack(U); g0 = None
        if method == "fltrust":
            m = copy.deepcopy(base); m.load_state_dict(gsd)
            local_train(m, Xc[root_idx], E[root_idx], y[root_idx], fl["local_epochs"], fl["lr"], fl["weight_decay"], fl["batch_size"], dev, 0.0, None, fl["text_dropout"], cfg["seed"])
            g0 = state_to_vec({k: v.cpu() for k, v in m.state_dict().items()}) - gvec
        t0 = time.perf_counter(); agg = aggregate(method, U, np.maximum(np.asarray(sizes, float), 1.0), fl["n_byzantine"], fl["trimmed_beta"], g0); agg_t.append(time.perf_counter() - t0)   # FedAvg/FedProx/RFA weight clients by n_k
        gvec = gvec + agg; gsd = vec_to_state(gvec, gsd)
    base.load_state_dict(gsd); return base, np.mean(agg_t), n_par

rows = []
hem_te = te[y[te] != EV]
for scn in fl["scenarios"]:
    for method in fl["methods"]:
        print(f"\n--- {method} | {scn} ---"); model, agg_s, n_par = run(method, scn)
        pc = predict(model, Xc[te], E[te], "fused", dev); pci = predict(model, Xc[te], None, "image", dev)
        rep = classification_report(y[te], pc, EV)
        Xt = np.stack([fiba(Xc[i], trig, A["fiba"]["alpha"], A["fiba"]["beta"]) for i in hem_te])
        row = {"scenario": scn, "method": method, "accuracy (clean test)": rep["accuracy"], "macro-F1": rep["macro_f1"],
               "hemorrhage sensitivity": rep["hemorrhage_sensitivity"], "control specificity": rep["control_specificity"]}
        for mode, tag in (("image", "image-only"), ("fused", "fused")):
            base_p = predict(model, Xc[hem_te], E[hem_te] if mode == "fused" else None, mode, dev)
            att_p = predict(model, Xt, Ep[hem_te] if mode == "fused" else None, mode, dev)
            if method == "fpmc":
                Xd, fl_i = defense.sanitize_images(Xt); fl_t = defense.text_flags([caps[i] for i in hem_te], [pcaps[i] for i in hem_te], E[hem_te], Ep[hem_te])
                Ed = np.where(fl_t[:, None], 0.0 if ACTION == "quarantine" else E[hem_te], Ep[hem_te]); def_p = predict(model, Xd, Ed if mode == "fused" else None, mode, dev)
            else: def_p = att_p
            r_ = asr_row(base_p, att_p, def_p, EV); row[f"ASR {tag} (no inference defence)"] = r_["ASR no defence"]
            row[f"ASR {tag} (with inference defence)"] = r_["ASR with defence"] if method == "fpmc" else "n/a"
        cc = communication_cost(n_par, fl["rounds"], fl["n_clients"])
        row.update({"comm per round (MB)": round(cc["per_round_MB"], 1), "total comm (MB)": round(cc["total_MB"], 1), "mean aggregation time (s)": round(agg_s, 4)})
        rows.append(row)
        if (method, scn) in (("fedavg", "clean"), ("fedavg", "data_poison"), ("fpmc", "data_poison")):
            torch.save(model.state_dict(), cache_path(cfg, f"model_{method}_{scn}.pt"))
        del model; torch.cuda.empty_cache()
        save_table(pd.DataFrame(rows), cfg, "step3_federated_baselines", show=False)
save_table(pd.DataFrame(rows), cfg, "step3_federated_baselines")
print(f"\nn test = {len(te)} real images ({len(hem_te)} hemorrhage). Small n: read the intervals, do not over-claim.")
print("Krum/Median/Trimmed-mean/RFA/FLTrust defend the model-UPDATE channel; FPMC's image/text checks defend the DATA channel.")
