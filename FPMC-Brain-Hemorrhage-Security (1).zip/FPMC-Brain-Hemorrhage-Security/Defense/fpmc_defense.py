"""One object bundling the image defence (detector -> Grad-CAM mask -> inpaint) and the text defence (MCSIV rules).

ASSUMPTION (state it in the paper): the text check compares an incoming note with a TRUSTED REFERENCE copy of the same note
(e.g. a hash-verified original archived in the EHR). Without such a reference the cosine/assertion check cannot be applied."""
import numpy as np
from Defense.lama_inpainting import sanitize_flagged
from Defense.negation_detection import assertions, polarity_flip
from Detection.clinical_biobert import cosdist


class FPMCDefense:
    def __init__(self, cam_extractor, patch_detector, cam_thr=0.6, cos_tau=None, use_lama=True):
        self.cx, self.pd, self.cam_thr, self.cos_tau, self.use_lama = cam_extractor, patch_detector, cam_thr, cos_tau, use_lama

    def sanitize_images(self, X):
        f, cams = self.cx(X, return_cams=True); flags = self.pd.flag(f)
        return sanitize_flagged(X, cams, flags, self.cam_thr, self.use_lama), flags

    def text_flags(self, texts_ref, texts_in, E_ref, E_in):
        """Flag an incoming note that contradicts the trusted reference (assertion flip) or whose cosine similarity < tau."""
        flip = np.array([polarity_flip(assertions(a), assertions(b)) for a, b in zip(texts_ref, texts_in)])
        low = (1 - cosdist(E_ref, E_in)) < self.cos_tau if self.cos_tau is not None else np.zeros(len(flip), bool)
        return flip | low


def sanitize_client(defense, X, caps_ref, caps_in, E_ref, E_in, y_ref, y_in, action="quarantine"):
    """Client-side FPMC defence applied to a client's TRAINING data before local training.

    action="quarantine" (default, realistic): every sample flagged by the image OR text check is removed from training.
        Labels and embeddings are never replaced, so no ground truth leaks into the defence.
    action="restore_reference" (ORACLE upper bound): flagged samples get the trusted reference embedding AND the true
        reference label back. A real deployment does not know the true label of a poisoned sample - report this variant
        only as an upper bound, never as the headline result.
    Returns (X_sanitized, E, y, img_flag, txt_flag, keep_mask)."""
    Xs, img_flag = defense.sanitize_images(X)
    txt_flag = defense.text_flags(caps_ref, caps_in, E_ref, E_in); any_flag = np.asarray(img_flag, bool) | np.asarray(txt_flag, bool)
    if action == "quarantine":
        return Xs, np.array(E_in, copy=True), np.array(y_in, copy=True), img_flag, txt_flag, ~any_flag
    if action == "restore_reference":
        E = np.where(txt_flag[:, None], E_ref, E_in); y = np.where(any_flag, y_ref, y_in)
        return Xs, E, y, img_flag, txt_flag, np.ones(len(X), bool)
    raise ValueError(f"unknown action {action!r}")
