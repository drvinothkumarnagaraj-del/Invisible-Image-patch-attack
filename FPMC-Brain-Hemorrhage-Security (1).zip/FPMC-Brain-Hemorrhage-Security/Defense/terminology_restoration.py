"""Restore a manipulated caption. With a trusted reference note (EHR original) the original is returned. Without one a
rule-based reversal removes negation cues, restores a class-appropriate hemorrhage term and drops appended 'normal' labels."""
import re
from Defense.negation_detection import MENT_RE, NEG_PRE, NORMAL, HEM

CLASS_TERM = {"epidural": "epidural hematoma", "intracerebral": "intracerebral hemorrhage",
              "intraventricular": "intraventricular hemorrhage", "subdural": "subdural hematoma"}
_CUES = r"(?:no evidence of|no sign of|absence of|free of|negative for|without|not seen|no|not)\s+"


def rule_restore(text, cls=None):
    t = re.sub(r"\s*(?:Impression:\s*)?normal study,?\s*no h(?:a)?emorrh\w*\.?", "", text, flags=re.I)
    t = re.sub(r"\b[Hh](?:a)?emorrh\w*\s+is\s+absent\b", "Hemorrhage is present", t)
    t = re.sub(r"\bis absent\b", "is present", t, flags=re.I)
    t = re.sub(_CUES + r"(?=(?:[\w\-]+\s+){0,2}(?:" + HEM + r"))", "", t, flags=re.I)
    term = CLASS_TERM.get(cls)
    if term and not MENT_RE.search(t):
        t = re.sub(r"\b(?:normal finding\w*|lesion)\b", term, t, count=1, flags=re.I)
    return re.sub(r"\s{2,}", " ", t).strip()


def restore_caption(modified, original=None, cls=None):
    return original if original is not None else rule_restore(modified, cls)
