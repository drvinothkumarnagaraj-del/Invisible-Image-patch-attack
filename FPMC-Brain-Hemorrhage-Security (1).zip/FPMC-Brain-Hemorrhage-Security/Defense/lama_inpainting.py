"""CAM-guided inpainting: LaMa if installed (simple-lama-inpainting), OpenCV Telea otherwise."""
import numpy as np, cv2

_LAMA = None


def _get_lama():
    global _LAMA
    if _LAMA is None:
        try:
            from simple_lama_inpainting import SimpleLama
            _LAMA = SimpleLama()
        except Exception as e:
            print("LaMa unavailable -> OpenCV Telea fallback:", e); _LAMA = False
    return _LAMA


def cam_to_mask(cam, thr=0.6, dilate=5):
    m = (cam > thr).astype(np.uint8) * 255
    return cv2.dilate(m, np.ones((dilate, dilate), np.uint8)) if dilate > 1 else m


def inpaint(img, mask, use_lama=True):
    if mask.max() == 0: return img
    lama = _get_lama() if use_lama else False
    if lama:
        from PIL import Image
        out = lama(Image.fromarray(img).convert("RGB"), Image.fromarray(mask).convert("L"))
        return np.array(out.convert("L")).astype(np.uint8)[:img.shape[0], :img.shape[1]]
    return cv2.inpaint(img, mask, 3, cv2.INPAINT_TELEA)


def sanitize_flagged(X, cams, flags, thr=0.6, use_lama=True):
    """Inpaint only images the detector flagged (this decides the average latency)."""
    out = X.copy()
    for i in np.where(flags)[0]: out[i] = inpaint(X[i], cam_to_mask(cams[i], thr), use_lama)
    return out
