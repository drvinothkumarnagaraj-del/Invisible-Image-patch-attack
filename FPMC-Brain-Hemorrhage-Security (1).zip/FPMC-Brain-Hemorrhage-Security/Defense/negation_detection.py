"""Rule-based assertion analysis: is the hemorrhage statement present / absent / uncertain? Pure python."""
import re

HEM = r"h(?:a)?emorrh\w*|h(?:a)?ematoma\w*|bleed\w*|EDH|SDH|IVH|ICH"
SITE = r"intracerebral|intraparenchymal|intraventricular|subdural|epidural|extradural"
MENT_RE = re.compile(rf"\b(?:{HEM}|{SITE})\b", re.I)
NEG_PRE = re.compile(r"\b(?:no|not|without|negative|absence|absent|free of|denies|rule[sd]? out|ruled out|resolved|resolution)\b", re.I)
UNC_PRE = re.compile(r"\b(?:possible|probable|suspected|suspicious|questionable|likely|may represent|cannot be excluded|could represent|query)\b", re.I)
POST_NEG = re.compile(r"^\W*(?:\w+\W+){0,3}?(?:is absent|not seen|not identified|is excluded|was excluded|ruled out|resolved|absent)", re.I)
POST_UNC = re.compile(r"^\W*(?:\w+\W+){0,3}?(?:cannot be excluded|not excluded|is possible|is suspected|inconclusive)", re.I)
NORMAL = re.compile(r"\b(?:normal (?:study|brain|mri|finding\w*|scan)|unremarkable|no (?:acute )?abnormalit\w+)\b", re.I)


def _sentences(t):
    return [s for s in re.split(r"(?<=[.;!?])\s+|\n+", t) if s.strip()]


def assertions(text):
    """Set of {'present','absent','uncertain'} over all sentences ('none' if no hemorrhage statement is found)."""
    out = set()
    for s in _sentences(re.sub(r"\bwithout\s+contrast\b", "withcontrastnone", text, flags=re.I)):
        found = False
        for m in MENT_RE.finditer(s):
            found = True
            pre = re.split(r"[,;:]|\bbut\b|\bwith\b", s[:m.start()], flags=re.I)[-1]
            pre = " ".join(pre.split()[-6:]); post = s[m.end():m.end() + 40]
            if NEG_PRE.search(pre) or POST_NEG.search(post): out.add("absent")
            elif UNC_PRE.search(pre) or POST_UNC.search(post): out.add("uncertain")
            else: out.add("present")
        if not found and NORMAL.search(s): out.add("absent")
    return out or {"none"}


def polarity_flip(s_o, s_m, strict=False):
    """Clinically contradictory change. strict=True also flags present -> uncertain."""
    if "present" in s_o and "absent" in s_m and "absent" not in s_o: return True
    if "present" in s_o and "present" not in s_m and "uncertain" not in s_m: return True
    if "absent" in s_o and "present" not in s_o and "present" in s_m: return True
    if strict and "present" in s_o and "present" not in s_m and "uncertain" in s_m: return True
    return False


def jaccard(a, b):
    A, B = set(re.findall(r"\w+", a.lower())), set(re.findall(r"\w+", b.lower()))
    return len(A & B) / len(A | B) if (A | B) else 1.0


def inconsistent(s_m, pred_is_hem):
    """report vs image-derived decision (hedged reports never count as inconsistent)."""
    if pred_is_hem and "absent" in s_m and "present" not in s_m: return True
    if (not pred_is_hem) and "present" in s_m and "absent" not in s_m: return True
    return False
