"""Dataset loading. The index CSV (from the verify/expand script) needs: ID, Caption, split, class, image_path,
is_augmented, source_id. Real images are never mixed with augmented copies of the same source across splits."""
import os
import numpy as np, pandas as pd, cv2


def _resolve(root, p):
    p = str(p)
    if os.path.isabs(p) and os.path.exists(p): return p
    for cand in (os.path.join(root, p), os.path.join(root, os.path.basename(p))):
        if os.path.exists(cand): return cand
    return os.path.join(root, p)


def load_dataset(cfg):
    P, dc = cfg["paths"], cfg["data"]
    df = pd.read_csv(P["index_csv"], encoding="utf-8", encoding_errors="replace")
    df = df[df["class"].isin(dc["classes"])].reset_index(drop=True)
    cls_to_i = {c: i for i, c in enumerate(dc["classes"])}
    X, keep, missing = [], [], []
    for i, r in df.iterrows():
        path = _resolve(P["dataset_root"], r["image_path"])
        im = cv2.imread(path, cv2.IMREAD_GRAYSCALE)
        if im is None: missing.append(path); continue
        X.append(cv2.resize(im, (dc["img_size"],) * 2, interpolation=cv2.INTER_AREA)); keep.append(i)
    if missing: print(f"WARNING: {len(missing)} unreadable images skipped, e.g. {missing[:2]}")
    df = df.loc[keep].reset_index(drop=True)
    y = df["class"].map(cls_to_i).values.astype(int)
    counts = {c: int((y == i).sum()) for c, i in cls_to_i.items()}
    print("images per class:", counts)
    empty = [c for c, n in counts.items() if n == 0]
    if empty and dc.get("require_all_classes", True):
        raise RuntimeError(f"No images for {empty}. Attack-success results would be meaningless; rebuild the dataset first.")
    # NaN-safe on every pandas version (pandas>=3 keeps missing values as NaN instead of the text "nan")
    is_aug = df["is_augmented"].fillna(0).astype(str).str.strip().str.lower().isin(["true", "1", "1.0", "yes"]).values if "is_augmented" in df else np.zeros(len(df), bool)
    ids = df["ID"].astype(str)
    src = df["source_id"].fillna("").astype(str).str.strip() if "source_id" in df else ids
    grp = np.where(src.str.lower().isin(["", "nan", "none"]), ids, src)       # real image -> its own ID; augmented copy -> ID of its source
    split = df["split"].astype(str).str.lower().replace({"valid": "val", "validation": "val"}).values
    return dict(X=np.stack(X), y=y, caps=df["Caption"].astype(str).tolist(), split=split, grp=grp, is_aug=is_aug,
                ids=df["ID"].astype(str).values)


def to_tensor_input(X):
    """uint8 (N,H,W) -> float32 (N,3,H,W) in [-1,1] (numpy; convert with torch.from_numpy)."""
    x = (X.astype(np.float32) / 255.0 - 0.5) / 0.5
    return np.repeat(x[:, None], 3, axis=1)
