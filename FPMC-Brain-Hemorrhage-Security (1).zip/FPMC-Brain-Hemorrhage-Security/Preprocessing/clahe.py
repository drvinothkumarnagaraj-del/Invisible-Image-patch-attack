"""CLAHE enhancement with parameters selected by the Pelican Optimization Algorithm (POA). numpy/cv2 only."""
import numpy as np, cv2


def clahe_apply(img, clip=2.0, tile=8):
    return cv2.createCLAHE(clipLimit=float(clip), tileGridSize=(int(round(tile)),) * 2).apply(img)


def _entropy(img):
    h = np.bincount(img.ravel(), minlength=256).astype(np.float64)
    p = h / h.sum(); p = p[p > 0]
    return float(-(p * np.log2(p)).sum())


def clahe_score(orig, enh):
    """Higher is better: information (entropy) + edge strength, with a penalty for noise amplification."""
    ent = _entropy(enh) / 8.0
    gx, gy = cv2.Sobel(enh, cv2.CV_32F, 1, 0), cv2.Sobel(enh, cv2.CV_32F, 0, 1)
    edge = float(np.mean(np.hypot(gx, gy))) / 255.0
    no, ne = cv2.Laplacian(orig, cv2.CV_32F).var(), cv2.Laplacian(enh, cv2.CV_32F).var()
    return ent + edge - 0.02 * max(0.0, ne / (no + 1e-6) - 4.0)


def pelican_optimize(fitness, bounds, pop=8, iters=10, seed=0):
    """Pelican Optimization Algorithm (maximisation). bounds: list of (lo, hi). Returns (best_x, best_f, history)."""
    rs = np.random.RandomState(seed)
    lo, hi = np.array([b[0] for b in bounds], float), np.array([b[1] for b in bounds], float)
    X = lo + rs.rand(pop, len(bounds)) * (hi - lo)
    F = np.array([fitness(x) for x in X]); hist = [float(F.max())]
    for t in range(iters):
        prey = X[rs.randint(pop)].copy(); fprey = fitness(prey)
        for i in range(pop):                                   # phase 1: moving towards prey
            I = rs.randint(1, 3)
            xn = X[i] + rs.rand(len(bounds)) * (prey - I * X[i]) if fprey > F[i] else X[i] + rs.rand(len(bounds)) * (X[i] - prey)
            xn = np.clip(xn, lo, hi); fn = fitness(xn)
            if fn > F[i]: X[i], F[i] = xn, fn
        for i in range(pop):                                   # phase 2: winging on the water surface
            xn = np.clip(X[i] + 0.2 * (1 - (t + 1) / iters) * (2 * rs.rand(len(bounds)) - 1) * X[i], lo, hi); fn = fitness(xn)
            if fn > F[i]: X[i], F[i] = xn, fn
        hist.append(float(F.max()))
    b = int(F.argmax())
    return X[b], float(F[b]), hist


def optimize_clahe(images, bounds_clip=(1.0, 6.0), bounds_tile=(4, 16), pop=6, iters=8, seed=0):
    def fit(p):
        return float(np.mean([clahe_score(im, clahe_apply(im, p[0], p[1])) for im in images]))
    x, f, hist = pelican_optimize(fit, [bounds_clip, bounds_tile], pop, iters, seed)
    return float(x[0]), int(round(x[1])), f, hist
