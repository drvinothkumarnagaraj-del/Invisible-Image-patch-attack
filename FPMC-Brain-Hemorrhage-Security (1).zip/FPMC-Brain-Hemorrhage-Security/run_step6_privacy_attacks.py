"""STEP 6 - privacy attacks on model updates / the trained model: gradient inversion, label inference, membership inference.
Not evaluated here (state as limitation): client-level inference, secure aggregation, formal differential privacy."""
import os
os.environ["TIMM_FUSED_ATTN"] = "0"     # fused attention kernels have no double-backward, which gradient inversion needs
import numpy as np, pandas as pd, torch
from common import *
from Federated_Learning.client_training import MultimodalNet
from Privacy.gradient_inversion import invert, reconstruction_quality
from Privacy.label_inference import last_layer_bias_grad, infer_label_from_bias_grad
from Privacy.membership_inference import mia_metrics, per_sample_loss
from Evaluation.confidence_intervals import fmt_rate

cfg = load_config(); set_seed(cfg["seed"]); dev = device(); D = load_cache(cfg); pv = cfg["privacy"]
Xc, y, split, is_aug = D["Xc"], D["y"], D["split"], D["is_aug"]; NC = len(cfg["data"]["classes"]); rs = np.random.RandomState(cfg["seed"])
m = MultimodalNet(cfg["backbone"]["name"], NC, text_dim=D["E_orig"].shape[1], pretrained=False)
m.load_state_dict(torch.load(cache_path(cfg, "model_fedavg_clean.pt"))); m.to(dev).eval()
tr = np.where((split == "train") & ~is_aug)[0]; ho = np.where((split != "train") & ~is_aug)[0]

# ---- membership inference (members = real training images, non-members = real held-out images; balanced) ----
n = min(len(tr), len(ho)); a, b = rs.choice(tr, n, replace=False), rs.choice(ho, n, replace=False)
r = mia_metrics(per_sample_loss(m, Xc[a], y[a], dev), per_sample_loss(m, Xc[b], y[b], dev))
save_table(pd.DataFrame([{"attack": "loss-threshold membership inference", "AUC": round(r["auc"], 3), "advantage (max TPR-FPR)": round(r["advantage"], 3),
                          "TPR@5%FPR": round(r["tpr_at_5pct_fpr"], 3), "members": r["n_members"], "non-members": r["n_nonmembers"]}]), cfg, "step6a_membership_inference")

# ---- label inference from the batch-size-1 gradient ----
idx = rs.choice(tr, min(len(tr), 100), replace=False)
ok = [infer_label_from_bias_grad(last_layer_bias_grad(m, Xc[i], y[i], dev)) == y[i] for i in idx]
save_table(pd.DataFrame([{"attack": "label inference (iDLG, batch size 1)", "label recovery accuracy": fmt_rate(float(np.mean(ok)), len(ok))}]), cfg, "step6b_label_inference")

# ---- gradient inversion, with and without update clipping + noise (empirical only) ----
sel = rs.choice(tr, min(len(tr), pv["n_inversion_images"]), replace=False); rows = []
for sigma in pv["dp_noise_sigmas"]:
    q = []
    for i in sel:
        rec = invert(m, Xc[i], y[i], dev, pv["inversion_iters"], pv["inversion_lr"], noise_sigma=sigma, clip=pv["dp_clip"] if sigma > 0 else None, seed=int(i))
        q.append(reconstruction_quality(Xc[i], rec))
    rows.append({"gradient perturbation": "none (plain gradient)" if sigma == 0 else f"clip={pv['dp_clip']}, noise sigma={sigma}", "n images": len(q),
                 "PSNR dB (mean)": round(float(np.mean([t["psnr"] for t in q])), 2), "SSIM (mean)": round(float(np.mean([t["ssim"] for t in q])), 3),
                 "LPIPS (mean)": round(float(np.nanmean([t["lpips"] for t in q])), 3) if not all(np.isnan(t["lpips"]) for t in q) else "n/a"})
save_table(pd.DataFrame(rows), cfg, "step6c_gradient_inversion")
print("\nClip+noise above is an EMPIRICAL probe only. No (epsilon, delta) accounting is done, so do not claim differential privacy.")
print("Unevaluated threats to list as limitations: client-level inference, secure aggregation, formal DP.")
