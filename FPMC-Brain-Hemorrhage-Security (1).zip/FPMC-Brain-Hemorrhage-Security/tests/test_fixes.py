"""Tests for the corrected evaluation protocol (no torch needed).   python tests/test_fixes.py"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import numpy as np


def test_split_audit_catches_leakage():
    from Evaluation.protocol import assert_no_group_overlap, assert_no_aug_outside_train, data_audit, real_split_indices
    split = np.array(["train", "train", "val", "test", "train"]); grp = np.array(["a", "a", "b", "c", "d"]); aug = np.array([0, 1, 0, 0, 0], bool)
    assert_no_group_overlap(grp, split); assert_no_aug_outside_train(split, aug)
    for bad in (lambda: assert_no_group_overlap(np.array(["a", "a", "a", "c", "d"]), split),
                lambda: assert_no_aug_outside_train(split, np.array([0, 0, 0, 1, 0], bool))):
        try: bad(); raise AssertionError("leak not detected")
        except RuntimeError: pass
    P = real_split_indices(split, aug); assert list(P["train"]) == [0, 4] and list(P["test"]) == [3]       # augmented copy (index 1) excluded
    a = data_audit(np.array([0, 1, 0, 1, 0]), split, aug, ["control", "bleed"]); assert a["n"].sum() == 5


def test_detector_threshold_from_validation_only():
    from Evaluation.detection_metrics import fit_detector_split, tpr_fpr_auc
    rs = np.random.RandomState(0); d = 6
    tr_c, tr_a = rs.normal(0, 1, (600, d)), rs.normal(1.5, 1, (600, d))
    va_c, te_c, te_a = rs.normal(0, 1, (4000, d)), rs.normal(0, 1, (20000, d)), rs.normal(1.5, 1, (20000, d))
    det, thr = fit_detector_split(tr_c, tr_a, va_c, 0.05, 0)
    r = tpr_fpr_auc(det.predict_proba(te_c)[:, 1], det.predict_proba(te_a)[:, 1], thr)
    assert abs(r["fpr"] - 0.05) < 0.012, r["fpr"]                       # honest FPR on unseen data matches the target
    assert r["tpr"] > 0.5 and r["auc"] > 0.85
    det, thr = fit_detector_split(tr_c, rs.normal(0, 1, (600, d)), va_c, 0.05, 0)       # attack indistinguishable from clean
    r = tpr_fpr_auc(det.predict_proba(te_c)[:, 1], det.predict_proba(te_a * 0 + rs.normal(0, 1, te_a.shape))[:, 1], thr)
    assert abs(r["auc"] - 0.5) < 0.02 and abs(r["tpr"] - r["fpr"]) < 0.015      # chance-level detector is reported as chance


def test_fedavg_weights_by_client_size():
    from Federated_Learning.global_aggregation import aggregate
    U = np.array([[1.0, 1.0], [3.0, 3.0]]); w = np.array([30.0, 10.0])
    assert np.allclose(aggregate("fedavg", U, w), [1.5, 1.5])           # (30*1 + 10*3) / 40
    assert np.allclose(aggregate("fedprox", U, None), [2.0, 2.0])


class _Stub:
    def __init__(self, img, txt): self.i, self.t = np.asarray(img, bool), np.asarray(txt, bool)
    def sanitize_images(self, X): return X.copy(), self.i
    def text_flags(self, *a): return self.t


def test_quarantine_uses_no_ground_truth():
    from Defense.fpmc_defense import sanitize_client
    X = np.zeros((4, 8, 8), np.uint8); E_ref, E_in = np.ones((4, 3)), np.full((4, 3), 9.0); y_ref, y_in = np.array([1, 1, 1, 1]), np.array([0, 0, 1, 1])
    d = _Stub([1, 0, 0, 0], [0, 1, 0, 0])
    Xs, E, y, fi, ft, keep = sanitize_client(d, X, ["a"] * 4, ["b"] * 4, E_ref, E_in, y_ref, y_in)               # default action
    assert list(keep) == [False, False, True, True]                      # flagged by either check -> removed
    assert (E == E_in).all() and (y == y_in).all()                       # nothing restored from the reference
    Xs, E, y, fi, ft, keep = sanitize_client(d, X, ["a"] * 4, ["b"] * 4, E_ref, E_in, y_ref, y_in, "restore_reference")
    assert keep.all() and list(y) == [1, 1, 1, 1] and (E[1] == 1).all() and (E[0] == 9).all()    # ORACLE variant restores truth
    try: sanitize_client(d, X, ["a"] * 4, ["b"] * 4, E_ref, E_in, y_ref, y_in, "bogus"); raise AssertionError
    except ValueError: pass


def _cams(n, rs, bump=None, H=64):
    c = rs.rand(n, H, H).astype(np.float32) * 0.3
    if bump is not None:
        x, y, h, w = bump; r0, r1, c0, c1 = int(y * H), int((y + h) * H), int(x * H), int((x + w) * H)
        c[:, r0:r1, c0:c1] += rs.rand(n, r1 - r0, c1 - c0).astype(np.float32) * 0.5          # attack leaves a trace only here
    return np.clip(c, 0, 1)


def test_poa_window_finds_where_the_attack_leaves_a_trace():
    from Detection.poa_window import search_window, window_stats, decode, _separability, N_WINDOW_FEATURES
    planted = (0.1, 0.55, 0.3, 0.3)
    def overlap(a, b):                                                                     # intersection area of two (x, y, h, w) windows
        iw = max(0.0, min(a[0] + a[3], b[0] + b[3]) - max(a[0], b[0])); ih = max(0.0, min(a[1] + a[2], b[1] + b[2]) - max(a[1], b[1])); return iw * ih
    for p in ([-1, -1, 5, 5], [0.9, 0.9, 0.2, 0.2], [0.3, 0.3, 0.5, 0.5]):               # decode always yields a valid window
        x, y, h, w = decode(np.array(p, float)); assert 0 <= x and x + w <= 1.0001 and 0 <= y and y + h <= 1.0001 and h >= 0.2 and w >= 0.2
    for seed in range(3):
        rs = np.random.RandomState(seed); clean, sim = _cams(60, rs), _cams(60, rs, planted)
        assert window_stats(clean, (0, 0, 1, 1)).shape == (60, N_WINDOW_FEATURES)
        win, fit, hist, whole = search_window(clean, sim, 0.6, pop=8, iters=10, seed=seed)
        far = _separability((0.6, 0.0, 0.3, 0.3), clean, sim, 0.6, seed)                  # a window the attack never touches
        assert far < 0.75, far                                                            # ...carries no signal
        assert fit > 0.95 and overlap(win, planted) > 0, (seed, win, fit)                 # chosen window sits on the trace
        assert hist[-1] >= hist[0]                                                        # POA never gets worse
        assert win[2] * win[3] <= 0.25                                                    # size tie-breaker keeps it local


def test_poa_window_null_attack_has_no_signal():
    from Detection.poa_window import search_window
    rs = np.random.RandomState(1); a, b = _cams(60, rs), _cams(60, rs)                    # "attack" leaves no trace at all
    win, fit, hist, whole = search_window(a, b, 0.6, pop=6, iters=6, seed=0)
    assert fit < 0.75, fit                                                                # search must not invent separability


def test_results_folder_must_be_outside_dataset_folder():
    import tempfile, yaml
    from common import load_config
    with tempfile.TemporaryDirectory() as t:
        ds = os.path.join(t, "FPMC_BH_sorted", "balanced_526"); os.makedirs(ds)
        base = dict(paths=dict(dataset_root=ds, index_csv=os.path.join(ds, "i.csv"), patch_dir=t, cache_dir=os.path.join(t, "cache")), seed=1)
        def go(**over):
            c = {**base, "paths": {**base["paths"], **over}}; p = os.path.join(t, "c.yaml"); yaml.safe_dump(c, open(p, "w")); return load_config(p)
        for bad in (dict(out_dir=os.path.join(ds, "fpmc_results")), dict(out_dir=ds), dict(results_root=ds, run_name="r1")):
            try: go(**bad); raise AssertionError("results inside the dataset folder were accepted")
            except ValueError: pass
        good = go(results_root=os.path.join(t, "FPMC_Final_Results"), run_name="final_run1")
        assert good["paths"]["out_dir"].endswith(os.path.join("FPMC_Final_Results", "final_run1")) and os.path.isdir(good["paths"]["out_dir"])


if __name__ == "__main__":
    n = 0
    for k, v in sorted(globals().items()):
        if k.startswith("test_") and callable(v): v(); print("ok", k); n += 1
    print(n, "tests passed")
