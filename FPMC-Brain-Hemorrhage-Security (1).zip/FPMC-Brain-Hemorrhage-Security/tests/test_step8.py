"""Tests for step 8 (numpy + cryptography + scipy only).   python -m pytest tests -q"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import numpy as np


def test_secure_aggregation_exact_hides_individuals_and_breaks_on_dropout():
    from Privacy.secure_aggregation import secure_weighted_mean, signed_view
    r = np.random.default_rng(0); n, d = 5, 5000; U = (r.normal(size=(n, d)) * 0.01).astype(np.float32); w = np.array([3., 1, 2, 2, 4])
    agg, masked, sa, _ = secure_weighted_mean(U, w, clip=8.0, scale_bits=24)
    true = (U.astype(np.float64) * (w / w.sum())[:, None]).sum(0)
    assert np.abs(agg - true).max() <= n * 0.5 / 2 ** 24 * 1.01
    assert abs(np.corrcoef(signed_view(masked[0]), U[0] * (w[0] / w.sum()))[0, 1]) < 0.1
    bad = sa.aggregate(masked[1:]); assert np.abs(bad - (U[1:].astype(np.float64) * (w[1:] / w.sum())[:, None]).sum(0)).max() > 1.0


def test_secure_aggregation_rejects_unrepresentable_clip():
    from Privacy.secure_aggregation import quantize
    try: quantize(np.zeros(3), clip=200.0, scale_bits=24); assert False
    except ValueError: pass


def test_dp_accountant_is_conservative_and_calibrates():
    from Privacy.dp_accountant import epsilon, exact_gaussian_eps, calibrate_noise_multiplier
    prev = 1e9
    for z in (0.5, 1.0, 2.0, 4.0):
        e, ex = epsilon(z, 10, 1e-5)[0], exact_gaussian_eps(z, 10, 1e-5); assert e >= ex - 1e-9 and e < 1.3 * ex and e < prev; prev = e
    z = calibrate_noise_multiplier(8.0, 10, 1e-5); assert abs(epsilon(z, 10, 1e-5)[0] - 8.0) < 0.01
    assert epsilon(0.0, 10)[0] == float("inf") and exact_gaussian_eps(0.01, 10) == float("inf")
    assert epsilon(1.0, 20)[0] > epsilon(1.0, 10)[0]


def test_dp_aggregate_clips_and_noise_scale():
    from Privacy.dp_accountant import dp_fedavg_aggregate
    r = np.random.default_rng(0); U = r.normal(size=(4, 20000)) * np.array([1., 5., 0.1, 2.])[:, None]
    m, info = dp_fedavg_aggregate(U, clip=10.0, z=0.0, rng=r); assert np.allclose(m, U.mean(0)) is False or info["clipped_fraction"] > 0
    nrm = np.linalg.norm(U, axis=1); Uc = U * np.minimum(1, 10.0 / nrm)[:, None]; assert np.allclose(m, Uc.mean(0))
    m2, _ = dp_fedavg_aggregate(U, clip=10.0, z=2.0, rng=np.random.default_rng(1)); assert abs(np.std(m2 - Uc.mean(0)) - 2.0 * 10.0 / 4) < 0.3


def test_channel_rejects_every_tampering_without_false_alarms():
    from Privacy import channel_security as ch
    rows, fr = ch.evaluate_channel(n_trials=5, n_floats=2000, n_clients=5, seed=0)
    assert fr == 0 and len(rows) == len(ch.TAMPERS)
    for r in rows: assert r["rejected_with_authenticated_encryption"] == r["trials"], r
    keys = ch.establish_keys(2); m = ch.seal(keys[0], 0, 3, 7, b"x" * 100)
    s = ch.ServerEndpoint(keys, 3); assert s.open(m) == (0, b"x" * 100)
    try: s.open(m); assert False
    except ch.ChannelError: pass


def test_client_inference_scores_detect_planted_signal_and_chance():
    from Privacy.client_inference import membership_from_delta, class_composition_inference, summarize_clients
    r = np.random.default_rng(0); d = r.normal(size=400); d[:200] -= 3.0
    m = membership_from_delta(d, np.arange(200), np.arange(200, 400), r); assert m["auc"] > 0.95
    n = membership_from_delta(r.normal(size=400), np.arange(200), np.arange(200, 400), r); assert 0.4 < n["auc"] < 0.6
    assert membership_from_delta(d, np.arange(3), np.arange(200, 400), r) is None and summarize_clients([None])["clients"] == 0
    H = np.array([[9, 1, 0, 0, 0], [0, 6, 4, 0, 0], [0, 0, 1, 8, 1.]]); c = class_composition_inference(H * 0.1 + r.normal(size=H.shape) * 0.01, H)
    assert c["top_class_hit"] == 1.0 and c["spearman_mean"] > 0.8


def test_partition_is_group_aware_and_deterministic():
    from Federated_Learning.partition import partition_clients
    r = np.random.default_rng(0); n = 200; y = r.integers(0, 3, n); grp = np.array([f"g{i // 2}" for i in range(n)]); y = np.repeat(y[::2], 2)
    tr = np.arange(n)
    a = partition_clients(grp, y, tr, 5, 3, np.random.RandomState(1)); b = partition_clients(grp, y, tr, 5, 3, np.random.RandomState(1))
    assert all(np.array_equal(i, j) for i, j in zip(a, b)) and sum(len(x) for x in a) == n
    owner = {}
    for c, ix in enumerate(a):
        for i in ix: owner.setdefault(grp[i], set()).add(c)
    assert all(len(v) == 1 for v in owner.values())


if __name__ == "__main__":
    for k, f in list(globals().items()):
        if k.startswith("test_"): f(); print("ok", k)
