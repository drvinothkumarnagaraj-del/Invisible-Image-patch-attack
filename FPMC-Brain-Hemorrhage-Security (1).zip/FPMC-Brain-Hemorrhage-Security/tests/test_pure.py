"""Tests for everything that does not need torch.   python -m pytest tests -q   (or: python tests/test_pure.py)"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import numpy as np, cv2


def rimg(seed=0, s=128):
    r = np.random.default_rng(seed); return cv2.GaussianBlur(r.integers(0, 255, (s, s)).astype(np.uint8), (0, 0), 3)


def test_clahe_and_poa():
    from Preprocessing.clahe import optimize_clahe, pelican_optimize
    x, f, h = pelican_optimize(lambda p: -((p[0] - 2) ** 2 + (p[1] - 3) ** 2), [(0, 5), (0, 5)], 10, 20, 0)
    assert abs(x[0] - 2) < 0.5 and abs(x[1] - 3) < 0.5 and h[-1] >= h[0]
    clip, tile, f, _ = optimize_clahe([rimg(i) for i in range(3)], pop=4, iters=3); assert 1 <= clip <= 6 and 4 <= tile <= 16


def test_fiba_invisible_and_variants():
    from Attacks.fiba_attack import fiba, psnr
    from Attacks.patch_generation import spatial_patch, fiba_band, sample_attack_params, apply_attack, ADAPTIVE_KINDS
    x, t = rimg(1), rimg(2)
    assert psnr(x, fiba(x, t, 0.3, 0.1)) > 30
    assert not np.array_equal(x, fiba_band(x, t, 0.3, 0.1, 0.4)) and not np.array_equal(x, spatial_patch(x, t, 0.2, "center", 0.3))
    rs = np.random.RandomState(0)
    for k in ADAPTIVE_KINDS: assert apply_attack(x, t, sample_attack_params(k, rs), rs).shape == x.shape


def test_detector_aware_attack_loop():
    from Attacks.adaptive_attacks import detector_aware_attack
    x = rimg(3); t = [rimg(4)]
    r = detector_aware_attack(x, t, lambda im: int(im.mean() > x.mean() + 0.01), lambda im: 0.2, 1, 0.5, 40, 25.0, np.random.RandomState(0))
    assert r is not None and "evaded" in r and r["psnr"] >= 25.0


def test_aggregators():
    from Federated_Learning.global_aggregation import fedavg, krum, coordinate_median, trimmed_mean, rfa, fltrust, aggregate, communication_cost, dp_clip_noise
    rs = np.random.RandomState(0); honest = rs.normal(1.0, 0.05, (6, 50)); U = np.vstack([honest, -20 * np.ones((1, 50))])
    assert fedavg(U).mean() < 0                                  # FedAvg is dragged by the attacker
    for name, v in (("krum", krum(U, 1)[0]), ("median", coordinate_median(U)), ("trim", trimmed_mean(U, 0.2)), ("rfa", rfa(U))):
        assert v.mean() > 0.8, name                              # robust rules stay near the honest mean
    assert krum(U, 1)[1][0] != 6
    g0 = np.ones(50); out = fltrust(U, g0); assert out.mean() > 0.8
    assert aggregate("multikrum", U, f=1).mean() > 0.8 and aggregate("fedprox", U).shape == (50,)
    cc = communication_cost(1_000_000, 10, 5); assert abs(cc["total_MB"] - 10 * 5 * 2 * 4e6 / 2 ** 20) < 1e-6
    u = dp_clip_noise(np.ones(100) * 10, 1.0, 0.0, rs); assert abs(np.linalg.norm(u) - 1.0) < 1e-6


def test_negation_and_flip():
    from Defense.negation_detection import assertions, polarity_flip, inconsistent
    assert assertions("MRI confirms intracerebral hemorrhage.") == {"present"}
    assert assertions("MRI does not confirm intracerebral hemorrhage.") == {"absent"}
    assert assertions("Axial MRI without contrast showing intraparenchymal hemorrhage") == {"present"}
    assert assertions("Axial MRI with possible hemorrhage") == {"uncertain"} and assertions("Normal brain MRI") == {"absent"}
    assert polarity_flip({"present"}, {"absent"}) and not polarity_flip({"present"}, {"uncertain"}) and polarity_flip({"present"}, {"uncertain"}, strict=True)
    assert inconsistent({"absent"}, True) and not inconsistent({"uncertain"}, True)


def test_poisoning_kinds_and_restoration():
    from Attacks.label_poisoning import SEEN, UNSEEN, adaptive_caption_attack, poison_sub_neg
    from Defense.negation_detection import assertions, polarity_flip
    from Defense.terminology_restoration import restore_caption
    c = "Axial T2 MRI showing acute subdural hematoma in the left hemisphere."
    for k in ("negation", "substitution (normal finding)", "semantic softening", "present->absent", "appended normal-study label"):
        assert polarity_flip(assertions(c), assertions(SEEN[k](c))), k
    for k, fn in UNSEEN.items(): assert fn(c) and fn(c) != c, k
    assert polarity_flip(assertions(c), assertions(poison_sub_neg(c)))
    assert restore_caption("x", original=c) == c
    r = restore_caption("Axial T2 MRI showing acute no evidence of subdural hematoma in the left hemisphere.", None, "subdural")
    assert assertions(r) == {"present"}, r
    r2 = restore_caption("Axial T2 MRI showing acute normal finding in the left hemisphere.", None, "subdural"); assert "subdural" in r2.lower()
    def emb(texts):                                             # toy bag-of-words embedding
        vocab = {}; M = np.zeros((len(texts), 400))
        for i, t in enumerate(texts):
            for w in t.lower().split(): M[i, hash(w) % 400] += 1
        return M
    a = adaptive_caption_attack(c, emb); assert a and a["cosine"] > 0.3 and polarity_flip(assertions(c), assertions(a["text"]))


def test_stats_and_detection_protocol():
    from Evaluation.confidence_intervals import wilson, boot_auc, fmt_rate
    from Evaluation.detection_metrics import nested_detection, summarize_detection, fit_detector_calibrated
    from Evaluation.attack_success_rate import conditional_asr
    lo, hi = wilson(0, 11); assert lo < 1e-9 and 0.2 < hi < 0.3      # 0/11 -> upper bound about 0.26
    rs = np.random.default_rng(0); n = 60; fc = rs.normal(0, 1, (n, 5)); fs = rs.normal(1.5, 1, (n, 5)); fa = {"a": rs.normal(1.5, 1, (n, 5))}
    cf, cs, af, asc = nested_detection(fc, fs, fa, 2, 5, 0.05, 0); r = summarize_detection(cf, cs, af, asc)["a"]
    assert r["auc"] > 0.9 and r["fpr"] < 0.25
    det, thr = fit_detector_calibrated(fc, fs, 0.05, 0); assert 0 < thr <= 1
    a, n_, nat = conditional_asr([1, 1, 0, 2], [0, 1, 0, 0], 0); assert n_ == 3 and abs(a - 2 / 3) < 1e-9 and nat == 0.25


def test_caption_protocol():
    from Detection.clinical_biobert import evaluate_caption_detection
    from Evaluation.step_helpers import CAL_BENIGN, BENIGN_FAMILIES
    rg = np.random.default_rng(1); n = 150; G = np.repeat(np.arange(50), 3)
    Fb = {k: np.c_[rg.normal(.01, .005, n), rg.normal(.2, .1, n), np.zeros(n)] for k in BENIGN_FAMILIES}
    Fs = {k: np.c_[rg.normal(.02, .01, n), rg.normal(.1, .05, n), np.ones(n)] for k in ("a", "b")}
    Fu = {"u1": np.c_[rg.normal(.02, .01, n), rg.normal(.1, .05, n), np.ones(n)]}
    rows = evaluate_caption_detection(Fb, Fs, Fu, G, CAL_BENIGN, 0.05, 3, 0)
    assert len(rows) == 4 * 3 and all("attack set" in r for r in rows)


def test_privacy_metrics():
    from Privacy.membership_inference import mia_metrics
    from Privacy.gradient_inversion import ssim, psnr_f
    from Privacy.label_inference import infer_label_from_bias_grad
    m = mia_metrics(np.random.default_rng(0).normal(0.2, .1, 200), np.random.default_rng(1).normal(0.8, .1, 200)); assert m["auc"] > 0.95 and m["advantage"] > 0.8
    m0 = mia_metrics(np.random.default_rng(0).normal(0.5, .1, 400), np.random.default_rng(1).normal(0.5, .1, 400)); assert 0.4 < m0["auc"] < 0.6
    a = rimg(5); assert ssim(a, a) > 0.999 and ssim(a, 255 - a) < ssim(a, a) - 0.3 and psnr_f(a, a) == 99.0
    assert infer_label_from_bias_grad(np.array([0.3, -0.7, 0.2, 0.2])) == 1


def test_overhead_utils():
    from Evaluation.computational_overhead import time_fn, hardware_info
    t = time_fn(lambda i: sum(range(1000)), [0, 1, 2], 2, 10); assert t["n"] == 10 and t["mean_s"] >= 0
    assert "platform" in hardware_info()


def test_step_helpers():
    from Evaluation.step_helpers import benign_variants, benign_variants_masked
    caps = ["Axial MRI showing subdural hematoma.", "Intracerebral hemorrhage is present."]
    b = benign_variants(caps, np.random.default_rng(0)); assert set(b) >= {"synonym", "abbreviation", "typo"} and len(b["typo"]) == 2
    assert benign_variants_masked(caps, np.random.default_rng(0))["abbreviation"][0] == "Axial MRI showing SDH."


if __name__ == "__main__":
    n = 0
    for k, v in list(globals().items()):
        if k.startswith("test_"): v(); n += 1; print("ok", k)
    print(n, "tests passed")
