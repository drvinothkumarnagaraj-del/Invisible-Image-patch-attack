"""Runs all steps in order:  python run_all.py   (or run a single step: python run_step3_federated_baselines.py)"""
import runpy, sys, os
steps = ["run_step1_prepare_data.py", "run_step2_patch_detection.py", "run_step3_federated_baselines.py", "run_step4_adaptive_attacks.py",
         "run_step5_caption_attacks.py", "run_step6_privacy_attacks.py", "run_step7_computational_overhead.py", "run_step8_extended_privacy_security.py"]
here = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, here)
for s in steps:
    print("\n" + "=" * 20, s, "=" * 20); runpy.run_path(os.path.join(here, s), run_name="__main__")
