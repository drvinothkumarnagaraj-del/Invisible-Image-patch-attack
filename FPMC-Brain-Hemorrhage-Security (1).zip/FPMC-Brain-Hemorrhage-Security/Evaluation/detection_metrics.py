import numpy as np
from sklearn.model_selection import KFold
from sklearn.metrics import roc_auc_score
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from Evaluation.confidence_intervals import boot_auc


def fit_detector_calibrated(f_clean, f_att, fpr=0.05, seed=0, cal_frac=0.3):
    """Fit on one part of the data; set the alarm threshold on HELD-OUT clean images so the realised FPR is honest."""
    rs = np.random.RandomState(seed); n = len(f_clean); idx = rs.permutation(n); k = max(2, int(n * (1 - cal_frac)))
    fit, cal = idx[:k], idx[k:]
    det = make_pipeline(StandardScaler(), LogisticRegression(max_iter=3000, class_weight="balanced"))
    det.fit(np.vstack([f_clean[fit], f_att[fit]]), np.r_[np.zeros(len(fit)), np.ones(len(fit))])
    thr = float(np.quantile(det.predict_proba(f_clean[cal])[:, 1], 1 - fpr)) if len(cal) else 0.5
    return det, thr


def fit_detector_split(f_clean_train, f_att_train, f_clean_val, fpr=0.05, seed=0):
    """Final detector: FIT on TRAIN only, alarm threshold from CLEAN VALIDATION images only. No test image (clean or
    attacked) is ever seen here, so TPR/FPR measured later on the test split are honest."""
    det = make_pipeline(StandardScaler(), LogisticRegression(max_iter=3000, class_weight="balanced"))
    det.fit(np.vstack([f_clean_train, f_att_train]), np.r_[np.zeros(len(f_clean_train)), np.ones(len(f_att_train))])
    if len(f_clean_val) < 2:
        raise ValueError("need clean validation images to set the alarm threshold")
    return det, float(np.quantile(det.predict_proba(f_clean_val)[:, 1], 1 - fpr))


def tpr_fpr_auc(score_neg, score_pos, thr):
    s0, s1 = np.asarray(score_neg), np.asarray(score_pos)
    auc, ci = boot_auc(np.r_[np.zeros(len(s0)), np.ones(len(s1))], np.r_[s0, s1])
    return dict(tpr=float((s1 > thr).mean()), fpr=float((s0 > thr).mean()), auc=auc, auc_ci=ci, n_pos=len(s1), n_neg=len(s0))


def nested_detection(f_clean, f_sim, f_att, repeats=5, n_splits=5, fpr=0.05, seed=0):
    """Repeated K-fold: per fold the detector is fit on 70% of the training images and the threshold is set on the other
    30% (clean only). Test images never influence fitting or threshold. Returns mean flag / score per image."""
    n = len(f_clean); cf, cs = np.zeros(n), np.zeros(n)
    af = {k: np.zeros(n) for k in f_att}; asc = {k: np.zeros(n) for k in f_att}
    for r in range(repeats):
        for trn, tst in KFold(n_splits, shuffle=True, random_state=seed + r).split(np.arange(n)):
            det, thr = fit_detector_calibrated(f_clean[trn], f_sim[trn], fpr, seed + r)
            s = det.predict_proba(f_clean[tst])[:, 1]; cs[tst] += s / repeats; cf[tst] += (s > thr) / repeats
            for k, f in f_att.items():
                s = det.predict_proba(f[tst])[:, 1]; asc[k][tst] += s / repeats; af[k][tst] += (s > thr) / repeats
    return cf, cs, af, asc


def summarize_detection(cf, cs, af, asc):
    n = len(cf); out = {}
    for k in af:
        auc, (lo, hi) = boot_auc(np.r_[np.zeros(n), np.ones(n)], np.r_[cs, asc[k]])
        out[k] = dict(tpr=float(af[k].mean()), fpr=float(cf.mean()), auc=auc, auc_lo=lo, auc_hi=hi, n=n)
    return out
