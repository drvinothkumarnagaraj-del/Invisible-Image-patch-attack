"""Small helpers shared by the step scripts (pure python/numpy)."""
import re
import numpy as np
from Defense.negation_detection import MENT_RE

BENIGN_FAMILIES = ["lowercase", "punctuation removed", "synonym", "rewording", "typo", "abbreviation", "uncertainty hedge"]
CAL_BENIGN = ["lowercase", "punctuation removed", "synonym", "rewording"]       # the others are unseen at calibration


def _syn(c):
    n = re.sub(r"\bh(?:a)?emorrhage\b", "bleeding", c, flags=re.I); n = re.sub(r"\bintracerebral\b", "intraparenchymal", n, flags=re.I)
    n = re.sub(r"\bhematoma\b", "haematoma", n, flags=re.I); return n if n != c else None


def _typo(c, r):
    w = c.split(); idx = [i for i, t in enumerate(w) if len(t) > 4]
    if not idx: return None
    i = int(r.choice(idx)); t = w[i]; j = int(r.integers(1, len(t) - 2)); w[i] = t[:j] + t[j + 1] + t[j] + t[j + 2:]; return " ".join(w)


def _abbr(c):
    n = re.sub(r"\bsubdural h(?:a)?ematoma\b", "SDH", c, flags=re.I); n = re.sub(r"\bepidural h(?:a)?ematoma\b", "EDH", n, flags=re.I)
    n = re.sub(r"\bintraventricular h(?:a)?emorrhage\b", "IVH", n, flags=re.I); n = re.sub(r"\bintracerebral h(?:a)?emorrhage\b", "ICH", n, flags=re.I)
    return n if n != c else None


def _hedge(c):
    m = MENT_RE.search(c); return c[:m.start()] + "possible " + c[m.start():] if m else None


def benign_variants(caps, rng):
    """Genuine clinical wording variation (rule-generated; NOT written by independent radiologists). Inapplicable -> original text."""
    f = {"lowercase": lambda c: c.lower(), "punctuation removed": lambda c: re.sub(r"[^\w\s\-]", "", c), "synonym": _syn,
         "rewording": lambda c: "Findings: " + re.sub(r"\b(shows?|showing)\b", "demonstrating", c, flags=re.I),
         "typo": lambda c: _typo(c, rng), "abbreviation": _abbr, "uncertainty hedge": _hedge}
    return {k: [(fn(c) or c) for c in caps] for k, fn in f.items()}


def benign_variants_masked(caps, rng):
    """Same as above but None where the edit did not apply (so those rows can be excluded)."""
    f = {"lowercase": lambda c: c.lower(), "punctuation removed": lambda c: re.sub(r"[^\w\s\-]", "", c), "synonym": _syn,
         "rewording": lambda c: "Findings: " + re.sub(r"\b(shows?|showing)\b", "demonstrating", c, flags=re.I),
         "typo": lambda c: _typo(c, rng), "abbreviation": _abbr, "uncertainty hedge": _hedge}
    return {k: [fn(c) for c in caps] for k, fn in f.items()}
