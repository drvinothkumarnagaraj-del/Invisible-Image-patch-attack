"""Split and audit helpers. Every detector fit uses TRAIN, every threshold uses VAL (clean images only), every reported
number uses TEST. Pure numpy/pandas - no torch needed."""
import numpy as np, pandas as pd

SPLITS = ("train", "val", "test")


def real_split_indices(split, is_aug):
    """Indices of REAL (non-augmented) images per split."""
    split, real = np.asarray(split).astype(str), ~np.asarray(is_aug, bool)
    return {s: np.where((split == s) & real)[0] for s in SPLITS}


def assert_no_group_overlap(grp, split):
    """An image and its augmented copies share a group id; no group may appear in two splits."""
    grp, split = np.asarray(grp).astype(str), np.asarray(split).astype(str)
    names = [s for s in SPLITS if (split == s).any()]
    for i, a in enumerate(names):
        for b in names[i + 1:]:
            ov = set(grp[split == a]) & set(grp[split == b])
            if ov:
                raise RuntimeError(f"source-group leakage between '{a}' and '{b}': {len(ov)} shared groups, e.g. {sorted(ov)[:3]}")


def assert_no_aug_outside_train(split, is_aug):
    split, is_aug = np.asarray(split).astype(str), np.asarray(is_aug, bool)
    bad = int(((split != "train") & is_aug).sum())
    if bad:
        raise RuntimeError(f"{bad} augmented images are in val/test; augmented copies may only be used for training")


def data_audit(y, split, is_aug, classes):
    """Counts per split x (real/augmented) x class. Save this table: it documents exactly what was trained and tested on."""
    y, split, is_aug = np.asarray(y), np.asarray(split).astype(str), np.asarray(is_aug, bool)
    rows = []
    for s in SPLITS:
        for aug in (False, True):
            m = (split == s) & (is_aug == aug)
            if m.any():
                rows.append({"split": s, "type": "augmented" if aug else "real", "n": int(m.sum()),
                             **{c: int((y[m] == i).sum()) for i, c in enumerate(classes)}})
    return pd.DataFrame(rows)


def warn_small(P, min_n=30):
    """Warn when held-out sets are too small for narrow intervals."""
    msgs = [f"{s}: {len(P[s])} real images" for s in ("val", "test") if len(P[s]) < min_n]
    if msgs:
        print("WARNING - small held-out sets (" + "; ".join(msgs) + "). Rates have wide Wilson intervals; do not over-claim.")
