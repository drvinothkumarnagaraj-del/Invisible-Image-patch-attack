import math
import numpy as np
from sklearn.metrics import roc_auc_score


def wilson(k, n, z=1.96):
    if n == 0: return (float("nan"), float("nan"))
    p = k / n; d = 1 + z * z / n; c = (p + z * z / (2 * n)) / d
    h = z * math.sqrt(max(p * (1 - p), 0) / n + z * z / (4 * n * n)) / d
    return max(0.0, c - h), min(1.0, c + h)


def fmt_rate(rate, n):
    if n == 0 or rate is None or (isinstance(rate, float) and math.isnan(rate)): return "n/a"
    lo, hi = wilson(round(rate * n), n); return f"{rate:.2f} [{lo:.2f}-{hi:.2f}] (n={n})"


def boot_auc(lab, sc, B=300, seed=0):
    lab, sc = np.asarray(lab), np.asarray(sc)
    if len(set(lab)) < 2: return float("nan"), (float("nan"), float("nan"))
    auc = roc_auc_score(lab, sc); rng = np.random.default_rng(seed); v = []
    for _ in range(B):
        i = rng.integers(0, len(lab), len(lab))
        if len(set(lab[i])) == 2: v.append(roc_auc_score(lab[i], sc[i]))
    return float(auc), (float(np.percentile(v, 2.5)), float(np.percentile(v, 97.5)))


def boot_mean_ci(v, B=1000, seed=0):
    v = np.asarray(v, float); rng = np.random.default_rng(seed)
    m = [rng.choice(v, len(v)).mean() for _ in range(B)]
    return float(v.mean()), (float(np.percentile(m, 2.5)), float(np.percentile(m, 97.5)))
