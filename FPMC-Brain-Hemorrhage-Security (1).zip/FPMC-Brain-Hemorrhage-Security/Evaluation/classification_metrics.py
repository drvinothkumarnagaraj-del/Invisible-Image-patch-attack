import numpy as np
from sklearn.metrics import f1_score
from Evaluation.confidence_intervals import fmt_rate


def classification_report(y_true, y_pred, control_class=0):
    y_true, y_pred = np.asarray(y_true), np.asarray(y_pred); n = len(y_true)
    hem, ctl = y_true != control_class, y_true == control_class
    acc = float((y_true == y_pred).mean()) if n else float("nan")
    return {"n": n, "accuracy": fmt_rate(acc, n), "macro_f1": round(float(f1_score(y_true, y_pred, average="macro", zero_division=0)), 3) if n else float("nan"),
            "hemorrhage_sensitivity": fmt_rate(float((y_pred[hem] != control_class).mean()) if hem.sum() else float("nan"), int(hem.sum())),
            "control_specificity": fmt_rate(float((y_pred[ctl] == control_class).mean()) if ctl.sum() else float("nan"), int(ctl.sum())),
            "_acc": acc}
