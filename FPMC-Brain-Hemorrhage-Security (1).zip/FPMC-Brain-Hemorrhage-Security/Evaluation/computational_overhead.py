"""Reproducible latency / memory / communication measurement."""
import time, platform
import numpy as np


def hardware_info():
    info = dict(platform=platform.platform(), python=platform.python_version(), cpu=platform.processor() or platform.machine())
    try:
        import psutil; info["system_ram_GB"] = round(psutil.virtual_memory().total / 2 ** 30, 1); info["cpu_cores"] = psutil.cpu_count(logical=True)
    except Exception: pass
    try:
        import torch; info["torch"] = torch.__version__; info["cuda_available"] = torch.cuda.is_available()
        if torch.cuda.is_available(): info["gpu"] = torch.cuda.get_device_name(0); info["gpu_mem_GB"] = round(torch.cuda.get_device_properties(0).total_memory / 2 ** 30, 1)
    except Exception: pass
    for lib in ("timm", "transformers", "cv2", "sklearn"):
        try: info[lib] = __import__(lib).__version__
        except Exception: pass
    return info


def _sync():
    try:
        import torch
        if torch.cuda.is_available(): torch.cuda.synchronize()
    except Exception: pass


def time_fn(fn, inputs, warmup=10, repeats=100):
    """fn(item) is called with batch size 1 per call. Inputs are cycled. GPU is synchronised before/after each call.
    Returns seconds per call: mean, std, median, IQR."""
    for i in range(warmup): fn(inputs[i % len(inputs)])
    ts = []
    for i in range(repeats):
        _sync(); t = time.perf_counter(); fn(inputs[i % len(inputs)]); _sync(); ts.append(time.perf_counter() - t)
    a = np.array(ts)
    return dict(mean_s=float(a.mean()), std_s=float(a.std()), median_s=float(np.median(a)), iqr_s=float(np.percentile(a, 75) - np.percentile(a, 25)), n=len(a))


def peak_memory_of(fn, inputs, n=20):
    """Peak GPU memory (MB, max_memory_allocated) and process RSS (MB, psutil) during n calls."""
    import os
    gpu = float("nan")
    try:
        import torch
        if torch.cuda.is_available(): torch.cuda.reset_peak_memory_stats()
    except Exception: pass
    rss = 0.0
    try:
        import psutil; p = psutil.Process(os.getpid())
    except Exception: p = None
    for i in range(n):
        fn(inputs[i % len(inputs)])
        if p: rss = max(rss, p.memory_info().rss / 2 ** 20)
    _sync()
    try:
        import torch
        if torch.cuda.is_available(): gpu = torch.cuda.max_memory_allocated() / 2 ** 20
    except Exception: pass
    return dict(peak_gpu_MB=gpu, peak_ram_MB=rss)


def model_size(model):
    n = sum(p.numel() for p in model.parameters()); return dict(params=n, size_MB=n * 4 / 2 ** 20)
