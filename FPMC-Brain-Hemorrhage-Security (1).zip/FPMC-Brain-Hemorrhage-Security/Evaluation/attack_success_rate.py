import numpy as np
from Evaluation.confidence_intervals import fmt_rate


def conditional_asr(base_pred, attacked_pred, target):
    """ASR over images the model does NOT already assign to the target class without the attack.
    Returns (asr, n_eligible, natural_target_rate)."""
    base_pred, attacked_pred = np.asarray(base_pred), np.asarray(attacked_pred)
    elig = base_pred != target
    n = int(elig.sum())
    asr = float((attacked_pred[elig] == target).mean()) if n else float("nan")
    return asr, n, float((base_pred == target).mean()) if len(base_pred) else float("nan")


def asr_row(base_pred, att_pred, att_pred_def, target):
    a0, n, nat = conditional_asr(base_pred, att_pred, target)
    a1, _, _ = conditional_asr(base_pred, att_pred_def, target)
    return {"n eligible": n, "ASR no defence": fmt_rate(a0, n), "ASR with defence": fmt_rate(a1, n),
            "natural target rate (no attack)": f"{nat:.2f}", "_asr0": a0, "_asr1": a1}
