"""STEP 2 - invisible-patch detection: Grad-CAM detector vs FFT baseline, attack-strength sweep (alpha, beta), then ADAPTIVE
attacks (location / frequency / intensity / size).

Protocol (no test leakage):
  * the detector is FIT on TRAIN images (clean = negatives, defender-simulated FIBA = positives; simulated triggers are
    drawn from TRAIN images only);
  * the alarm threshold is set on CLEAN VALIDATION images only (fpr_target);
  * every number in tables 2a2 and 2b is measured on the TEST images, which the detector never saw;
  * table 2a (all real images, repeated K-fold cross-fitting) is a larger-n complement: every image is scored by a detector
    that never saw it.
The final detector saved for steps 3-7 is the train/val one.

Detectors compared (ablation):
  "Grad-CAM (global stats)"                      whole-image Grad-CAM statistics
  "POA-MaxViT window Grad-CAM (proposed)"        + statistics inside an attention window chosen by the Pelican Optimization
                                                  Algorithm on TRAIN images only
  "FFT baseline"                                 radial log-spectrum features"""
import numpy as np, pandas as pd, joblib
from common import *
from Attacks.fiba_attack import fiba, psnr
from Attacks.patch_generation import load_triggers, sample_attack_params, apply_attack, ADAPTIVE_KINDS
from Detection.maxvit_detection import CamFeatureExtractor, fft_feature_matrix, PatchDetector
from Detection.poa_window import search_window, window_stats
from Evaluation.detection_metrics import nested_detection, summarize_detection, fit_detector_split, tpr_fpr_auc
from Evaluation.confidence_intervals import fmt_rate
from Evaluation.protocol import real_split_indices, assert_no_group_overlap, assert_no_aug_outside_train, warn_small

cfg = load_config(); set_seed(cfg["seed"]); dev = device(); D = load_cache(cfg)
Xc, y, is_aug, split = D["Xc"], D["y"], D["is_aug"], D["split"]; S = cfg["data"]["img_size"]
rs = np.random.RandomState(cfg["seed"]); A = cfg["attack"]; dt = cfg["detection"]
assert_no_group_overlap(D["grp"], split); assert_no_aug_outside_train(split, is_aug)
P = real_split_indices(split, is_aug); warn_small(P)
real = np.where(~is_aug)[0]
m_tr, m_va, m_te = (np.isin(real, P[s]) for s in ("train", "val", "test"))        # masks over the `real` ordering
print(f"real images: train {m_tr.sum()} | val {m_va.sum()} | test {m_te.sum()}")

trigs, files = load_triggers(cfg["paths"]["patch_dir"], S, *D["clahe"].tolist(), n=A["trigger_pool"]); assert trigs, "no trigger patches found"
cx = CamFeatureExtractor(cfg["backbone"]["name"], tuple(cfg["backbone"]["gradcam_stages"]), dev, dt["cam_threshold"]); cx.window = None
PW = dt.get("poa_window", {})
G, W, FFT = "Grad-CAM (global stats)", "POA-MaxViT window Grad-CAM (proposed)", "FFT baseline"
WIN = None                                             # set after the POA search (below)
def split_feats(X):
    f, cams = cx(X, return_cams=True); out = {G: f, FFT: fft_feature_matrix(X)}
    if WIN is not None: out[W] = np.hstack([f, window_stats(cams, WIN, dt["cam_threshold"])])
    return out, cams

# defender-simulated attacks use TRAIN images as triggers (never the attacker's patch files, never val/test images)
pool = [Xc[j] for j in rs.choice(P["train"], min(64, len(P["train"])), replace=False)]
sim_imgs = np.stack([fiba(Xc[i], pool[rs.randint(len(pool))], rs.uniform(0.05, 0.5), rs.uniform(0.02, 0.2)) for i in real])
F_clean, cams_clean = split_feats(Xc[real]); F_sim, cams_sim = split_feats(sim_imgs)       # one simulated set shared by all detectors

# ---- POA search of the MaxViT attention window: TRAIN images only (clean vs defender-simulated attack) ----
if PW.get("enabled", True):
    WIN, wfit, whist, wfull = search_window(cams_clean[m_tr], cams_sim[m_tr], dt["cam_threshold"], PW.get("pop", 8), PW.get("iters", 10), cfg["seed"], PW.get("fitness", "separability"))
    print(f"POA window (x,y,h,w) = {tuple(round(v, 3) for v in WIN)} | train CV-AUC {wfit:.3f} (whole image: {wfull:.3f})")
    save_table(pd.DataFrame({"iteration": range(len(whist)), "best fitness": whist}), cfg, "step2_poa_window_history", show=False)
    save_json(dict(window_xyhw=WIN, fitness=wfit, whole_image_fitness=wfull, fitness_type=PW.get("fitness", "separability")), cfg, "step2_poa_window")
    F_clean, cams_clean = split_feats(Xc[real]); F_sim, cams_sim = split_feats(sim_imgs)   # recompute so the window detector exists

# attacker's seen-FIBA sweep over ALL real images (sliced to the test images for table 2a2)
atts, psnrs = {}, {}
for a in A["alphas"]:
    for b in A["betas"]:
        imgs = np.stack([fiba(Xc[i], trigs[rs.randint(len(trigs))], a, b) for i in real]); atts[(a, b)] = split_feats(imgs)[0]
        psnrs[(a, b)] = float(np.mean([psnr(Xc[i], imgs[j]) for j, i in enumerate(real)]))

# ---- (a) cross-fitted sweep on all real images ----
rows = []
for d in F_clean:
    cf, cs, af, asc = nested_detection(F_clean[d], F_sim[d], {k: v[d] for k, v in atts.items()}, dt["repeats"], dt["n_splits"], dt["fpr_target"], cfg["seed"])
    for (a, b), r in summarize_detection(cf, cs, af, asc).items():
        rows.append({"detector": d, "alpha": a, "beta": b, "PSNR dB": round(psnrs[(a, b)], 1), "invisible": psnrs[(a, b)] >= A["psnr_invisible_db"],
                     "TPR": fmt_rate(r["tpr"], r["n"]), f"FPR realised (target {dt['fpr_target']})": fmt_rate(r["fpr"], r["n"]),
                     "AUC [95% CI]": f"{r['auc']:.3f} [{r['auc_lo']:.3f}-{r['auc_hi']:.3f}]"})
save_table(pd.DataFrame(rows), cfg, "step2a_seen_fiba_detection_crossfit")

# ---- (a2) HELD-OUT test sweep: detector fit on train, threshold on val, evaluated on test ----
final, rows_a2, rows_b = {}, [], []
for d in F_clean:
    det, thr = fit_detector_split(F_clean[d][m_tr], F_sim[d][m_tr], F_clean[d][m_va], dt["fpr_target"], cfg["seed"])
    final[d] = (det, thr); sc_clean = det.predict_proba(F_clean[d][m_te])[:, 1]
    for (a, b), fd in atts.items():
        r = tpr_fpr_auc(sc_clean, det.predict_proba(fd[d][m_te])[:, 1], thr)
        rows_a2.append({"detector": d, "alpha": a, "beta": b, "PSNR dB": round(psnrs[(a, b)], 1), "invisible": psnrs[(a, b)] >= A["psnr_invisible_db"],
                        "TPR (sensitivity)": fmt_rate(r["tpr"], r["n_pos"]), f"FPR (target {dt['fpr_target']})": fmt_rate(r["fpr"], r["n_neg"]),
                        "AUC [95% CI]": f"{r['auc']:.3f} [{r['auc_ci'][0]:.3f}-{r['auc_ci'][1]:.3f}]"})
    # ---- (b) adaptive attacks, same final detector, test images only ----
    for kind in ADAPTIVE_KINDS:
        imgs, ps = [], []
        for _ in range(dt["adaptive_per_kind"]):
            for i in real[m_te]:
                p = sample_attack_params(kind, rs); xa = apply_attack(Xc[i], trigs[rs.randint(len(trigs))], p, rs); imgs.append(xa); ps.append(psnr(Xc[i], xa))
        sc = det.predict_proba(split_feats(np.stack(imgs))[0][d])[:, 1]
        r = tpr_fpr_auc(np.tile(sc_clean, dt["adaptive_per_kind"]), sc, thr)
        rows_b.append({"detector": d, "adaptive attack": kind, "mean PSNR dB": round(float(np.mean(ps)), 1), "TPR": fmt_rate(r["tpr"], r["n_pos"]),
                       "FPR": fmt_rate(r["fpr"], r["n_neg"]), "AUC": f"{r['auc']:.3f} [{r['auc_ci'][0]:.3f}-{r['auc_ci'][1]:.3f}]"})
save_table(pd.DataFrame(rows_a2), cfg, "step2a2_heldout_strength_sweep")
save_table(pd.DataFrame(rows_b), cfg, "step2b_adaptive_patch_detection")

PROPOSED = W if WIN is not None else G
det, thr = final[PROPOSED]
pdet = PatchDetector(dt["fpr_target"], cfg["seed"]); pdet.det, pdet.thr, pdet.window = det, thr, WIN
joblib.dump(dict(detector=pdet, F_clean=F_clean[PROPOSED][m_tr]), cache_path(cfg, "patch_detector.joblib"))
print(f"saved detector for steps 3-7: {PROPOSED}")
save_json(dict(n_train=int(m_tr.sum()), n_val=int(m_va.sum()), n_test=int(m_te.sum()), threshold=thr, fpr_target=dt["fpr_target"]), cfg, "step2_protocol")
print("\nIf TPR is close to FPR and AUC close to 0.5, the detector does NOT detect that attack. Report it as such.")
print("FIBA has no localised patch, so localisation IoU is not defined; compute a Grad-CAM/perturbation correlation only if you need one.")
