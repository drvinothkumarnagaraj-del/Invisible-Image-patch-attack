"""Shared helpers for the run_step*.py scripts."""
import os, sys, json, random
import numpy as np, pandas as pd

ROOT = os.path.dirname(os.path.abspath(__file__))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)


def load_config(path=None):
    import yaml
    path = path or os.path.join(ROOT, "Configuration", "experiment_config.yaml")
    cfg = yaml.safe_load(open(path)); P = cfg["paths"]
    if "out_dir" not in P: P["out_dir"] = os.path.join(P["results_root"], str(P.get("run_name", "run1")))
    out, ds = os.path.abspath(P["out_dir"]), os.path.abspath(P["dataset_root"])
    idx_dir = os.path.dirname(os.path.abspath(P["index_csv"]))
    for protected in (ds, idx_dir):
        if out == protected or out.startswith(protected + os.sep):
            raise ValueError(f"out_dir '{out}' is inside the dataset folder '{protected}'. Results must go to a separate folder (paths.results_root).")
    for k in ("out_dir", "cache_dir"):
        os.makedirs(cfg["paths"][k], exist_ok=True)
    return cfg


def set_seed(seed):
    random.seed(seed); np.random.seed(seed)
    try:
        import torch
        torch.manual_seed(seed); torch.cuda.manual_seed_all(seed)
        torch.backends.cudnn.deterministic = True; torch.backends.cudnn.benchmark = False
    except Exception:
        pass


def device():
    import torch
    return "cuda" if torch.cuda.is_available() else "cpu"


def save_table(df, cfg, name, show=True):
    p = os.path.join(cfg["paths"]["out_dir"], name + ".csv")
    df.to_csv(p, index=False)
    if show:
        print(f"\n=== {name} ===\n" + df.to_string(index=False))
    return p


def cache_path(cfg, name):
    return os.path.join(cfg["paths"]["cache_dir"], name)


def load_cache(cfg):
    z = np.load(cache_path(cfg, "data.npz"), allow_pickle=True)
    D = {k: z[k] for k in z.files}
    D["caps"] = list(D["caps"])
    D["split"] = np.asarray(D["split"]).astype(str)
    D["grp"] = np.asarray(D["grp"]).astype(str)
    D["is_aug"] = D["is_aug"].astype(bool)
    return D


def save_json(obj, cfg, name):
    json.dump(obj, open(os.path.join(cfg["paths"]["out_dir"], name + ".json"), "w"), indent=2, default=str)


def save_run_manifest(cfg, name="run_manifest"):
    """Config + library versions + hardware, so a reader can re-run exactly what produced the tables."""
    import platform
    info = dict(config=cfg, python=platform.python_version(), platform=platform.platform())
    for lib in ("numpy", "pandas", "sklearn", "torch", "timm", "transformers", "cv2"):
        try: info[lib] = __import__(lib).__version__
        except Exception: pass
    try:
        import torch
        if torch.cuda.is_available(): info["gpu"] = torch.cuda.get_device_name(0)
    except Exception: pass
    save_json(info, cfg, name)
