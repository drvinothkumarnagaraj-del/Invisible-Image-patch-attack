"""STEP 7 - per-component and full-pipeline latency (batch size 1, warm-up, GPU-synchronised), peak GPU memory / RAM,
parameter counts and federated communication, all measured here (nothing is estimated from totals)."""
import joblib, numpy as np, pandas as pd, torch
from common import *
from Attacks.fiba_attack import fiba
from Attacks.patch_generation import load_triggers
from Preprocessing.clahe import clahe_apply
from Defense.lama_inpainting import cam_to_mask, inpaint
from Defense.negation_detection import assertions, polarity_flip
from Detection.maxvit_detection import CamFeatureExtractor
from Detection.clinical_biobert import ClinicalEmbedder, pair_features
from Federated_Learning.client_training import MultimodalNet, predict
from Federated_Learning.global_aggregation import communication_cost
from Evaluation.computational_overhead import hardware_info, time_fn, peak_memory_of, model_size

cfg = load_config(); set_seed(cfg["seed"]); dev = device(); D = load_cache(cfg); oh = cfg["overhead"]
X, Xc, y, E, caps, split, is_aug = D["X"], D["Xc"], D["y"], D["E_orig"], D["caps"], D["split"], D["is_aug"]
NC = len(cfg["data"]["classes"]); S = cfg["data"]["img_size"]; EV = cfg["data"]["classes"].index(cfg["data"]["evade_class"])
te = np.where((split == "test") & ~is_aug)[0]; trigs, _ = load_triggers(cfg["paths"]["patch_dir"], S, *D["clahe"].tolist(), n=4)
clip, tile = D["clahe"].tolist(); pdet = joblib.load(cache_path(cfg, "patch_detector.joblib"))["detector"]
cx = CamFeatureExtractor(cfg["backbone"]["name"], tuple(cfg["backbone"]["gradcam_stages"]), dev, cfg["detection"]["cam_threshold"])
cx.window = getattr(pdet, "window", None)      # POA-selected attention window saved in step 2
emb = ClinicalEmbedder(cfg["text"]["encoder"], dev)
model = MultimodalNet(cfg["backbone"]["name"], NC, text_dim=E.shape[1], pretrained=False); model.load_state_dict(torch.load(cache_path(cfg, "model_fpmc_data_poison.pt"))); model.to(dev).eval()
items = []                                    # 50% clean, 50% attacked test cases
for k, i in enumerate(te):
    atk = k % 2 == 1; img = fiba(Xc[i], trigs[0], cfg["attack"]["fiba"]["alpha"], cfg["attack"]["fiba"]["beta"]) if atk else Xc[i]
    items.append(dict(i=int(i), raw=X[i], img=img, cap=caps[i], attacked=atk))
flags_seen = []

def f_clahe(it): clahe_apply(it["raw"], clip, tile)
def f_cam(it): cx(it["img"][None], return_cams=True)
def f_det(it): pdet.flag(cx_feat_cache[it["i"]])
cx_feat_cache = {it["i"]: cx(it["img"][None]) for it in items}
def f_lama(it):
    f, c = cx(it["img"][None], return_cams=True); inpaint(it["img"], cam_to_mask(c[0], 0.6), True)
def f_text(it):
    e = emb([it["cap"]]); pair_features([it["cap"]], [it["cap"]], e, e)
def f_cls(it): predict(model, it["img"][None], E[it["i"]][None], "fused", dev)
def f_full(it):
    f, c = cx(it["img"][None], return_cams=True); flag = bool(pdet.flag(f)[0]); img = inpaint(it["img"], cam_to_mask(c[0], 0.6), True) if flag else it["img"]
    e = emb([it["cap"]]); pair_features([it["cap"]], [it["cap"]], e, e); predict(model, img[None], e, "fused", dev); flags_seen.append(flag)

rows = []
for name, fn in [("CLAHE preprocessing", f_clahe), ("Grad-CAM feature extraction (MaxViT fwd+bwd)", f_cam), ("Patch-detector decision (logistic head)", f_det),
                 ("LaMa/Telea inpainting (when triggered, incl. CAM pass)", f_lama), ("Clinical BioBERT + integrity features (per report)", f_text),
                 ("Multimodal fusion + classification", f_cls), ("COMPLETE pipeline (inpaint only if flagged)", f_full)]:
    t = time_fn(fn, items, oh["warmup"], oh["repeats"]); m = peak_memory_of(fn, items, 20)
    rows.append({"component": name, "mean s": round(t["mean_s"], 4), "std s": round(t["std_s"], 4), "median s": round(t["median_s"], 4), "IQR s": round(t["iqr_s"], 4), "n": t["n"],
                 "peak GPU MB": round(m["peak_gpu_MB"], 0), "peak RAM MB": round(m["peak_ram_MB"], 0)})
save_table(pd.DataFrame(rows), cfg, "step7a_latency_memory")
print(f"fraction of cases flagged and inpainted in the full-pipeline run: {np.mean(flags_seen):.2f} (50% of the cases were attacked)")

ms, bs = model_size(model), model_size(cx.model); cc = communication_cost(ms["params"], cfg["federated"]["rounds"], cfg["federated"]["n_clients"])
save_table(pd.DataFrame([{"classifier params": ms["params"], "classifier size MB": round(ms["size_MB"], 1), "detector backbone params": bs["params"],
                          "download per client per round MB": round(cc["bytes_download_per_client"] / 2 ** 20, 1), "upload per client per round MB": round(cc["bytes_upload_per_client"] / 2 ** 20, 1),
                          "rounds": cfg["federated"]["rounds"], "clients": cfg["federated"]["n_clients"], "total communication MB": round(cc["total_MB"], 1)}]), cfg, "step7b_size_and_communication")
save_json(hardware_info(), cfg, "step7c_hardware"); print(hardware_info())
print("Local image/caption checks add no communication payload because no masks, reports or embeddings are uploaded.")
