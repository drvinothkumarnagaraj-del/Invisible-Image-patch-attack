"""STEP 5 - caption manipulation: SEEN vs UNSEEN attack types, adaptive (cosine-aware) attack, calibration/test separated by
source group, and the image-report consistency signal (test split only, out-of-sample image model)."""
import numpy as np, pandas as pd, torch
from common import *
from Attacks.label_poisoning import SEEN, UNSEEN, adaptive_caption_attack
from Defense.negation_detection import assertions, polarity_flip, inconsistent
from Detection.clinical_biobert import ClinicalEmbedder, pair_features, cosdist, evaluate_caption_detection
from Evaluation.step_helpers import benign_variants_masked, CAL_BENIGN
from Evaluation.confidence_intervals import fmt_rate

cfg = load_config(); set_seed(cfg["seed"]); dev = device(); D = load_cache(cfg); tx = cfg["text"]
y, caps, E_o, grp, is_aug, split = D["y"], D["caps"], D["E_orig"], D["grp"], D["is_aug"], D["split"]
EV = cfg["data"]["classes"].index(cfg["data"]["evade_class"]); real = np.where(~is_aug)[0]
texts_o = [caps[i] for i in real]; Eo = E_o[real]; G = grp[real]; rng = np.random.default_rng(cfg["seed"])
emb = ClinicalEmbedder(tx["encoder"], dev)

gen = {}
for k, v in benign_variants_masked(texts_o, rng).items(): gen[("b", k)] = [t if (t and t != o) else None for t, o in zip(v, texts_o)]
for tag, pool in (("s", SEEN), ("u", UNSEEN)):
    for k, fn in pool.items():
        gen[(tag, k)] = [None if y[real[j]] == EV else (lambda t: t if (t and t != o) else None)(fn(o)) for j, o in enumerate(texts_o)]
flat, slot = [], []
for key, v in gen.items():
    for j, t in enumerate(v):
        if t is not None: flat.append(t); slot.append((key, j))
EA = emb(flat); Em = {k: np.full_like(Eo, np.nan) for k in gen}
for e, (key, j) in zip(EA, slot): Em[key][j] = e
def build(key):
    F = np.full((len(real), 3), np.nan); ids = [j for j, t in enumerate(gen[key]) if t is not None]
    if ids: F[ids] = pair_features([texts_o[j] for j in ids], [gen[key][j] for j in ids], Eo[ids], Em[key][ids])
    return F
F_b = {k[1]: build(k) for k in gen if k[0] == "b"}; F_s = {k[1]: build(k) for k in gen if k[0] == "s"}; F_u = {k[1]: build(k) for k in gen if k[0] == "u"}
res = pd.DataFrame(evaluate_caption_detection(F_b, F_s, F_u, G, CAL_BENIGN, tx["fpr_target"], tx["repeats"], cfg["seed"]))
save_table(res.drop(columns=["_tpr", "_fpr", "_auc"]), cfg, "step5a_caption_detection_seen_vs_unseen")
gap = res.groupby(["detector", "attack set"])["_tpr"].mean().unstack()
print("\nMean TPR by detector and attack set (the SEEN-UNSEEN gap measures generalisation):\n", gap.round(2).to_string())

# ---- adaptive caption attacker (knows cosine check; wants a REAL diagnostic change with maximal similarity) ----
tau = float(D["cos_tau"][0]); rows = []; hem_r = [j for j in range(len(real)) if y[real[j]] != EV]
atk = [(j, adaptive_caption_attack(texts_o[j], emb)) for j in hem_r]; atk = [(j, a) for j, a in atk if a]
if atk:
    sims = np.array([a["cosine"] for _, a in atk]); flips = np.array([polarity_flip(assertions(texts_o[j]), assertions(a["text"])) for j, a in atk])
    rows.append({"captions with a feasible adaptive edit": f"{len(atk)}/{len(hem_r)}", "median cosine of best edit": round(float(np.median(sims)), 4),
                 "pass the cosine check (sim >= tau)": fmt_rate(float((sims >= tau).mean()), len(atk)), "caught by assertion/polarity rule": fmt_rate(float(flips.mean()), len(atk)),
                 "cosine tau (calibrated)": round(tau, 4)})
    save_table(pd.DataFrame(rows), cfg, "step5b_adaptive_caption_attack")

# ---- image-report consistency (test split only; image model trained without these images) ----
try:
    from Federated_Learning.client_training import MultimodalNet, predict
    NC = len(cfg["data"]["classes"]); m = MultimodalNet(cfg["backbone"]["name"], NC, text_dim=E_o.shape[1], pretrained=False)
    m.load_state_dict(torch.load(cache_path(cfg, "model_fedavg_clean.pt"))); m.to(dev).eval()
    te = np.where((split == "test") & ~is_aug)[0]; pos = {int(i): k for k, i in enumerate(real)}
    ph = predict(m, D["Xc"][te], None, "image", dev) != EV; out = []
    for key in [k for k in gen if k[0] in ("b", "s", "u")]:
        vals = [inconsistent(assertions(gen[key][pos[int(i)]]), p) for i, p in zip(te, ph) if gen[key][pos[int(i)]] is not None]
        if vals: out.append({"category": {"b": "genuine variation", "s": "seen attack", "u": "unseen attack"}[key[0]], "edit": key[1], "n": len(vals), "inconsistent with image model": fmt_rate(float(np.mean(vals)), len(vals))})
    orig = [inconsistent(assertions(t), p) for t, p in zip([caps[i] for i in te], ph)]
    out.insert(0, {"category": "original note", "edit": "-", "n": len(orig), "inconsistent with image model": fmt_rate(float(np.mean(orig)), len(orig))})
    save_table(pd.DataFrame(out), cfg, "step5c_image_report_consistency")
    print("The image-report check inherits the image model's own errors (see the 'original note' row): treat it as supporting evidence only.")
except Exception as e:
    print("image-report consistency skipped (run step 3 first):", e)
