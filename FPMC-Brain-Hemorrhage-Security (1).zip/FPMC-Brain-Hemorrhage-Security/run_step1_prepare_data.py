"""STEP 1 - load dataset, POA-optimised CLAHE, Clinical BioBERT embeddings, calibrate cosine tau on genuine variations."""
import numpy as np
from common import *
from Preprocessing.image_preprocessing import load_dataset
from Preprocessing.clahe import optimize_clahe, clahe_apply
from Attacks.label_poisoning import poison_sub_neg
from Detection.clinical_biobert import ClinicalEmbedder, calibrate_cos_tau
from Evaluation.protocol import assert_no_group_overlap, assert_no_aug_outside_train, data_audit

cfg = load_config(); set_seed(cfg["seed"]); dev = device(); save_run_manifest(cfg)
import os as _os
_n = len(_os.listdir(cfg["paths"]["out_dir"]))
print(f"results folder: {cfg['paths']['out_dir']}" + (f"  (already holds {_n} files - change paths.run_name to keep the earlier results)" if _n else ""))
D = load_dataset(cfg); X, y, caps = D["X"], D["y"], D["caps"]
assert_no_group_overlap(D["grp"], D["split"]); assert_no_aug_outside_train(D["split"], D["is_aug"])
audit = data_audit(y, D["split"], D["is_aug"], cfg["data"]["classes"]); save_table(audit, cfg, "step1_data_audit")
print("REPORT THESE COUNTS: augmented copies are used for TRAINING only; every metric is on real val/test images.")
rs = np.random.RandomState(cfg["seed"]); pc = cfg["preprocessing"]
tr_idx = np.where(D["split"] == "train")[0]                       # CLAHE parameters are chosen on TRAIN images only
sample = X[rs.choice(tr_idx, min(pc["poa_sample_images"], len(tr_idx)), replace=False)]
clip, tile, f, hist = optimize_clahe(sample, tuple(pc["clahe_bounds"]["clip"]), tuple(pc["clahe_bounds"]["tile"]), pc["poa_population"], pc["poa_iterations"], cfg["seed"])
print(f"POA-CLAHE: clip={clip:.2f} tile={tile} fitness={f:.3f}")
Xc = np.stack([clahe_apply(x, clip, tile) for x in X])

emb = ClinicalEmbedder(cfg["text"]["encoder"], dev)
E_orig = emb(caps)
pois = [poison_sub_neg(c) or c for c in caps]; E_pois = emb(pois)
from Evaluation.step_helpers import benign_variants
cal_idx = np.where(D["split"] != "test")[0]                        # cosine threshold uses train+val captions only
ben = benign_variants([caps[i] for i in cal_idx], np.random.default_rng(cfg["seed"]))
tau = calibrate_cos_tau(E_orig[cal_idx], [emb(v) for v in ben.values()], cfg["text"]["fpr_target"])
print(f"cosine tau (similarity) calibrated on genuine variations at FPR={cfg['text']['fpr_target']}: {tau:.4f}")
np.savez_compressed(cache_path(cfg, "data.npz"), X=X, Xc=Xc, y=y, caps=np.array(caps, dtype=object), split=D["split"], grp=D["grp"],
                    is_aug=D["is_aug"], ids=D["ids"], E_orig=E_orig, E_pois=E_pois, poisoned_caps=np.array(pois, dtype=object),
                    clahe=np.array([clip, tile]), cos_tau=np.array([tau]))
save_json(dict(clahe_clip=clip, clahe_tile=tile, cos_tau=tau, n=len(X)), cfg, "step1_summary")
print("cache saved")
