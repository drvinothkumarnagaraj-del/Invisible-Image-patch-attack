"""Client-level inference: what can be learned about ONE CLIENT from the update the server receives (or from the aggregate)?

Two attacks, both white-box on the server side (the server knows the global model before the round and sees the update):
  1. client-level membership inference: is a candidate sample part of client c's training data? Score = how much the loss
     of the candidate DROPS when the model is moved by the update  (loss(theta + u) - loss(theta); members drop more).
     Two kinds of non-members: (a) held-out real images, (b) other clients' real training images (client ATTRIBUTION).
  2. class-composition (property) inference: the last-layer bias part of the update is correlated with the client's class
     frequencies; we report the Spearman correlation and whether the client's most frequent class is the arg-max of the
     bias update.
Views compared by the caller: an individual client's update (what the server sees WITHOUT secure aggregation), the
aggregate (what it sees WITH secure aggregation), and noised aggregates (with client-level DP).
The scoring helpers are numpy; only `UpdateLossProbe` needs torch."""
import numpy as np
from scipy.stats import spearmanr
from Privacy.membership_inference import mia_metrics


def param_slices(template_sd):
    """name -> slice into the vector produced by `state_to_vec` (sorted keys, floating-point entries only)."""
    out, i = {}, 0
    for k, v in sorted(template_sd.items()):
        if v.is_floating_point():
            n = v.numel(); out[k] = slice(i, i + n); i += n
    return out


class UpdateLossProbe:
    """Per-sample losses of `model` after moving its flattened parameters by an update vector (torch needed)."""

    def __init__(self, model, gvec, template_sd, X, y, device, mode="image"):
        from Privacy.membership_inference import per_sample_loss
        from Federated_Learning.global_aggregation import vec_to_state
        self._psl, self._v2s = per_sample_loss, vec_to_state
        self.model, self.gvec, self.tmpl, self.X, self.y, self.dev, self.mode = model, np.asarray(gvec, np.float32), template_sd, X, y, device, mode
        self.base = self._loss(np.zeros_like(self.gvec))

    def _loss(self, update):
        self.model.load_state_dict(self._v2s((self.gvec + np.asarray(update, np.float32)).astype(np.float32), self.tmpl))
        return self._psl(self.model, self.X, self.y, self.dev, self.mode)

    def delta(self, update):
        """loss(theta + update) - loss(theta) for every candidate sample (members have the more NEGATIVE values)."""
        return self._loss(update) - self.base


def membership_from_delta(delta, pos, neg, rng, min_n=5):
    """AUC / advantage / TPR@5%FPR of 'sample is a member' with balanced classes (subsampled with `rng`). Returns None if too few."""
    pos, neg = np.asarray(pos), np.asarray(neg); n = min(len(pos), len(neg))
    if n < min_n: return None
    p, q = rng.choice(pos, n, replace=False), rng.choice(neg, n, replace=False)
    return mia_metrics(delta[p], delta[q])        # mia_metrics treats LOWER values as 'member'


def summarize_clients(per_client):
    """per_client: list of metric dicts (or None). Mean/min/max AUC over clients and the total number of balanced pairs."""
    ok = [m for m in per_client if m is not None]
    if not ok: return dict(clients=0, auc_mean=float("nan"), auc_min=float("nan"), auc_max=float("nan"), advantage_mean=float("nan"), pairs=0)
    a = [m["auc"] for m in ok]
    return dict(clients=len(ok), auc_mean=float(np.mean(a)), auc_min=float(np.min(a)), auc_max=float(np.max(a)),
                advantage_mean=float(np.mean([m["advantage"] for m in ok])), pairs=int(sum(m["n_members"] for m in ok)))


def class_composition_inference(bias_updates, label_hist):
    """bias_updates (n_clients, K): last-layer bias part of each client's (or of the aggregate, repeated) update.
    label_hist (n_clients, K): the clients' true class counts. Returns mean Spearman correlation and the fraction of clients whose
    most frequent class equals the arg-max of the bias update (chance = mean over clients of 1/#tied classes ~ 1/K)."""
    B, H = np.asarray(bias_updates, float), np.asarray(label_hist, float); rho, hit = [], []
    for b, h in zip(B, H):
        r = spearmanr(b, h).statistic if np.std(b) > 0 and np.std(h) > 0 else float("nan"); rho.append(r)
        hit.append(float(int(np.argmax(b)) in set(np.flatnonzero(h == h.max()))))
    return dict(spearman_mean=float(np.nanmean(rho)) if np.any(~np.isnan(rho)) else float("nan"), top_class_hit=float(np.mean(hit)), n_clients=len(B))
