"""Label inference from a batch-size-1 gradient (iDLG): for softmax cross-entropy the gradient of the last-layer bias is
negative ONLY at the true class."""
import numpy as np


def infer_label_from_bias_grad(bias_grad): return int(np.argmin(bias_grad))


def last_layer_bias_grad(model, x_uint8, y, device="cuda", mode="image"):
    import torch, torch.nn.functional as F
    from Preprocessing.image_preprocessing import to_tensor_input
    model.eval().to(device); model.zero_grad()
    xb = torch.from_numpy(to_tensor_input(x_uint8[None])).to(device)
    F.cross_entropy(model(xb, None, mode), torch.tensor([int(y)], device=device)).backward()
    return (model.ihead.bias.grad if mode == "image" else model.head.bias.grad).detach().cpu().numpy()
