"""Client->server channel: tampering (man-in-the-middle) with and without authenticated encryption. numpy + `cryptography`.

`SecureChannel` is an APPLICATION-LAYER SIMULATION of what a TLS 1.3 record layer with AES-256-GCM gives each message:
confidentiality, integrity/authenticity (any change to header, nonce, ciphertext or tag is detected) and, with the counter
check below, protection against replay and cross-client substitution. The session key comes from an X25519 key agreement
+ HKDF-SHA256. It does NOT test a TLS implementation, certificate validation, or key management; a deployment should use
TLS 1.3 with mutual authentication and pinned certificates, and this module only measures the integrity/overhead properties
that authenticated encryption provides.

Out of scope (state it): a man-in-the-middle can still DROP or DELAY messages (denial of service), and a channel does not
protect against a malicious client or a malicious server."""
import os, struct, time
import numpy as np
from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric.x25519 import X25519PrivateKey
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.hkdf import HKDF

HEADER = struct.Struct(">IIQ")            # client_id, round, counter (authenticated as AAD)
NONCE, TAG = 12, 16
TAMPERS = ["flip a ciphertext bit", "flip a tag bit", "flip a nonce bit", "change the round field", "change the client id",
           "truncate the message", "replace the payload (same header)", "replay an earlier message", "relabel as another client"]


CRYPTO_FIELDS = ("flip a ciphertext bit", "flip a tag bit", "flip a nonce bit")     # fields that only exist with authenticated encryption


class ChannelError(Exception):
    pass


def vec_to_bytes(v): return np.asarray(v, "<f4").tobytes()
def bytes_to_vec(b): return np.frombuffer(b, dtype="<f4").copy()


def establish_keys(n_clients):
    """X25519 + HKDF per client (client ephemeral key, server static key). Returns {client_id: 32-byte key}."""
    server = X25519PrivateKey.generate(); keys = {}
    for c in range(n_clients):
        cli = X25519PrivateKey.generate(); s = cli.exchange(server.public_key()); assert s == server.exchange(cli.public_key())
        keys[c] = HKDF(algorithm=hashes.SHA256(), length=32, salt=None, info=b"fl-channel|%d" % c).derive(s)
    return keys


def seal(key, client_id, rnd, counter, payload):
    aad = HEADER.pack(client_id, rnd, counter); nonce = os.urandom(NONCE)
    return aad + nonce + AESGCM(key).encrypt(nonce, payload, aad)


class ServerEndpoint:
    """Receiving side: verifies the AEAD tag against the header, rejects unknown clients, stale rounds and replayed counters."""

    def __init__(self, keys, expected_round=0):
        self.keys, self.expected_round, self.seen = keys, expected_round, set()

    def open(self, msg):
        if len(msg) < HEADER.size + NONCE + TAG: raise ChannelError("message too short")
        cid, rnd, ctr = HEADER.unpack(msg[:HEADER.size]); aad = msg[:HEADER.size]
        if cid not in self.keys: raise ChannelError("unknown client")
        if rnd != self.expected_round: raise ChannelError("stale or wrong round")
        if (cid, rnd, ctr) in self.seen: raise ChannelError("replay")
        nonce, ct = msg[HEADER.size:HEADER.size + NONCE], msg[HEADER.size + NONCE:]
        try: pt = AESGCM(self.keys[cid]).decrypt(nonce, ct, aad)
        except InvalidTag: raise ChannelError("authentication tag mismatch")
        self.seen.add((cid, rnd, ctr)); return cid, pt


def plain_send(client_id, rnd, counter, payload): return HEADER.pack(client_id, rnd, counter) + payload      # no protection at all
def plain_open(msg):
    if len(msg) < HEADER.size: raise ChannelError("message too short")
    return HEADER.unpack(msg[:HEADER.size])[0], msg[HEADER.size:]


def _flip(b, pos):
    b = bytearray(b); b[pos // 8] ^= 1 << (pos % 8); return bytes(b)


def tamper(kind, msg, rng, other=None, n_clients=5):
    """Returns the message after the man-in-the-middle's modification (or the original replayed). `other` is a second valid
    message of the same client used for payload replacement."""
    H, ct0 = HEADER.size, HEADER.size + NONCE
    if kind == "flip a ciphertext bit": return _flip(msg, 8 * ct0 + int(rng.integers(0, 8 * (len(msg) - ct0 - TAG))))
    if kind == "flip a tag bit": return _flip(msg, 8 * (len(msg) - TAG) + int(rng.integers(0, 8 * TAG)))
    if kind == "flip a nonce bit": return _flip(msg, 8 * H + int(rng.integers(0, 8 * NONCE)))
    if kind == "change the round field": c, r, k = HEADER.unpack(msg[:H]); return HEADER.pack(c, r + 1, k) + msg[H:]
    if kind == "change the client id": c, r, k = HEADER.unpack(msg[:H]); return HEADER.pack((c + 1) % n_clients, r, k) + msg[H:]
    if kind == "truncate the message": return msg[:-1]
    if kind == "replace the payload (same header)": return msg[:H] + other[H:]
    if kind == "replay an earlier message": return msg
    if kind == "relabel as another client": c, r, k = HEADER.unpack(msg[:H]); return HEADER.pack((c + 2) % n_clients, r, k) + msg[H:]
    raise ValueError(kind)


def evaluate_channel(n_trials=200, n_floats=262144, n_clients=5, seed=0):
    """For every tampering kind: how often the protected channel rejects it, how often the UNPROTECTED channel accepts the
    modified payload, and how often legitimate messages are wrongly rejected. Returns a list of dict rows."""
    rng = np.random.default_rng(seed); rows = []; false_rej = 0
    for kind in TAMPERS:
        rej = acc_plain = 0
        for t in range(n_trials):
            keys = establish_keys(n_clients); cid = int(rng.integers(0, n_clients)); srv = ServerEndpoint(keys, expected_round=1)
            payload = vec_to_bytes(rng.normal(size=n_floats)); payload2 = vec_to_bytes(rng.normal(size=n_floats))
            m = seal(keys[cid], cid, 1, 2 * t, payload); m2 = seal(keys[cid], cid, 1, 2 * t + 1, payload2)
            try: srv.open(m)                                                    # legitimate delivery must succeed
            except ChannelError: false_rej += 1
            if kind == "replay an earlier message": bad = m                    # the attacker re-sends a message the server already accepted
            else:
                srv = ServerEndpoint(keys, expected_round=1); bad = tamper(kind, m, rng, other=m2, n_clients=n_clients)
            try: srv.open(bad)
            except ChannelError: rej += 1
            pm = plain_send(cid, 1, 2 * t, payload); pm2 = plain_send(cid, 1, 2 * t + 1, payload2)
            try:                                                                # the same attack on a channel WITHOUT integrity protection
                pbad = _flip(pm, 8 * HEADER.size + int(rng.integers(0, 8 * len(payload)))) if kind in CRYPTO_FIELDS else tamper(kind, pm, rng, other=pm2, n_clients=n_clients)
                plain_open(pbad); acc_plain += 1                                # nothing can detect the change, so it is accepted
            except ChannelError: pass
        rows.append(dict(tampering=kind, trials=n_trials, rejected_with_authenticated_encryption=rej, accepted_without_protection=acc_plain))
    return rows, false_rej


def overhead(n_floats, repeats=3):
    """Cost of sealing/opening one full-size update."""
    rng = np.random.default_rng(0); keys = establish_keys(1); v = rng.normal(size=n_floats).astype("<f4"); b = v.tobytes()
    ts, to = [], []
    for r in range(repeats):
        t0 = time.perf_counter(); m = seal(keys[0], 0, 1, r, b); ts.append(time.perf_counter() - t0)
        srv = ServerEndpoint(keys, expected_round=1); t0 = time.perf_counter(); _, pt = srv.open(m); to.append(time.perf_counter() - t0)
    assert pt == b
    return dict(payload_MB=len(b) / 2 ** 20, extra_bytes=len(m) - len(b), extra_pct=100.0 * (len(m) - len(b)) / len(b),
                seal_s=float(np.mean(ts)), open_s=float(np.mean(to)))
