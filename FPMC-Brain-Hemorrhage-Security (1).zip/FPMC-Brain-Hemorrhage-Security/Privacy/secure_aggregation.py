"""Pairwise-masking secure aggregation (Bonawitz et al., CCS 2017), simplified. numpy + `cryptography` only.

What it does
  * every pair of clients (i, j) derives a shared seed by X25519 key agreement + HKDF-SHA256;
  * the seed keys an AES-256-CTR keystream (a cryptographic PRG) that is expanded to a mask vector m_ij over Z_(2^32);
  * client i uploads  y_i = q_i + sum_{j>i} m_ij - sum_{j<i} m_ji   (mod 2^32), where q_i is its fixed-point update;
  * the server sums the y_i; every mask appears once with + and once with -, so the sum of the y_i is the sum of the q_i.

What it does NOT do (state these as limitations)
  * no dropout recovery (the Shamir secret-sharing / double-masking step of the full protocol is not implemented): if one
    client's upload is missing the masks of its pairs do not cancel and the aggregate is garbage (tested);
  * the server is assumed honest-but-curious and not colluding with clients; a malicious server that lies about public keys
    (no authenticated key exchange here) or colluding clients can break the protection;
  * it hides INDIVIDUAL updates from the server, it does not hide what the AGGREGATE reveals (membership inference on the
    global model is unchanged) and it does not stop a malicious client from sending a poisoned update;
  * all clients are simulated in one process; the key exchange is therefore a simulation of the message flow, not a network
    implementation."""
import time
import numpy as np
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric.x25519 import X25519PrivateKey
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives.kdf.hkdf import HKDF

MOD_BITS = 32


def quantize(x, clip, scale_bits):
    """float vector -> uint32 residues of the fixed-point value round(clip(x) * 2^scale_bits) (two's complement mod 2^32)."""
    lim = 2.0 ** (MOD_BITS - 1 - scale_bits)
    if clip >= lim: raise ValueError(f"clip {clip} must be < {lim} for scale_bits={scale_bits} (the signed sum must fit in 32 bits)")
    q = np.rint(np.clip(np.asarray(x, np.float64), -clip, clip) * (2.0 ** scale_bits)).astype(np.int64)
    return (q & 0xFFFFFFFF).astype(np.uint32)


def dequantize(v, scale_bits):
    """uint32 residues (summed mod 2^32) -> float64 values, interpreting them as signed two's-complement integers."""
    return np.asarray(v, np.uint32).view(np.int32).astype(np.float64) / (2.0 ** scale_bits)


def _prg(seed32, n):
    """n uniform uint32 words from AES-256-CTR keyed with `seed32` (32 bytes), zero nonce (each seed is used once)."""
    enc = Cipher(algorithms.AES(seed32), modes.CTR(b"\x00" * 16)).encryptor()
    return np.frombuffer(enc.update(bytes(4 * n)), dtype=np.uint32)


class SecureAggregation:
    """One aggregation round for `n` clients and vectors of length `d`. Call `setup()` once, then `mask(i, update)` per client
    and `aggregate(masked)` on the server. `session` is mixed into the HKDF info so masks are never reused across rounds."""

    def __init__(self, n, d, clip=8.0, scale_bits=24, session=b"round-0"):
        self.n, self.d, self.clip, self.scale_bits, self.session = int(n), int(d), float(clip), int(scale_bits), bytes(session)
        self._seeds = {}
        self.setup_time_s = 0.0

    def setup(self):
        """Key agreement. Each client holds an X25519 key pair; public keys are relayed by the server; each pair derives the
        same 32-byte seed. (In a deployment the public keys must be authenticated, e.g. signed by a PKI.)"""
        t0 = time.perf_counter()
        priv = [X25519PrivateKey.generate() for _ in range(self.n)]; pub = [p.public_key() for p in priv]
        for i in range(self.n):
            for j in range(i + 1, self.n):
                s_ij = priv[i].exchange(pub[j]); s_ji = priv[j].exchange(pub[i]); assert s_ij == s_ji
                self._seeds[(i, j)] = HKDF(algorithm=hashes.SHA256(), length=32, salt=None, info=b"secagg-pair|" + self.session + b"|%d,%d" % (i, j)).derive(s_ij)
        self.setup_time_s = time.perf_counter() - t0
        return self

    def mask(self, i, update, weight=1.0):
        """Client i: fixed-point encode weight*update and add the pairwise masks. Returns the uint32 upload vector."""
        y = quantize(np.asarray(update, np.float64) * float(weight), self.clip, self.scale_bits)
        for j in range(self.n):
            if j == i: continue
            m = _prg(self._seeds[(min(i, j), max(i, j))], self.d)
            y = y + m if i < j else y - m            # uint32 arithmetic wraps modulo 2^32
        return y

    def aggregate(self, masked):
        """Server: modular sum of all uploads, decoded to floats. Equals sum_i weight_i * update_i up to quantisation error."""
        s = np.zeros(self.d, np.uint32)
        for y in masked: s = s + y
        return dequantize(s, self.scale_bits)


def secure_weighted_mean(U, weights, clip=8.0, scale_bits=24, session=b"round-0"):
    """Convenience: run one full round on the rows of U (n, d) with FedAvg weights. Returns (aggregate, masked uploads, SecureAggregation
    object, timing dict). `weights` are normalised to sum to 1 BEFORE masking (so the server only ever adds)."""
    U = np.asarray(U); n, d = U.shape; w = np.asarray(weights, float); w = w / w.sum()
    sa = SecureAggregation(n, d, clip, scale_bits, session).setup()
    t0 = time.perf_counter(); masked = [sa.mask(i, U[i], w[i]) for i in range(n)]; t_clients = time.perf_counter() - t0
    t0 = time.perf_counter(); agg = sa.aggregate(masked); t_server = time.perf_counter() - t0
    return agg, masked, sa, dict(setup_s=sa.setup_time_s, mask_s_per_client=t_clients / n, server_sum_s=t_server)


def signed_view(masked_upload, scale_bits=24):
    """What an eavesdropping server sees for ONE client, decoded as if it were that client's update (it is uniform noise)."""
    return dequantize(masked_upload, scale_bits)
