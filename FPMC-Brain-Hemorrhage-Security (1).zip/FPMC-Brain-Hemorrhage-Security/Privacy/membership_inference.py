"""Loss-threshold membership inference (Yeom et al.): members tend to have lower loss than non-members."""
import numpy as np
from sklearn.metrics import roc_auc_score, roc_curve


def mia_metrics(loss_members, loss_nonmembers):
    s = -np.r_[loss_members, loss_nonmembers]; lab = np.r_[np.ones(len(loss_members)), np.zeros(len(loss_nonmembers))]
    auc = roc_auc_score(lab, s); fpr, tpr, _ = roc_curve(lab, s)
    return dict(auc=float(auc), advantage=float((tpr - fpr).max()), tpr_at_5pct_fpr=float(np.interp(0.05, fpr, tpr)),
                n_members=len(loss_members), n_nonmembers=len(loss_nonmembers))


def per_sample_loss(model, X, y, device="cuda", mode="image", bs=64):
    import torch, torch.nn.functional as F
    from Preprocessing.image_preprocessing import to_tensor_input
    model.eval().to(device); out = []
    with torch.no_grad():
        for i in range(0, len(X), bs):
            xb = torch.from_numpy(to_tensor_input(X[i:i + bs])).to(device); yb = torch.from_numpy(y[i:i + bs]).long().to(device)
            out.append(F.cross_entropy(model(xb, None, mode), yb, reduction="none").cpu().numpy())
    return np.concatenate(out)
