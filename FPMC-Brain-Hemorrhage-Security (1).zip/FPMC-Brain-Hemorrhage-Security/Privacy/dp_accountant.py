"""Privacy accounting for CLIENT-LEVEL differentially private FedAvg (McMahan et al., ICLR 2018). numpy + scipy.

Mechanism (per round): every client's update is clipped to L2 norm <= C; the server adds Gaussian noise with std z*C to the SUM
of the clipped updates (z = noise multiplier) and divides by the number of clients. All clients participate in every round (no
client sampling), so each round is one plain Gaussian mechanism with L2 sensitivity C (add/remove-one-client adjacency) and the
T rounds compose adaptively. Guarantee: (epsilon, delta)-DP with respect to ONE CLIENT's whole dataset, for anyone who sees
the sequence of global models.  It is NOT record-level DP and says nothing about a client that is itself malicious.

Accounting uses Renyi DP:  RDP of the Gaussian mechanism at order a is a/(2 z^2) per round, T rounds add up, and the conversion to
(eps, delta) uses Balle et al. (AISTATS 2020, Thm 21).  `exact_gaussian_eps` gives the exact analytic value (Balle & Wang, ICML
2018) for T identical Gaussian mechanisms (equivalent to one mechanism with multiplier z/sqrt(T)); the RDP value must be >= it."""
import math
import numpy as np
from scipy.optimize import brentq
from scipy.stats import norm

ORDERS = np.concatenate([np.linspace(1.01, 2.0, 100), np.arange(2.05, 12.0, 0.05), np.arange(12.0, 64.0, 1.0), [80., 100., 128., 256., 512.]])


def rdp_gaussian(z, steps, orders=ORDERS):
    z = float(z)
    if z <= 0: return np.full_like(orders, np.inf, dtype=float)
    return steps * np.asarray(orders, float) / (2.0 * z * z)


def eps_from_rdp(rdp, delta, orders=ORDERS):
    """Balle et al. 2020 conversion, minimised over the orders. Returns (epsilon, best_order)."""
    a = np.asarray(orders, float); r = np.asarray(rdp, float)
    eps = r + np.log1p(-1.0 / a) - (math.log(delta) + np.log(a)) / (a - 1.0)
    k = int(np.nanargmin(eps)); return float(max(eps[k], 0.0)), float(a[k])


def epsilon(z, steps, delta=1e-5):
    """(eps, delta)-DP of `steps` rounds of the Gaussian mechanism with noise multiplier z. z == 0 -> inf."""
    if z <= 0: return float("inf"), float("nan")
    return eps_from_rdp(rdp_gaussian(z, steps), delta)


def exact_gaussian_eps(z, steps, delta=1e-5):
    """Exact epsilon of T-fold composition of the Gaussian mechanism (sensitivity 1, std z): one Gaussian with std z/sqrt(T)."""
    s = z / math.sqrt(steps)
    d_of = lambda e: norm.cdf(-e * s + 1.0 / (2 * s)) - math.exp(e) * norm.cdf(-e * s - 1.0 / (2 * s))
    if d_of(0.0) <= delta: return 0.0
    if d_of(500.0) > delta: return float("inf")
    return float(brentq(lambda e: d_of(e) - delta, 0.0, 500.0))


def calibrate_noise_multiplier(eps_target, steps, delta=1e-5, hi=200.0):
    """Smallest z (by bisection) whose RDP epsilon is <= eps_target after `steps` rounds."""
    lo = 1e-3
    for _ in range(80):
        mid = 0.5 * (lo + hi)
        if epsilon(mid, steps, delta)[0] > eps_target: lo = mid
        else: hi = mid
    return hi


def dp_fedavg_aggregate(U, clip, z, rng):
    """Client-level DP aggregation of the rows of U (n, d): clip each row to L2 <= clip, average with EQUAL weights (so the
    sensitivity of the mean is clip/n; weighting by data size would change the sensitivity), add N(0, (z*clip/n)^2) noise.
    Returns (noisy_mean, info). clip=None and z=0 gives the plain equal-weight mean."""
    U = np.asarray(U, np.float64); n = len(U); norms = np.linalg.norm(U, axis=1)
    if clip is not None: U = U * np.minimum(1.0, clip / (norms + 1e-12))[:, None]
    m = U.mean(0)
    if z > 0: m = m + rng.normal(0.0, z * clip / n, m.shape)
    return m, dict(norms=norms, clipped_fraction=float((norms > clip).mean()) if clip is not None else 0.0)
