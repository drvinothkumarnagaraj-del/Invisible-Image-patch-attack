"""Gradient inversion (Deep Leakage from Gradients with the label known/inferred): optimise a dummy image so that its
gradient matches the victim's gradient. Quality: PSNR, SSIM (+ LPIPS if installed)."""
import numpy as np, cv2


def psnr_f(a, b):
    mse = np.mean((a.astype(np.float64) - b.astype(np.float64)) ** 2); return 99.0 if mse < 1e-10 else float(10 * np.log10(255.0 ** 2 / mse))


def ssim(a, b):
    a, b = a.astype(np.float64), b.astype(np.float64); C1, C2 = (0.01 * 255) ** 2, (0.03 * 255) ** 2
    g = lambda x: cv2.GaussianBlur(x, (11, 11), 1.5)
    mu_a, mu_b = g(a), g(b); sa, sb, sab = g(a * a) - mu_a ** 2, g(b * b) - mu_b ** 2, g(a * b) - mu_a * mu_b
    return float(np.mean(((2 * mu_a * mu_b + C1) * (2 * sab + C2)) / ((mu_a ** 2 + mu_b ** 2 + C1) * (sa + sb + C2))))


def _tv(x): return (x[..., 1:, :] - x[..., :-1, :]).abs().mean() + (x[..., :, 1:] - x[..., :, :-1]).abs().mean()


def _math_attention_ctx():
    """Fused SDPA kernels have no double-backward, which gradient inversion needs -> force the plain 'math' kernel."""
    import contextlib, torch
    try:
        from torch.nn.attention import sdpa_kernel, SDPBackend
        return sdpa_kernel(SDPBackend.MATH)
    except Exception:
        try:
            torch.backends.cuda.enable_flash_sdp(False); torch.backends.cuda.enable_mem_efficient_sdp(False); torch.backends.cuda.enable_math_sdp(True)
        except Exception:
            pass
        return contextlib.nullcontext()


def invert(model, x_uint8, y, device="cuda", iters=200, lr=0.1, noise_sigma=0.0, clip=None, tv=1e-4, seed=0):
    """Returns the reconstruction (uint8 HxW). noise_sigma/clip emulate a clipped+noised gradient the server would see."""
    import torch, torch.nn.functional as F
    from Preprocessing.image_preprocessing import to_tensor_input
    torch.manual_seed(seed); model.eval().to(device)
    try:
        from timm.layers import set_fused_attn; set_fused_attn(False)
    except Exception:
        pass
    params = [p for p in model.b.parameters() if p.requires_grad] + list(model.ihead.parameters())
    x = torch.from_numpy(to_tensor_input(x_uint8[None])).to(device); yt = torch.tensor([int(y)], device=device)
    with _math_attention_ctx():
        g = torch.autograd.grad(F.cross_entropy(model(x, None, "image"), yt), params)
        if clip is not None:
            nrm = torch.sqrt(sum((gi ** 2).sum() for gi in g)); g = [gi * min(1.0, clip / (nrm.item() + 1e-12)) for gi in g]
        if noise_sigma > 0: g = [gi + torch.randn_like(gi) * noise_sigma * (clip or 1.0) for gi in g]
        g = [gi.detach() for gi in g]
        d = torch.randn_like(x, requires_grad=True); opt = torch.optim.Adam([d], lr=lr)
        for _ in range(iters):
            opt.zero_grad()
            gd = torch.autograd.grad(F.cross_entropy(model(d, None, "image"), yt), params, create_graph=True)
            loss = sum(((a - b) ** 2).sum() for a, b in zip(gd, g)) + tv * _tv(d)
            loss.backward(); opt.step()
    rec = ((d.detach()[0].mean(0).cpu().numpy() * 0.5 + 0.5).clip(0, 1) * 255).astype(np.uint8)
    return rec


def reconstruction_quality(orig, rec):
    out = dict(psnr=psnr_f(orig, rec), ssim=ssim(orig, rec))
    try:
        import lpips, torch
        fn = lpips.LPIPS(net="alex", verbose=False)
        t = lambda im: torch.from_numpy(np.repeat(im[None, None].astype(np.float32) / 127.5 - 1, 3, 1))
        out["lpips"] = float(fn(t(orig), t(rec)).item())
    except Exception:
        out["lpips"] = float("nan")
    return out
