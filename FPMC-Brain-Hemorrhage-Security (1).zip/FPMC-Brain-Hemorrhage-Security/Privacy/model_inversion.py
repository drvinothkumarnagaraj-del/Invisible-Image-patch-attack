"""Class-representative model inversion (Fredrikson et al., CCS 2015, adapted to images) against a trained GLOBAL model.
Unlike gradient inversion (which needs a client's update) this needs only the final model, i.e. it is available to every
participant and to anyone who obtains the model. For each target class we optimise a synthetic image so the model assigns it
that class with high confidence (+ total-variation and L2 priors), then ask how close the result is to REAL images:
  SSIM / PSNR to the mean TRAINING image of the target class, to the mean training image of the OTHER classes,
  and to the mean HELD-OUT image of the target class when one exists.
If the inversion recovered class-specific (or training-specific) content, similarity to the target-class mean exceeds similarity
to the other-class mean (and to the held-out mean). The numbers are small-sample indications, not proofs of (non-)leakage.
torch is imported lazily."""
import numpy as np
from Privacy.gradient_inversion import ssim, psnr_f


def _tv(x): return (x[..., 1:, :] - x[..., :-1, :]).abs().mean() + (x[..., :, 1:] - x[..., :, :-1]).abs().mean()


def invert_class(model, target, size, device="cuda", iters=300, lr=0.05, tv=1e-2, l2=1e-3, seed=0, mode="image"):
    """Returns (uint8 image HxW, softmax probability of the target class for the optimised input)."""
    import torch, torch.nn.functional as F
    torch.manual_seed(seed); model.eval().to(device)
    for p in model.parameters(): p.requires_grad_(False)
    x = (torch.randn(1, 3, size, size, device=device) * 0.1).requires_grad_(True); opt = torch.optim.Adam([x], lr=lr); t = torch.tensor([int(target)], device=device)
    for _ in range(iters):
        opt.zero_grad(); xc = x.clamp(-1, 1)
        loss = F.cross_entropy(model(xc, None, mode), t) + tv * _tv(xc) + l2 * (xc ** 2).mean(); loss.backward(); opt.step()
    with torch.no_grad():
        xc = x.clamp(-1, 1); p = torch.softmax(model(xc, None, mode), 1)[0, int(target)].item()
    for p_ in model.parameters(): p_.requires_grad_(True)
    return ((xc[0].mean(0).cpu().numpy() * 0.5 + 0.5).clip(0, 1) * 255).astype(np.uint8), float(p)


def _mean_img(X): return None if len(X) == 0 else X.astype(np.float64).mean(0)


def similarity_row(inv, X_cls_train, X_other_train, X_cls_heldout=None):
    """inv uint8 (H,W). Returns SSIM/PSNR against the class means (NaN when the reference set is empty)."""
    nan = float("nan"); ref = {"own-class train mean": _mean_img(X_cls_train), "other-class train mean": _mean_img(X_other_train),
                               "own-class held-out mean": _mean_img(X_cls_heldout) if X_cls_heldout is not None else None}
    out = {}
    for k, m in ref.items():
        out[f"SSIM vs {k}"] = nan if m is None else ssim(inv, m); out[f"PSNR vs {k}"] = nan if m is None else psnr_f(inv, m)
    return out
