# Corrections to the original code

Each item is a bug or an unsupported assumption that made reported numbers optimistic or impossible to reproduce.

| # | File | Problem in the original | Correction |
|---|---|---|---|
| 1 | `run_step2_patch_detection.py` | The final patch detector (saved for steps 3-7) was fitted on **all** real images, including the test split, then evaluated on the test images. | Fit on **train** only; alarm threshold from **clean validation** images only; every reported number is measured on the **test** images. New function `fit_detector_split`. |
| 2 | `run_step2_patch_detection.py` (adaptive table) | Clean scores for FPR/AUC came from images the detector had been trained on (in-sample). | Clean and attacked scores are both computed on held-out test images. |
| 3 | `run_step2_patch_detection.py` | Defender-simulated attacks used triggers from all images (including test) and were generated twice (a different set for each detector). | Triggers come from the train split only; one simulated set is shared by both detectors. |
| 4 | `Federated_Learning/client_training.py` (`sanitize_client`) and `run_step3_...py` | FPMC "restored" the **true label** and the original note embedding of any flagged sample, and at inference restored the clean embedding. A real defender does not have either. | Default `defense.flag_action: quarantine` removes flagged samples; flagged notes are replaced by a zero text embedding at inference. The old behaviour remains as `restore_reference`, labelled an **oracle upper bound**. |
| 5 | `run_step3_...py` | FedAvg / FedProx / RFA used equal client weights although client sizes differ (136, 122, 110, 61, 60). | Weighted by the number of training samples per client (FedAvg definition). |
| 6 | `run_step1_prepare_data.py` | CLAHE parameters and the cosine threshold were selected using test-split images and captions. | Chosen from train (CLAHE) and train+val (cosine threshold) only. |
| 7 | `run_step1_prepare_data.py` | No record of how many images were real vs augmented per split. | Fails if an augmented image is outside train or a source group spans two splits; writes `step1_data_audit.csv` (real/augmented x split x class) and `run_manifest.json` (config + versions). |
| 8 | `run_step4_adaptive_attacks.py` | ASR and detection were reported for one attack strength. | Adds a sweep over `attack.alphas`: detection TPR/FPR and ASR (undefended, FPMC-trained, FPMC + defence) at each strength. |
| 9 | `common.py` | `cudnn` non-deterministic. | Deterministic flags set. |
| 10 | `Detection/poa_window.py` (new), `run_step2_patch_detection.py`, `maxvit_detection.py` | POA only tuned CLAHE; the manuscript says POA tunes the MaxViT local attention window. | The Pelican Optimization Algorithm now searches a window (x, y, h, w) on the MaxViT Grad-CAM map; the detector uses the CAM statistics inside that window. The search uses **train images only**. Step 2 reports an ablation: whole-image Grad-CAM vs POA-window Grad-CAM vs FFT baseline, so you can see whether the window helps. |
| 11 | `Configuration/experiment_config.yaml`, `common.py` | Results were written to `FPMC_BH_sorted/fpmc_results`, inside the dataset folder. | Results go to `<results_root>/<run_name>` = `/content/drive/MyDrive/FPMC_Final_Results/final_run1`. `load_config` refuses any results folder inside the dataset folder. Change `run_name` for each new run so nothing is overwritten. |

New: `Evaluation/protocol.py` (split audit and guards), `tests/test_fixes.py`.

## What these corrections do NOT do
* They do not change the amount of data. The index CSV contains 134 real image-caption pairs (40 hemorrhage, 94 control);
  the "526" is reached by augmenting the training split. Say this in the paper.
* They do not make any metric reach a target. Accuracy, detection rate, ASR and FPR are outputs. With ~17 real test images
  one image moves accuracy by ~6 points, so 95.4% is not even attainable at that size, and every rate has a wide interval.
* POA window fitness. Manuscript Eq. 11 (variance + mean attention) contains no attack information, so it cannot find where
  an attack leaves a trace. The default fitness is the train-only cross-validated AUC of clean vs defender-simulated attack
  (`fitness: separability`), with a small window-area penalty as a tie-breaker. Update Eq. 11 in the manuscript to match
  (`fitness: eq11` keeps the original form as a baseline). The window is a region on the Grad-CAM map; MaxViT's internal
  partitioning is unchanged. Whether it helps is decided by the ablation table, not assumed.
* The text check assumes a trusted reference copy of each note (e.g. a hash-verified EHR original). State this assumption.

## Step 8 (new): privacy and security threats not evaluated before

`run_step8_extended_privacy_security.py` plus `Privacy/secure_aggregation.py`, `Privacy/dp_accountant.py`, `Privacy/client_inference.py`,
`Privacy/model_inversion.py`, `Privacy/channel_security.py`, `Federated_Learning/partition.py`, config section `privacy_ext`, `tests/test_step8.py`.
Adds: pairwise-masking secure aggregation (exactness, hidden individual updates, dropout failure); client-level DP-FedAvg with RDP accounting
cross-checked against the exact Gaussian epsilon; client-level membership and class-composition inference on individual updates, the aggregate,
masked uploads and DP aggregates; class-representative model inversion; man-in-the-middle tampering with and without authenticated encryption.
No numbers are included in the repository: they come from running the script.
