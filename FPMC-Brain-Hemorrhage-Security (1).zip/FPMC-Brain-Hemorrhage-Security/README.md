# FPMC-Brain-Hemorrhage-Security

Secure federated brain-hemorrhage MRI classification (FPMC): POA-optimised CLAHE, FIBA invisible-patch attack and
detection (MaxViT + Grad-CAM), CAM-guided LaMa inpainting, Clinical BioBERT caption-integrity checking, and federated
training. This repository additionally contains the experiments requested in reviewer comments 5-7 and the extended privacy/security evaluation (step 8):
**adaptive/unseen attacks, robust-aggregation baselines, privacy attacks, and a measured computational budget.**

> Everything below is meant to be run on **Google Colab (T4)**. `python tests/test_pure.py` runs without a GPU and checks
> the numpy-level logic (attacks, aggregators, negation analysis, statistics, privacy metrics).

> **Data are not included.** The MRI images and clinical notes are not distributed here. Put your dataset where
> `Configuration/experiment_config.yaml` points (see `Dataset/dataset_description.md`). Results are written outside the dataset folder.

> **Evaluation protocol (corrected).** Detectors are fitted on the train split, thresholds are set on clean validation images,
> and all reported rates are measured on the test split. Augmented copies are training-only. See `CHANGES.md` for the list of
> fixes. Metrics are outputs of the experiment, never targets.

## Layout

| folder | content |
|---|---|
| `Preprocessing/` | `clahe.py` (CLAHE + Pelican Optimization), `image_preprocessing.py` (dataset loader) |
| `Attacks/` | `fiba_attack.py`, `patch_generation.py` (location/size/frequency/intensity variants), `adaptive_attacks.py` (detector-aware), `label_poisoning.py` (seen + unseen caption attacks, adaptive caption attack) |
| `Detection/` | `gradcam.py`, `maxvit_detection.py` (Grad-CAM detector + FFT baseline), `clinical_biobert.py` (embeddings, integrity features, evaluation protocol) |
| `Defense/` | `lama_inpainting.py`, `negation_detection.py` (present/absent/uncertain), `terminology_restoration.py`, `fpmc_defense.py` |
| `Federated_Learning/` | `fedprox.py`, `client_training.py`, `global_aggregation.py` (FedAvg, Krum/Multi-Krum, Median, Trimmed mean, RFA, FLTrust, communication cost) |
| `Privacy/` | `gradient_inversion.py`, `label_inference.py`, `membership_inference.py`; step 8: `secure_aggregation.py`, `dp_accountant.py`, `client_inference.py`, `model_inversion.py`, `channel_security.py` |
| `Evaluation/` | classification metrics, conditional ASR, detection metrics (nested calibration), confidence intervals, computational overhead |
| `Configuration/experiment_config.yaml` | all paths and hyper-parameters. Results are written to `results_root/run_name` (outside the dataset folder); `Detection/poa_window.py` holds the POA attention-window search |

## Step by step (Colab)

```python
from google.colab import drive; drive.mount('/content/drive')
!pip install -q -r requirements.txt
%cd /content/FPMC-Brain-Hemorrhage-Security      # wherever you copied the repository
```
0. **Dataset** - rebuild `balanced_526` with the verify/expand script. It MUST contain control images
   (the code stops otherwise). Edit `Configuration/experiment_config.yaml` paths if needed.
1. `python run_step1_prepare_data.py` - loads data, POA-CLAHE, Clinical BioBERT embeddings, calibrates the cosine threshold
   on genuine wording variation.
2. `python run_step2_patch_detection.py` - patch detection: strength sweep (alpha, beta), Grad-CAM vs FFT baseline,
   then **adaptive** attacks (location, frequency, intensity, size) the detector never saw. -> Table A (image part)
3. `python run_step3_federated_baselines.py` - FedAvg, FedProx, Krum, Multi-Krum, Median, Trimmed mean, RFA, FLTrust, FPMC under
   `clean`, `data_poison`, `model_poison`. -> Table B
4. `python run_step4_adaptive_attacks.py` - TPR/FPR, accuracy and ASR per adaptive attack on the trained models + a
   detector-aware black-box attack. -> Table A
5. `python run_step5_caption_attacks.py` - SEEN vs UNSEEN caption attacks, calibration/test split by source group, adaptive
   cosine-aware attack, image-report consistency. -> Table A (text part)
6. `python run_step6_privacy_attacks.py` - membership inference, label inference, gradient inversion. -> Table C
7. `python run_step7_computational_overhead.py` - per-component latency, peak GPU/RAM, parameters, communication. -> Table D

8. `python run_step8_extended_privacy_security.py` - secure aggregation (pairwise masking), client-level DP-FedAvg with (epsilon, delta)
   accounting, client-level membership / class-composition inference, class-representative model inversion, channel tampering
   (man-in-the-middle). Needs only the step-1 cache; trains 6 clean FL runs (about the cost of 6 methods in step 3). -> Table E

`python run_all.py` runs 1-8. Run `python tests/test_pure.py && python tests/test_fixes.py && python tests/test_step8.py` first (no GPU needed). Set `quick: true` for a smoke test only (never report quick results). All tables are saved as
CSV in `paths.out_dir`.

## What the results can and cannot support (read before writing the paper)

* **Report negative results.** If the detector's AUC stays near 0.5 for an adaptive attack, or caption detection is
  low on unseen attacks, say so. Do not tune on the test split.
* **Krum / Median / Trimmed mean / RFA / FLTrust** defend the *model-update* channel; FPMC's patch/caption checks defend the
  *data* channel. Table B therefore has both attack scenarios; FPMC is *expected* to be weak under `model_poison`.
* **Privacy.** Local training keeps raw data on clients, but this is not a privacy guarantee. The code evaluates three
  update-based threats in step 6; step 8 adds secure aggregation, client-level DP with accounting, client-level inference, model
  inversion and channel tampering. The clip+noise probe in step 6 gives **no (epsilon, delta)** and must not be called differential
  privacy; only the step-8 DP-FedAvg runs carry a client-level (epsilon, delta). Step-8 limits: secure aggregation is a single-process
  simulation without dropout recovery and does not change what the aggregate reveals; DP is client-level (not record-level), with
  only 5 clients the noise needed for a meaningful epsilon is expected to destroy utility (the table shows it); the clip is taken from
  round-0 norms; the channel test simulates AES-GCM authenticated encryption, not a TLS stack or certificate handling; a man-in-the-middle
  can still drop or delay messages. Report whatever the tables show.
* **Detector-aware attack** uses black-box random search (weak). A gradient-based white-box attacker would be stronger;
  list this as a limitation.
* **Caption variants** are rule-generated, not written by independent radiologists; flags mean "send for verification".
* **Samples are small** (a few real test images per class). Read the Wilson/bootstrap intervals; zero observed successes in
  11 trials still allows ~26% (upper 95% bound).
* **Computation.** Step 7 measures each component at batch size 1 with warm-up and CUDA synchronisation, reporting mean, std, median,
  IQR, peak GPU memory and peak process RAM separately. Federated communication is `R x N x (down + up)` model bytes; the image/caption checks
  add no payload because no masks, reports or embeddings are uploaded. Do not quote the old 1.30 s / 3,218 MB figures unless you
  can state what they measured.
* Keep **classification accuracy, attack detection and attack mitigation** in separate tables.

## Reviewer-comment map

| comment | script(s) | output tables |
|---|---|---|
| 5 adaptive / unseen attacks, FL baselines | step2 (b), step3, step4, step5 | `step2b_*`, `step3_*`, `step4a/b_*`, `step5a/b_*` |
| 6 privacy | step6 (+ README statement) | `step6a/b/c_*` |
| 6 (extended privacy/security) | step8 | `step8a_*` ... `step8e_*`, `step8d_model_inversion.png` |
| 7 computational overhead | step7 | `step7a/b/c_*` |

## License
MIT
