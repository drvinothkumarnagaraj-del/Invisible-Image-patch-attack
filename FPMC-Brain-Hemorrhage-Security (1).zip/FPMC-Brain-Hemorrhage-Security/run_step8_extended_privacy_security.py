"""STEP 8 - privacy and security threats that steps 1-7 did not evaluate:
  8A secure aggregation (pairwise masking)            8B formal client-level differential privacy (DP-FedAvg + RDP accounting)
  8C client-level inference (membership, class composition) against individual updates, the aggregate, masked uploads and DP aggregates
  8D model inversion beyond gradient inversion (class-representative inversion of the trained global model)
  8E communication-channel tampering / man-in-the-middle (authenticated encryption vs no protection)
Needs only the step-1 cache (data.npz). All FL runs here are CLEAN (no attacker), FedAvg with EQUAL client weights (client-level DP
needs equal weights), the same partition and local-training settings as step 3.
Every number printed or saved comes from running this script; none is hard-coded. `quick: true` in the config gives a smoke test
whose numbers must not be reported. Set FPMC_CONFIG to use another config file."""
import copy, os, time
import numpy as np, pandas as pd, torch
from common import *
from Federated_Learning.client_training import MultimodalNet, local_train, predict
from Federated_Learning.global_aggregation import state_to_vec, vec_to_state
from Federated_Learning.partition import partition_clients
from Evaluation.classification_metrics import classification_report
from Privacy.secure_aggregation import secure_weighted_mean, signed_view, SecureAggregation
from Privacy.dp_accountant import epsilon, exact_gaussian_eps, calibrate_noise_multiplier, dp_fedavg_aggregate
from Privacy.client_inference import UpdateLossProbe, membership_from_delta, summarize_clients, class_composition_inference, param_slices
from Privacy.model_inversion import invert_class, similarity_row
from Privacy import channel_security as ch

cfg = load_config(os.environ.get("FPMC_CONFIG")); set_seed(cfg["seed"]); dev = device(); D = load_cache(cfg); fl = cfg["federated"]; px = cfg["privacy_ext"]
quick = bool(cfg["quick"]); R = 2 if quick else fl["rounds"]; Z = [1.0] if quick else list(px["dp_noise_multipliers"]); DELTA = float(px["dp_delta"])
Xc, y, E, split, grp, is_aug = D["Xc"], D["y"], D["E_orig"], D["split"], D["grp"], D["is_aug"]
EV = cfg["data"]["classes"].index(cfg["data"]["evade_class"]); NC = len(cfg["data"]["classes"]); N = fl["n_clients"]
tr = np.where(split == "train")[0]; te = np.where((split == "test") & ~is_aug)[0]; ho = np.where((split != "train") & ~is_aug)[0]
client_idx = partition_clients(grp, y, tr, N, NC, np.random.RandomState(cfg["seed"]))
real_tr = [ci[~is_aug[ci]] for ci in client_idx]
print("client sizes:", [len(c) for c in client_idx], "| real (non-augmented) per client:", [len(c) for c in real_tr], "| held-out real:", len(ho), "| test:", len(te))
if quick: print("*** QUICK MODE: smoke test only, do not report these numbers ***")


def new_model(): return MultimodalNet(cfg["backbone"]["name"], NC, text_dim=E.shape[1], pretrained=cfg["backbone"]["pretrained"]).to(dev)


def run_fl(tag, clip, z, secagg=False):
    """R rounds of equal-weight FedAvg. Aggregation = clip each client update to `clip` (None = no clipping), average, add N(0,(z*clip/N)^2).
    With secagg=True every round's plain mean is ALSO computed through the masking protocol and compared (the plain mean advances the model)."""
    print(f"\n--- {tag} (clip={clip}, z={z}) ---"); set_seed(cfg["seed"]); base = new_model()
    gsd = {k: v.detach().cpu().clone() for k, v in base.state_dict().items()}; gvec = state_to_vec(gsd); out = dict(rounds=[], tmpl=gsd, gvec0=gvec.copy())
    for r in range(R):
        U = []
        for c in range(N):
            idx = client_idx[c]; m = copy.deepcopy(base); m.load_state_dict(gsd)
            local_train(m, Xc[idx], E[idx], y[idx], fl["local_epochs"], fl["lr"], fl["weight_decay"], fl["batch_size"], dev, 0.0, None, fl["text_dropout"], cfg["seed"] + r * 100 + c)
            U.append(state_to_vec({k: v.cpu() for k, v in m.state_dict().items()}) - gvec); del m
        U = np.stack(U); rng = np.random.default_rng(cfg["seed"] + 1000 + r)
        agg, info = dp_fedavg_aggregate(U, clip, z, rng); rec = dict(round=r, clipped_fraction=info["clipped_fraction"], mean_update_norm=float(np.linalg.norm(U.mean(0))))
        if z > 0: rec["noise_norm"] = float(z * clip / N * np.sqrt(U.shape[1]))
        if secagg:
            sa_clip, bits = px["secagg"]["clip"], px["secagg"]["scale_bits"]
            agg_sa, masked, sa, tm = secure_weighted_mean(U, np.ones(N), sa_clip, bits, session=b"round-%d" % r)
            rec.update(sa_max_abs_err=float(np.abs(agg_sa - U.astype(np.float64).mean(0)).max()), sa_bound=N * 0.5 / 2 ** bits,
                       sa_clipped_coord_fraction=float((np.abs(U / N) > sa_clip).mean()), **{f"sa_{k}": v for k, v in tm.items()})
            if r == 0:                                    # kept for the attacks below
                w = np.full(N, 1.0 / N); out["masked0"] = masked
                out["sa_view_corr"] = [float(np.corrcoef(signed_view(masked[c], bits)[:200000], (U[c] * w[c])[:200000])[0, 1]) for c in range(N)]
                out["dropout_err"] = float(np.abs(sa.aggregate(masked[1:]) - (U[1:].astype(np.float64) * w[1:, None]).sum(0)).max())
            else: del masked
        if r == 0: out["U0"] = U.copy()
        out["rounds"].append(rec); gvec = (gvec + agg).astype(np.float32); gsd = vec_to_state(gvec, gsd)
        print(f"  round {r + 1}/{R}: |mean update| {rec['mean_update_norm']:.4f}" + (f", sa err {rec['sa_max_abs_err']:.2e}" if secagg else "") + (f", noise norm {rec['noise_norm']:.2f}" if z > 0 else ""))
        base.load_state_dict(gsd)
    base.load_state_dict(gsd); pc = predict(base, Xc[te], E[te], "fused", dev); rep = classification_report(y[te], pc, EV)
    out.update(model_sd={k: v.clone() for k, v in gsd.items()}, report=rep); del base; torch.cuda.empty_cache(); return out


# ===================== training runs =====================
plain = run_fl("FedAvg, equal weights, no clipping, no noise", None, 0.0, secagg=True)
U0, gvec0, tmpl = plain["U0"], plain["gvec0"], plain["tmpl"]; norms0 = np.linalg.norm(U0, axis=1)
CLIP = float(np.median(norms0)) if px["dp_clip"] == "median" else float(px["dp_clip"])
print(f"\nround-0 client update norms: {np.round(norms0, 3).tolist()} -> DP clip C = {CLIP:.4f}")
runs = {"FedAvg (equal weights), no clip/noise": plain}
ONLY8A = os.environ.get("FPMC_STEP8_ONLY", "").lower() == "8a"
if ONLY8A: Z = []
if not quick and not ONLY8A: runs[f"clip C={CLIP:.3g}, no noise (no DP guarantee)"] = run_fl("clip only", CLIP, 0.0)
for z in Z: runs[f"DP-FedAvg z={z}"] = run_fl(f"DP-FedAvg z={z}", CLIP, z)

# ===================== 8A secure aggregation =====================
rr = plain["rounds"]
if max(r["sa_clipped_coord_fraction"] for r in rr) > 0: print("WARNING: some coordinates were clipped by the fixed-point encoder, so the secure-aggregation error below is dominated by clipping, not by the protocol. Raise privacy_ext.secagg.clip (must stay < 2^(31-scale_bits)).")
sa_rows = [{"quantity": "rounds checked", "value": len(rr)},
    {"quantity": "max |secure aggregate - plain mean| over all rounds and coordinates", "value": f"{max(r['sa_max_abs_err'] for r in rr):.3e}"},
    {"quantity": "theoretical bound n*0.5/2^scale_bits", "value": f"{rr[0]['sa_bound']:.3e}"},
    {"quantity": "fraction of coordinates clipped by the fixed-point encoder (max over rounds)", "value": f"{max(r['sa_clipped_coord_fraction'] for r in rr):.3e}"},
    {"quantity": "correlation(masked upload decoded as an update, true weighted update), mean over clients (round 0)", "value": f"{np.mean(plain['sa_view_corr']):.4f}"},
    {"quantity": "max error of the aggregate when ONE client's upload is missing (no dropout recovery implemented)", "value": f"{plain['dropout_err']:.3e}"},
    {"quantity": "key agreement, all client pairs (s per round, mean)", "value": f"{np.mean([r['sa_setup_s'] for r in rr]):.3f}"},
    {"quantity": "masking per client (s per round, mean)", "value": f"{np.mean([r['sa_mask_s_per_client'] for r in rr]):.3f}"},
    {"quantity": "server modular sum (s per round, mean)", "value": f"{np.mean([r['sa_server_sum_s'] for r in rr]):.4f}"},
    {"quantity": "upload size per client vs plain float32 update", "value": "same (uint32 per coordinate)"}]
save_table(pd.DataFrame(sa_rows), cfg, "step8a_secure_aggregation")
if os.environ.get("FPMC_STEP8_ONLY", "").lower() == "8a": print("FPMC_STEP8_ONLY=8a: stopping after the secure-aggregation table."); raise SystemExit

# ===================== 8B formal client-level DP =====================
zs_all = sorted(set([0.5, 1.0, 2.0, 4.0, 8.0] + Z)); acc = []
for z in zs_all: acc.append({"noise multiplier z": z, "rounds": R, "delta": DELTA, "epsilon (RDP accountant)": round(epsilon(z, R, DELTA)[0], 3), "epsilon (exact analytic Gaussian)": round(exact_gaussian_eps(z, R, DELTA), 3)})
for e in px["eps_targets"]: acc.append({"noise multiplier z": round(calibrate_noise_multiplier(e, R, DELTA), 3), "rounds": R, "delta": DELTA, "epsilon (RDP accountant)": e, "epsilon (exact analytic Gaussian)": "calibrated to this target"})
save_table(pd.DataFrame(acc), cfg, "step8b_dp_accounting")
ut = []
for name, o in runs.items():
    z = float(name.split("z=")[1]) if "z=" in name else 0.0; rep = o["report"]; rds = o["rounds"]
    ut.append({"configuration": name, "epsilon at delta": "no guarantee" if z == 0 else round(epsilon(z, R, DELTA)[0], 2), "accuracy (clean test)": rep["accuracy"], "macro-F1": rep["macro_f1"],
               "hemorrhage sensitivity": rep["hemorrhage_sensitivity"], "control specificity": rep["control_specificity"],
               "clipped fraction (round 1 / last)": f"{rds[0]['clipped_fraction']:.2f} / {rds[-1]['clipped_fraction']:.2f}",
               "noise norm / update norm (round 1 / last)": "n/a" if z == 0 else f"{rds[0]['noise_norm'] / rds[0]['mean_update_norm']:.1f} / {rds[-1]['noise_norm'] / max(rds[-1]['mean_update_norm'], 1e-12):.1f}"})
save_table(pd.DataFrame(ut), cfg, "step8b_dp_utility")

# ===================== 8C client-level inference (round-0 updates) =====================
rs = np.random.RandomState(cfg["seed"] + 7)
cand = np.concatenate([np.concatenate(real_tr), ho]); pos_of = {int(i): k for k, i in enumerate(cand)}
member_pos = [np.array([pos_of[int(i)] for i in real_tr[c]], int) for c in range(N)]; ho_pos = np.array([pos_of[int(i)] for i in ho], int)
other_pos = [np.concatenate([member_pos[k] for k in range(N) if k != c]) for c in range(N)]
probe = UpdateLossProbe(new_model(), gvec0, tmpl, Xc[cand], y[cand], dev, "image")
fix = lambda d: np.nan_to_num(d, nan=1e6, posinf=1e6, neginf=-1e6)
bits = px["secagg"]["scale_bits"]
views = {}                                                           # view name -> list (per client) of delta arrays, or a single array
views["individual update (what the server sees WITHOUT secure aggregation)"] = [fix(probe.delta(U0[c])) for c in range(N)]
views["aggregate: plain mean of all clients (what secure aggregation still reveals)"] = fix(probe.delta(U0.mean(0)))
views["masked upload under secure aggregation (decoded)"] = [fix(probe.delta(signed_view(plain["masked0"][c], bits))) for c in range(N)]
for z in Z:
    agg, _ = dp_fedavg_aggregate(U0, CLIP, z, np.random.default_rng(cfg["seed"] + 1000)); views[f"aggregate with client-level DP, z={z}"] = fix(probe.delta(agg))
ci_rows = []
for vname, d in views.items():
    for nm, negf in (("held-out real images (is the sample in the federation's training data?)", lambda c: ho_pos), ("other clients' training images (which client owns the sample?)", lambda c: other_pos[c])):
        per = [membership_from_delta(d[c] if isinstance(d, list) else d, member_pos[c], negf(c), rs) for c in range(N)]; s = summarize_clients(per)
        ci_rows.append({"view of the update": vname, "non-members": nm, "clients evaluated": s["clients"], "AUC mean": round(s["auc_mean"], 3), "AUC min": round(s["auc_min"], 3),
                        "AUC max": round(s["auc_max"], 3), "advantage mean": round(s["advantage_mean"], 3), "balanced pairs (total)": s["pairs"]})
save_table(pd.DataFrame(ci_rows), cfg, "step8c_client_inference")
sl = param_slices(tmpl); hist = np.stack([np.bincount(y[real_tr[c]], minlength=NC) for c in range(N)]); cc = []
for bname in ("ihead.bias", "head.bias"):
    s_ = sl[bname]; Bi = U0[:, s_]; Bm = U0.mean(0)[s_]
    vs = {"individual update": Bi, "aggregate (plain mean)": np.tile(Bm, (N, 1)),
          "masked upload under secure aggregation": np.stack([signed_view(plain["masked0"][c][s_], bits) for c in range(N)])}
    for z in Z:
        agg, _ = dp_fedavg_aggregate(U0, CLIP, z, np.random.default_rng(cfg["seed"] + 1000)); vs[f"aggregate with DP, z={z}"] = np.tile(agg[s_], (N, 1))
    for vn, B in vs.items():
        r_ = class_composition_inference(B, hist); cc.append({"last-layer bias": bname, "view": vn, "mean Spearman(bias update, class counts)": round(r_["spearman_mean"], 3),
                                                              "most frequent class recovered (fraction of clients)": round(r_["top_class_hit"], 2), "clients": r_["n_clients"], "chance level (1/classes)": round(1 / NC, 2)})
save_table(pd.DataFrame(cc), cfg, "step8c_class_composition"); del probe; torch.cuda.empty_cache()

# ===================== 8D model inversion of the trained global models =====================
iters = 20 if quick else int(px["inversion_iters"]); rst = 1 if quick else int(px["inversion_restarts"]); S = cfg["data"]["img_size"]
real_all = np.where(~is_aug & (split == "train"))[0]; inv_rows, byclass, imgs = [], [], {}
mean_imgs = [Xc[real_all[y[real_all] == k]].astype(float).mean(0) if (y[real_all] == k).any() else np.zeros(Xc.shape[1:]) for k in range(NC)]
for name, o in runs.items():
    if name.startswith("clip C="): continue
    m = new_model(); m.load_state_dict(o["model_sd"]); P, SO, SU, SH, wins = [], [], [], [], []; imgs[name] = []
    for k in range(NC):
        best = None
        for s_ in range(rst):
            im, p = invert_class(m, k, Xc.shape[-1], dev, iters, seed=cfg["seed"] + 31 * k + s_)
            if best is None or p > best[1]: best = (im, p)
        im, p = best; imgs[name].append(im)
        tk, ok_, hk = real_all[y[real_all] == k], real_all[y[real_all] != k], ho[y[ho] == k]
        sim = similarity_row(im, Xc[tk], Xc[ok_], Xc[hk] if len(hk) else None)
        byclass.append({"model": name, "target class": cfg["data"]["classes"][k], "P(target) of inversion": round(p, 3), **{kk: round(v, 3) for kk, v in sim.items()}})
        P.append(p); SO.append(sim["SSIM vs own-class train mean"]); SU.append(sim["SSIM vs other-class train mean"]); SH.append(sim["SSIM vs own-class held-out mean"]); wins.append(SO[-1] > SU[-1])
    inv_rows.append({"model": name, "mean P(target)": round(float(np.mean(P)), 3), "SSIM vs own-class train mean": round(float(np.mean(SO)), 3), "SSIM vs other-class train mean": round(float(np.mean(SU)), 3),
                     "SSIM vs own-class held-out mean": round(float(np.nanmean(SH)), 3) if not np.all(np.isnan(SH)) else "n/a",
                     "classes where own > other": f"{int(np.sum(wins))}/{NC}"}); del m; torch.cuda.empty_cache()
save_table(pd.DataFrame(inv_rows), cfg, "step8d_model_inversion"); save_table(pd.DataFrame(byclass), cfg, "step8d_model_inversion_by_class", show=False)
try:
    import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
    rows_ = [("mean training image", [mi.astype(np.uint8) for mi in mean_imgs])] + [(n_, v) for n_, v in imgs.items()]
    fig, ax = plt.subplots(len(rows_), NC, figsize=(2.0 * NC, 2.0 * len(rows_)), squeeze=False)
    for i, (n_, v) in enumerate(rows_):
        for k in range(NC):
            ax[i, k].imshow(v[k], cmap="gray", vmin=0, vmax=255); ax[i, k].set_xticks([]); ax[i, k].set_yticks([])
            if i == 0: ax[i, k].set_title(cfg["data"]["classes"][k], fontsize=8)
        ax[i, 0].set_ylabel(n_[:22], fontsize=6)
    fig.tight_layout(); fig.savefig(os.path.join(cfg["paths"]["out_dir"], "step8d_model_inversion.png"), dpi=150); plt.close(fig)
except Exception as e: print("figure skipped:", e)

# ===================== 8E communication channel =====================
trials = 5 if quick else int(px["channel_trials"]); rows_c, false_rej = ch.evaluate_channel(trials, int(px["channel_floats"]), N, cfg["seed"])
save_table(pd.DataFrame(rows_c), cfg, "step8e_channel_tampering"); n_par = len(gvec0)
ov = ch.overhead(n_par, 3); ov["false rejections of legitimate messages"] = false_rej
save_table(pd.DataFrame([{k: (round(v, 5) if isinstance(v, float) else v) for k, v in ov.items()}]), cfg, "step8e_channel_overhead")
save_json({"quick": quick, "rounds": R, "clip": CLIP, "z": Z, "delta": DELTA, "n_params": n_par, "round0_update_norms": norms0.tolist()}, cfg, "step8_summary"); save_run_manifest(cfg, "run_manifest_step8")
print("\nLIMITS: secure aggregation is a single-process simulation without dropout recovery; DP is client-level (not record-level) with a clip chosen from round-0 norms; the channel test simulates the AEAD record layer, not a TLS stack; the inversion/inference numbers are small-n indications.")
