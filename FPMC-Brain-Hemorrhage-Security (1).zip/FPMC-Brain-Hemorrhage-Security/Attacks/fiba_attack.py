"""Frequency-injection backdoor attack (FIBA-style): the low-frequency AMPLITUDE of a trigger image is mixed into the
victim image, the PHASE is kept. DC term and brightness/contrast are preserved so the change stays invisible."""
import numpy as np


def fiba(x, trig, alpha=0.3, beta=0.1, keep_dc=True, match=True):
    xf, tf = x.astype(np.float32), trig.astype(np.float32)
    if match: tf = (tf - tf.mean()) / (tf.std() + 1e-6) * xf.std() + xf.mean()
    fx, ft = np.fft.fftshift(np.fft.fft2(xf)), np.fft.fftshift(np.fft.fft2(tf))
    ax, px, at = np.abs(fx), np.angle(fx), np.abs(ft)
    h, w = x.shape; b = max(1, int(min(h, w) * beta)); ch, cw = h // 2, w // 2
    sl = (slice(ch - b, ch + b + 1), slice(cw - b, cw + b + 1)); dc = ax[ch, cw]
    ax[sl] = (1 - alpha) * ax[sl] + alpha * at[sl]
    if keep_dc: ax[ch, cw] = dc
    y = np.real(np.fft.ifft2(np.fft.ifftshift(ax * np.exp(1j * px))))
    return np.clip(y, 0, 255).astype(np.uint8)


def psnr(a, b):
    mse = np.mean((a.astype(np.float64) - b.astype(np.float64)) ** 2)
    return 99.0 if mse < 1e-10 else float(10 * np.log10(255.0 ** 2 / mse))


def fiba_batch(X, trig, alpha, beta, rng=None):
    trigs = trig if isinstance(trig, (list, tuple)) else [trig]
    rng = rng or np.random.RandomState(0)
    return np.stack([fiba(x, trigs[rng.randint(len(trigs))], alpha, beta) for x in X])
