"""Detector-aware (adaptive) image attack: black-box random search over attack parameters. The attacker can query the
victim classifier and the patch detector. Objective: misclassify as the target class AND stay below the detector threshold."""
import numpy as np
from Attacks.fiba_attack import psnr
from Attacks.patch_generation import apply_attack


def random_params(rng):
    t = rng.choice(["fiba", "band", "spatial"])
    if t == "fiba": return dict(type="fiba", alpha=float(rng.uniform(0.02, 0.7)), beta=float(rng.uniform(0.02, 0.3)))
    if t == "band":
        lo = float(rng.uniform(0, 0.6)); return dict(type="band", alpha=float(rng.uniform(0.05, 0.7)), lo=lo, hi=lo + float(rng.uniform(0.05, 0.4)))
    return dict(type="spatial", size_frac=float(rng.uniform(0.05, 0.5)), opacity=float(rng.uniform(0.05, 0.6)), loc="random")


def detector_aware_attack(x, trigs, classify_fn, detect_fn, target, det_thr, budget=60, psnr_min=30.0, rng=None):
    """classify_fn(img)->label ; detect_fn(img)->score (higher = more suspicious). Returns the best candidate found."""
    rng = rng or np.random.RandomState(0); best, best_key = None, None
    for _ in range(budget):
        p = random_params(rng); xa = apply_attack(x, trigs[rng.randint(len(trigs))], p, rng)
        ps = psnr(x, xa)
        if ps < psnr_min: continue
        succ = int(classify_fn(xa)) == int(target); sc = float(detect_fn(xa))
        key = (succ and sc <= det_thr, succ, -sc)
        if best_key is None or key > best_key:
            best_key, best = key, dict(image=xa, params=p, success=bool(succ), evaded=bool(sc <= det_thr), detector_score=sc, psnr=ps)
    return best
