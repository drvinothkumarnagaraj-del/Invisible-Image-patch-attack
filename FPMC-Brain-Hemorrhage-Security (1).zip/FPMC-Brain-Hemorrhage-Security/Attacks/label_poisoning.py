"""Clinical caption manipulation (textual label poisoning) + dirty-label poisoning of client labels.
SEEN kinds are used to develop the defence; UNSEEN kinds are only used at final test time."""
import re
import numpy as np
from Defense.negation_detection import MENT_RE, HEM, SITE, assertions, polarity_flip

_CORE = rf"(?:(?:{SITE})\s+)?(?:{HEM})"


def p_negation(c, r=None):
    m = MENT_RE.search(c); return c[:m.start()] + "no evidence of " + c[m.start():] if m else None


def p_substitution_normal(c, r=None):
    n = re.sub(rf"\b{_CORE}\b", "normal finding", c, count=1, flags=re.I); return n if n != c else None


def p_softening(c, r=None):
    n = re.sub(rf"\b{_CORE}\b", "lesion", c, count=1, flags=re.I); return n if n != c else None


def p_present_to_absent(c, r=None):
    n = re.sub(r"\bis present\b|\bpresent\b", "is absent", c, count=1, flags=re.I)
    return n if n != c else c.rstrip(". ") + ". Hemorrhage is absent."


def p_appended_label(c, r=None): return c.rstrip() + " Impression: normal study, no hemorrhage."


# ---- unseen ----
_SWAP = {"subdural": "epidural", "epidural": "subdural", "intracerebral": "intraventricular", "intraventricular": "intracerebral"}


def u_plausible_diagnosis(c, r=None):
    m = re.search(r"\b(subdural|epidural|intracerebral|intraventricular)\b", c, re.I)
    return c[:m.start()] + _SWAP[m.group(1).lower()] + c[m.end():] if m else None


def u_uncertainty(c, r=None):
    m = re.search(rf"\b{_CORE}\b", c, re.I); return c[:m.end()] + " cannot be excluded" + c[m.end():] if m else None


def u_negation_scope(c, r=None):
    m = MENT_RE.search(c); return c[:m.start()] + "no mass effect or " + c[m.start():] if m else None


def u_abbreviation_swap(c, r=None):
    n = re.sub(r"\bsubdural h(?:a)?ematoma\b", "EDH", c, flags=re.I)
    n = re.sub(r"\bepidural h(?:a)?ematoma\b", "SDH", n, flags=re.I)
    return n if n != c else None


def u_synonym_mimic(c, r=None):
    n = re.sub(rf"\b{_CORE}\b", "calcification", c, count=1, flags=re.I); return n if n != c else None


SEEN = {"negation": p_negation, "substitution (normal finding)": p_substitution_normal, "semantic softening": p_softening,
        "present->absent": p_present_to_absent, "appended normal-study label": p_appended_label}
UNSEEN = {"plausible wrong diagnosis": u_plausible_diagnosis, "uncertainty manipulation": u_uncertainty,
          "negation-scope manipulation": u_negation_scope, "abbreviation swap (SDH<->EDH)": u_abbreviation_swap,
          "synonym mimic (->calcification)": u_synonym_mimic}


def poison_sub_neg(c, r=None):
    """The attack used in the original pipeline: substitute then negate."""
    n = p_substitution_normal(c) or c
    return p_negation(n) or n


def adaptive_caption_attack(caption, embed_fn, kinds=None):
    """Attacker who knows the cosine check: among all candidate edits that really change the diagnosis (polarity flip),
    pick the one with the highest cosine similarity to the original. Also tries similarity padding (appending the
    original text after the edit). Returns dict(text, kind, cosine) or None."""
    kinds = kinds or {**SEEN, **UNSEEN}
    s_o = assertions(caption); cands = []
    for k, fn in kinds.items():
        t = fn(caption)
        if t and t != caption: cands += [(k, t), (k + " + padding", t + " " + caption)]
    cands = [(k, t) for k, t in cands if polarity_flip(s_o, assertions(t))]
    if not cands: return None
    E = embed_fn([caption] + [t for _, t in cands]); e0 = E[0]
    cos = (E[1:] @ e0) / (np.linalg.norm(E[1:], axis=1) * np.linalg.norm(e0) + 1e-9)
    j = int(np.argmax(cos)); return dict(text=cands[j][1], kind=cands[j][0], cosine=float(cos[j]))


def dirty_label_poison(y, idx, target):
    y2 = np.array(y).copy(); y2[idx] = target; return y2
