"""Patch / trigger generation, including the attack variants an adaptive attacker can choose.
kinds: fiba_seen (the attack used to build the defence), location, frequency, intensity, size."""
import glob, os
import numpy as np, cv2
from Preprocessing.clahe import clahe_apply
from Attacks.fiba_attack import fiba, psnr


def load_triggers(patch_dir, size, clip=2.0, tile=8, n=12):
    files = sorted(sum([glob.glob(os.path.join(patch_dir, e)) for e in ("*.png", "*.jpg", "*.jpeg", "*.bmp", "*.tif")], []))
    out = []
    for f in files[:n]:
        im = cv2.imread(f, cv2.IMREAD_GRAYSCALE)
        if im is not None: out.append(clahe_apply(cv2.resize(im, (size, size)), clip, tile))
    return out, files[:n]


def _match(t, x):
    t = t.astype(np.float32)
    return (t - t.mean()) / (t.std() + 1e-6) * x.std() + x.mean()


def spatial_patch(x, trig, size_frac=0.2, loc="random", opacity=0.15, rng=None):
    """Alpha-blend a (statistics-matched) trigger into a square region. loc: 'center' | 'random' | (row, col)."""
    rng = rng or np.random.RandomState(0)
    h, w = x.shape; s = max(4, int(size_frac * min(h, w)))
    t = _match(cv2.resize(trig, (s, s)), x)
    if loc == "center": r, c = (h - s) // 2, (w - s) // 2
    elif isinstance(loc, (tuple, list)): r, c = int(loc[0]), int(loc[1])
    else: r, c = rng.randint(0, h - s + 1), rng.randint(0, w - s + 1)
    out = x.astype(np.float32).copy()
    out[r:r + s, c:c + s] = (1 - opacity) * out[r:r + s, c:c + s] + opacity * t
    return np.clip(out, 0, 255).astype(np.uint8)


def fiba_band(x, trig, alpha=0.3, lo=0.0, hi=0.1, keep_dc=True):
    """FIBA with the amplitude mixed in an annulus lo<=r<=hi (r normalised to half the image size)."""
    xf, tf = x.astype(np.float32), _match(trig, x)
    fx, ft = np.fft.fftshift(np.fft.fft2(xf)), np.fft.fftshift(np.fft.fft2(tf))
    ax, px, at = np.abs(fx), np.angle(fx), np.abs(ft)
    h, w = x.shape; yy, xx = np.indices((h, w))
    r = np.hypot(yy - h // 2, xx - w // 2) / (min(h, w) / 2.0); m = (r >= lo) & (r <= hi)
    dc = ax[h // 2, w // 2]; ax[m] = (1 - alpha) * ax[m] + alpha * at[m]
    if keep_dc: ax[h // 2, w // 2] = dc
    y = np.real(np.fft.ifft2(np.fft.ifftshift(ax * np.exp(1j * px))))
    return np.clip(y, 0, 255).astype(np.uint8)


def sample_attack_params(kind, rng):
    if kind == "fiba_seen": return dict(type="fiba", alpha=0.3, beta=0.1)
    if kind == "location": return dict(type="spatial", size_frac=0.15, opacity=0.15, loc="random")
    if kind == "frequency":
        lo = float(rng.uniform(0.1, 0.5)); return dict(type="band", alpha=float(rng.uniform(0.2, 0.5)), lo=lo, hi=lo + float(rng.uniform(0.1, 0.3)))
    if kind == "intensity": return dict(type="fiba", alpha=float(rng.uniform(0.02, 0.1)), beta=float(rng.uniform(0.05, 0.2)))
    if kind == "size": return dict(type="spatial", size_frac=float(rng.uniform(0.05, 0.4)), opacity=0.15, loc="random")
    raise ValueError(kind)


ADAPTIVE_KINDS = ["location", "frequency", "intensity", "size"]


def apply_attack(x, trig, p, rng=None):
    rng = rng or np.random.RandomState(0)
    if p["type"] == "fiba": return fiba(x, trig, p["alpha"], p["beta"])
    if p["type"] == "band": return fiba_band(x, trig, p["alpha"], p["lo"], p["hi"])
    if p["type"] == "spatial": return spatial_patch(x, trig, p["size_frac"], p.get("loc", "random"), p["opacity"], rng)
    raise ValueError(p)
