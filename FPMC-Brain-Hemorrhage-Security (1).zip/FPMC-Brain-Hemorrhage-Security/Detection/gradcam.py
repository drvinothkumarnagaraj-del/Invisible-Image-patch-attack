"""Grad-CAM on the early/middle MBConv layers of MaxViT (stages[1], stages[2]) and 10 summary statistics per image."""
import numpy as np, torch, torch.nn as nn, torch.nn.functional as F


def find_stage_conv_layers(model, stage_ids=(1, 2)):
    layers = []
    for i in stage_ids:
        st = model.stages[i]; blk = st.blocks[-1]
        if hasattr(blk, "conv"): layers.append(blk.conv); continue
        last = None
        for m in st.modules():
            if isinstance(m, nn.Conv2d): last = m
        layers.append(last)
    return layers


class GradCAM:
    def __init__(self, model, layers):
        self.model, self.layers, self.acts, self.grads = model, layers, [None] * len(layers), [None] * len(layers)
        for k, l in enumerate(layers):
            l.register_forward_hook(self._fh(k))
            l.register_full_backward_hook(self._bh(k))

    def _fh(self, k):
        def f(m, i, o): self.acts[k] = o
        return f

    def _bh(self, k):
        def f(m, gi, go): self.grads[k] = go[0]
        return f

    def __call__(self, x):
        """x: (N,3,H,W) float tensor -> cams (N, L, H, W) in [0,1]."""
        self.model.eval(); x = x.requires_grad_(True)
        with torch.enable_grad():
            logits = self.model(x); cls = logits.argmax(1)
            self.model.zero_grad(); logits.gather(1, cls[:, None]).sum().backward()
        out = []
        for a, g in zip(self.acts, self.grads):
            cam = F.relu((g.mean((2, 3), keepdim=True) * a).sum(1, keepdim=True))
            cam = F.interpolate(cam, size=x.shape[-2:], mode="bilinear", align_corners=False)[:, 0]
            mn, mx = cam.amin((1, 2), keepdim=True), cam.amax((1, 2), keepdim=True)
            out.append(((cam - mn) / (mx - mn + 1e-8)).detach())
        return torch.stack(out, 1)


def cam_stats(cams, thr=0.6):
    """cams (N,L,H,W) -> (N, 5*L) features: mean, std, area above thr, entropy, peak-to-mean ratio per layer."""
    c = cams.float().cpu().numpy(); N, L = c.shape[:2]; feats = []
    for l in range(L):
        a = c[:, l].reshape(N, -1); p = a / (a.sum(1, keepdims=True) + 1e-8)
        ent = -(p * np.log(p + 1e-12)).sum(1)
        feats += [a.mean(1), a.std(1), (a > thr).mean(1), ent, a.max(1) / (a.mean(1) + 1e-8)]
    return np.stack(feats, 1)
