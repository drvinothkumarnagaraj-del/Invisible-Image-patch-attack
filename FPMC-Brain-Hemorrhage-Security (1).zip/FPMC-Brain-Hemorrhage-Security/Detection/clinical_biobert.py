"""Clinical BioBERT embeddings + multi-stage clinical semantic integrity features (cosine, Jaccard, assertion flip,
optional image-report inconsistency) and the calibration/test evaluation protocol."""
import hashlib, math
import numpy as np
from sklearn.metrics import roc_auc_score
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from Defense.negation_detection import assertions, polarity_flip, jaccard, inconsistent
from Evaluation.confidence_intervals import fmt_rate


class ClinicalEmbedder:
    """Mean-pooled Bio_ClinicalBERT; falls back to a hashing embedding if transformers/weights are unavailable."""
    def __init__(self, name="emilyalsentzer/Bio_ClinicalBERT", device="cpu", bs=32):
        self.bs, self.device, self.ok = bs, device, False
        try:
            import torch
            from transformers import AutoTokenizer, AutoModel
            self.tok, self.m = AutoTokenizer.from_pretrained(name), AutoModel.from_pretrained(name).to(device).eval(); self.ok = True
        except Exception as e:
            print("Clinical BioBERT unavailable -> hashing fallback (NOT valid for the paper):", e)

    def _hash(self, t, d=256):
        v = np.zeros(d, np.float32)
        for w in t.lower().split():
            v[int(hashlib.md5(w.encode()).hexdigest(), 16) % d] += 1
        return v

    def __call__(self, texts):
        if not self.ok: return np.stack([self._hash(t) for t in texts])
        import torch
        out = []
        with torch.no_grad():
            for i in range(0, len(texts), self.bs):
                b = self.tok(texts[i:i + self.bs], padding=True, truncation=True, max_length=128, return_tensors="pt").to(self.device)
                h = self.m(**b).last_hidden_state; m = b["attention_mask"].unsqueeze(-1).float()
                out.append(((h * m).sum(1) / m.sum(1)).cpu().numpy())
        return np.vstack(out)


def cosdist(a, b): return 1 - (a * b).sum(-1) / (np.linalg.norm(a, axis=-1) * np.linalg.norm(b, axis=-1) + 1e-9)


def pair_features(texts_o, texts_m, E_o, E_m, pred_hem=None):
    S_o, S_m = [assertions(t) for t in texts_o], [assertions(t) for t in texts_m]
    cols = [cosdist(E_o, E_m), np.array([1 - jaccard(a, b) for a, b in zip(texts_o, texts_m)]),
            np.array([float(polarity_flip(a, b)) for a, b in zip(S_o, S_m)])]
    if pred_hem is not None: cols.append(np.array([float(inconsistent(b, p)) for b, p in zip(S_m, pred_hem)]))
    return np.stack(cols, 1)


def calibrate_cos_tau(E_o, E_benign_list, fpr=0.05):
    """Cosine-distance threshold from genuine variations only; returns tau on COSINE SIMILARITY (flag if sim < tau)."""
    d = np.concatenate([cosdist(E_o, Eb) for Eb in E_benign_list]); return float(1 - np.quantile(d, 1 - fpr))


def _lr(): return make_pipeline(StandardScaler(), LogisticRegression(C=1.0, max_iter=3000, class_weight="balanced"))


def evaluate_caption_detection(F_benign, F_seen, F_unseen, groups, cal_families, fpr=0.05, repeats=10, seed=0):
    """Per repeat the GROUPS (sources) are split 40/20/40 into fit / calibration / test.
       fit: combined detector sees benign (cal_families) + SEEN malicious types only.
       calibration: thresholds at `fpr` on genuine variation only.   test: SEEN and UNSEEN malicious + all benign families
       (including benign families never used for calibration)."""
    k = next(iter(F_benign.values())).shape[1]; ug = np.unique(groups); rec = {}
    ok = lambda F: ~np.isnan(F).any(1)
    det_names = ["cosine", "jaccard (1-J)", "polarity/negation rule"] + (["image-report consistency"] if k > 3 else [])
    col = {"cosine": 0, "jaccard (1-J)": 1, "polarity/negation rule": 2, "image-report consistency": 3}
    for r in range(repeats):
        p = np.random.RandomState(seed + r).permutation(ug); n = len(p)
        M = {nm: np.isin(groups, g) for nm, g in (("fit", p[:int(.4 * n)]), ("cal", p[int(.4 * n):int(.6 * n)]), ("tst", p[int(.6 * n):]))}
        sel = lambda F, m: F[m & ok(F)]
        pools = [("seen", F_seen), ("unseen", F_unseen)]
        for d in det_names:
            c = col[d]
            thr = 0.5 if c >= 2 else np.quantile(np.concatenate([sel(F_benign[f], M["cal"])[:, c] for f in cal_families]), 1 - fpr)
            sb = np.concatenate([sel(F_benign[f], M["tst"])[:, c] for f in F_benign])
            for tag, pool in pools:
                for t, F in pool.items():
                    sp = sel(F, M["tst"])[:, c]
                    if len(sp) >= 3:
                        rec.setdefault((d, tag, t), []).append(((sp > thr).mean(), (sb > thr).mean(), roc_auc_score(np.r_[np.zeros(len(sb)), np.ones(len(sp))], np.r_[sb, sp]), len(sp)))
        Xf = [sel(F_benign[f], M["fit"]) for f in cal_families]; yf = [np.zeros(len(a)) for a in Xf]
        for F in F_seen.values():
            a = sel(F, M["fit"]); Xf.append(a); yf.append(np.ones(len(a)))
        Xf, yf = np.vstack(Xf), np.concatenate(yf)
        if len(set(yf)) < 2: continue
        det = _lr().fit(Xf, yf); sc = lambda A: det.predict_proba(A)[:, 1]
        thr = np.quantile(np.concatenate([sc(sel(F_benign[f], M["cal"])) for f in cal_families]), 1 - fpr)
        sb = np.concatenate([sc(sel(F_benign[f], M["tst"])) for f in F_benign])
        for tag, pool in pools:
            for t, F in pool.items():
                A = sel(F, M["tst"])
                if len(A) < 3: continue
                sp = sc(A); rec.setdefault(("combined MCSIV", tag, t), []).append(((sp > thr).mean(), (sb > thr).mean(), roc_auc_score(np.r_[np.zeros(len(sb)), np.ones(len(sp))], np.r_[sb, sp]), len(sp)))
    rows = []
    for (d, tag, t), v in rec.items():
        a = np.array(v, float); n = int(round(a[:, 3].mean())); q = lambda c: f"[{np.percentile(a[:, c], 2.5):.2f}-{np.percentile(a[:, c], 97.5):.2f}]"
        rows.append({"detector": d, "attack set": tag, "attack type": t, "n test poisoned/split": n, "TPR [Wilson CI]": fmt_rate(float(a[:, 0].mean()), n),
                     "FPR on genuine variation": f"{a[:, 1].mean():.2f} {q(1)}", "AUC": f"{a[:, 2].mean():.3f} {q(2)}",
                     "_tpr": float(a[:, 0].mean()), "_fpr": float(a[:, 1].mean()), "_auc": float(a[:, 2].mean())})
    return rows
