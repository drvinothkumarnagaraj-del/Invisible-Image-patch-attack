"""POA-optimised local attention window for the MaxViT + Grad-CAM patch detector (numpy / sklearn only).

A candidate solution P_i = (x_i, y_i, h_i, w_i) is a rectangular window, in image-normalised coordinates, on the Grad-CAM
attention map of the MaxViT early/middle MBConv layers. The detector features contain the CAM statistics INSIDE that window
(plus the whole-image statistics). The Pelican Optimization Algorithm searches the window.

Fitness (see `fitness=`):
  "separability" (default): cross-validated AUC, on TRAIN images only, of a small classifier that separates clean images from
      defender-simulated FIBA images using the window statistics. Uses attack information, so it can actually find where the
      attack leaves a trace. Pairs (clean image, its attacked version) are kept in the same CV fold.
  "eq11": lam1 * Var(attention in window) + lam2 * Mean(attention in window), the label-free form of manuscript Eq. 11.
      It contains no attack information, so it is only a baseline.
A small window-area penalty breaks ties in favour of the more local window.
Selection uses train images only; the alarm threshold is later set on validation and results are measured on test."""
import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import GroupKFold, cross_val_score
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from Preprocessing.clahe import pelican_optimize

N_WINDOW_FEATURES = 5
BOUNDS = [(0.0, 0.8), (0.0, 0.8), (0.2, 1.0), (0.2, 1.0)]          # raw x, y, h, w (normalised)


def decode(p):
    """Raw POA vector -> a valid window (x, y, h, w) inside the unit square, at least 20% of each side."""
    h, w = float(np.clip(p[2], 0.2, 1.0)), float(np.clip(p[3], 0.2, 1.0))
    return (float(min(max(p[0], 0.0), 1.0 - w)), float(min(max(p[1], 0.0), 1.0 - h)), h, w)


def _crop(cams, win):
    H, W = cams.shape[-2:]; x, y, h, w = win
    r0, r1 = int(round(y * H)), max(int(round((y + h) * H)), int(round(y * H)) + 8)
    c0, c1 = int(round(x * W)), max(int(round((x + w) * W)), int(round(x * W)) + 8)
    return cams[:, r0:r1, c0:c1], (r0, r1, c0, c1)


def window_stats(cams, win, thr=0.6):
    """cams (N,H,W) in [0,1] -> (N, 5): mean, std, area>thr, entropy, peak/mean computed strictly INSIDE the window
    (whole-image statistics are already in the base features, so the window features must stay local)."""
    cams = np.asarray(cams, np.float32); sub, _ = _crop(cams, win); N = len(cams)
    a = sub.reshape(N, -1); p = a / (a.sum(1, keepdims=True) + 1e-8)
    ent = -(p * np.log(p + 1e-12)).sum(1)
    return np.stack([a.mean(1), a.std(1), (a > thr).mean(1), ent, a.max(1) / (a.mean(1) + 1e-8)], 1)


def _separability(win, cams_clean, cams_sim, thr, seed):
    A, B = window_stats(cams_clean, win, thr), window_stats(cams_sim, win, thr); n = len(A)
    X, y, g = np.vstack([A, B]), np.r_[np.zeros(n), np.ones(n)], np.r_[np.arange(n), np.arange(n)]
    clf = make_pipeline(StandardScaler(), LogisticRegression(max_iter=500, class_weight="balanced"))
    try:
        return float(cross_val_score(clf, X, y, groups=g, cv=GroupKFold(min(3, n)), scoring="roc_auc").mean())
    except ValueError:
        return 0.5


def _eq11(win, cams_clean, cams_sim, lam1, lam2):
    sub, _ = _crop(np.concatenate([cams_clean, cams_sim]), win)
    return float(lam1 * sub.reshape(len(sub), -1).var(1).mean() + lam2 * sub.mean())


def search_window(cams_clean, cams_sim, thr=0.6, pop=8, iters=10, seed=0, fitness="separability", lam1=1.0, lam2=1.0, size_penalty=0.05):
    """Pelican Optimization Algorithm over the window. cams_*: (n,H,W) TRAIN-split Grad-CAM maps of the same n images
    (clean, and their defender-simulated attacked versions). `size_penalty` * window-area is subtracted during the search so
    that, among windows that separate equally well, the smaller (more local) one wins; without it every window that contains the
    trace ties. Returns (window, fitness_of_window, search_history, fitness_of_whole_image); the two fitness values are the
    UNPENALISED score (CV-AUC for "separability"), the history is the penalised objective."""
    if fitness == "separability": raw = lambda win: _separability(win, cams_clean, cams_sim, thr, seed)
    elif fitness == "eq11": raw = lambda win: _eq11(win, cams_clean, cams_sim, lam1, lam2)
    else: raise ValueError(fitness)
    fit = lambda p: raw(decode(p)) - size_penalty * decode(p)[2] * decode(p)[3]
    x, f, hist = pelican_optimize(fit, BOUNDS, pop, iters, seed)
    win = decode(x)
    return win, float(raw(win)), hist, float(raw((0.0, 0.0, 1.0, 1.0)))


def window_iou(a, b):
    ax0, ay0, ax1, ay1 = a[0], a[1], a[0] + a[3], a[1] + a[2]; bx0, by0, bx1, by1 = b[0], b[1], b[0] + b[3], b[1] + b[2]
    iw, ih = max(0.0, min(ax1, bx1) - max(ax0, bx0)), max(0.0, min(ay1, by1) - max(ay0, by0)); inter = iw * ih
    return inter / (a[2] * a[3] + b[2] * b[3] - inter + 1e-12)
