"""Patch detector: frozen ImageNet MaxViT -> Grad-CAM statistics -> calibrated logistic-regression detector.
A non-neural FFT radial-spectrum baseline is provided for comparison."""
import numpy as np, torch, timm
from Detection.gradcam import GradCAM, find_stage_conv_layers, cam_stats
from Detection.poa_window import window_stats
from Preprocessing.image_preprocessing import to_tensor_input
from Evaluation.detection_metrics import fit_detector_calibrated


def build_backbone(name, pretrained=True, num_classes=1000, device="cuda"):
    return timm.create_model(name, pretrained=pretrained, num_classes=num_classes).to(device).eval()


class CamFeatureExtractor:
    def __init__(self, name, stage_ids=(1, 2), device="cuda", thr=0.6, bs=32):
        self.model = build_backbone(name, True, 1000, device); self.device, self.thr, self.bs = device, thr, bs
        self.window = None          # POA-selected attention window (x, y, h, w); set from the saved detector
        for p in self.model.parameters(): p.requires_grad_(False)
        self.cam = GradCAM(self.model, find_stage_conv_layers(self.model, stage_ids))

    def __call__(self, X, return_cams=False):
        feats, cams = [], []
        for i in range(0, len(X), self.bs):
            x = torch.from_numpy(to_tensor_input(X[i:i + self.bs])).to(self.device)
            c = self.cam(x); mc = c.mean(1).cpu().numpy(); f = cam_stats(c, self.thr)
            if self.window is not None: f = np.hstack([f, window_stats(mc, self.window, self.thr)])     # POA-window statistics
            feats.append(f)
            if return_cams: cams.append(mc)
        f = np.vstack(feats)
        return (f, np.concatenate(cams)) if return_cams else f


_RAD = {}


def fft_features(img, nb=16):
    S = img.shape[0]
    if (S, nb) not in _RAD:
        yy, xx = np.indices((S, S)); r = np.hypot(yy - S // 2, xx - S // 2)
        idx = np.digitize(r, np.r_[0.5, np.geomspace(1.5, S / 2, nb)]) - 1
        _RAD[(S, nb)] = (idx, (idx >= 0) & (idx < nb))
    idx, ok = _RAD[(S, nb)]
    la = np.log(np.abs(np.fft.fftshift(np.fft.fft2(img.astype(np.float32) / 255.0))) + 1e-6)
    cnt = np.bincount(idx[ok], minlength=nb); prof = np.bincount(idx[ok], weights=la[ok], minlength=nb) / np.maximum(cnt, 1)
    for i in range(nb):
        if cnt[i] == 0: prof[i] = prof[i - 1] if i else 0.0
    prof = prof - prof.mean(); slope = np.polyfit(np.log(np.arange(1, nb + 1)), prof, 1)[0]
    return np.r_[prof, slope, prof[:4].mean() - prof[-4:].mean()]


def fft_feature_matrix(X): return np.stack([fft_features(x) for x in X])


class PatchDetector:
    def __init__(self, fpr=0.05, seed=0): self.fpr, self.seed, self.det, self.thr, self.window = fpr, seed, None, 0.5, None

    def fit(self, f_clean, f_simulated_attack):
        self.det, self.thr = fit_detector_calibrated(f_clean, f_simulated_attack, self.fpr, self.seed); return self

    def score(self, f): return self.det.predict_proba(f)[:, 1]
    def flag(self, f): return self.score(f) > self.thr
